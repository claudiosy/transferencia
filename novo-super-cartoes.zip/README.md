# SuperCartoes Project using React Native

## This project contains:

[x] React & React Native
[x] TypeScript
[x] Storybook
[x] Styled-components
[x] Formik
[x] Prettier & Lint
[x] Pre commit tasks using Husky
[x] Enviroment variables (dot-env)

## Installing

```yarn``` or ```npm install```

## Running
### iOS
```react-native run-ios```

To run in a device, use XCode and set the device as build target.

### Android
1. Start Android Emulator from Android Studio AVD Manager or run ```android avd``` or connect a device using USB
2. ```react-native run-android```

### Storybook
```yarn storybook``` or ```npm run storybook```

## Troubleshooting

### iOS
* No bundle URL present:
This issue is generally caused when the app can't find the current running bundle (packager). There's a closed issue in React Native GitHub repository with a lot of approaches that may solve it https://github.com/facebook/react-native/issues/12754

I faced this issue while trying to run the app inside Super Digital enviroment, if you face this issue, try the following:
1. Make sure ```127.0.0.1``` and ```localhost``` are added to proxy bypass
2. Make sure 


* Error: `fsevents` unavailable:
This error happens because React Native needs watchman to run and it couldn't be found in the system. I guess due to proxy matters it was not automatically downloadded. So follow this:
1. Manually install xcode command-line tools from Apple website
2. Run ```npm r -g watchman```
3. Run ```brew install watchman```
4. Run ```react-native run-ios``` again

Make sure there's no error during watchman installation. If the error persists, try another approach from the link above.

### Android:
* adb not recognized:
This error is due to missing command-line that should have been automatically installed from Android Studio. To solve do the following:

1. Download the android-platform-tools from developer.android.com
2. Run ```/usr/bin/open -e ~/.bash_profile```
3. Make sure you have the following config:
```
export PATH=~/Library/Android/sdk/platform-tools:/usr/local/bin:/usr/bin:/bin:/usr/sbin:/sbin:/usr/local/share/dotnet:/Library/Frameworks/Mono.framework/Versions/Current/
```

* Emulator not authorized:
When running ```adb devices``` appears as ```unauthorized``` and due to this the app doesn't launch in the emulator. Solution:
1. Close the emulator
2. run ```adb kill-server```
3. Open Android Studio AVD Manager
4. Select the emulator actions and press ```Wipe Data```
4. Run ```react-native run-android``` again


* When trying to run the app by ```react-native run-android``` it doesn't simply doesn't launch. Solution:
1. Open the project folder and run ```chmod +x ./android/grandlew```
2. Run ```react-native run-android``` again

* Unable to load script:
This happens because the device is trying to connect its own localhost to find the bundle. You have to tell it to use the computer localhost instead. Solution:
run ```yarn android:reverse``` or ```npm run android:reverse```