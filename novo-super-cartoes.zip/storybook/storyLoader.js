
// Auto-generated file created by react-native-storybook-loader
// Do not edit.
//
// https://github.com/elderfo/react-native-storybook-loader.git

function loadStories() {
  require('../src/components/BankStatement/BankStatement.stories');
  require('../src/components/Login/Login.stories');
  require('../src/components/LoginForm/LoginForm.stories');
  require('../src/components/PhoneNumberValidation/PhoneNumberValidation.stories');
  require('../src/components/Template/Template.stories');
  require('../src/components/Welcome/Welcome.stories');
  require('../src/components/common/Button/Button.stories');
  require('../src/components/common/Icon/Icon.stories');
  require('../src/components/common/Input/InputText.stories');
  require('../src/components/common/Logo/Logo.stories');
  require('../src/components/common/Text/Text.stories');
  require('./stories/test.stories');
  
}

const stories = [
  '../src/components/BankStatement/BankStatement.stories',
  '../src/components/Login/Login.stories',
  '../src/components/LoginForm/LoginForm.stories',
  '../src/components/PhoneNumberValidation/PhoneNumberValidation.stories',
  '../src/components/Template/Template.stories',
  '../src/components/Welcome/Welcome.stories',
  '../src/components/common/Button/Button.stories',
  '../src/components/common/Icon/Icon.stories',
  '../src/components/common/Input/InputText.stories',
  '../src/components/common/Logo/Logo.stories',
  '../src/components/common/Text/Text.stories',
  './stories/test.stories',
  
];

module.exports = {
  loadStories,
  stories,
};
