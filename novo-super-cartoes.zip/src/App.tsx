import * as React from 'react'
import { StatusBar, SafeAreaView, StyleSheet } from 'react-native'
import Router from './Router';
import { colors } from './theme/theme'


export default class App extends React.Component {
  render() {
    return (
      <SafeAreaView style={styles.safeArea}>
        <StatusBar
          backgroundColor={colors.background.primary}
          barStyle='light-content'
        />
        <Router />
      </SafeAreaView>
    );
  }
}

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: colors.background.primary
  }
})