export const icons = {
  small: 22,
  medium: 30,
  large: 46,
}
