export const fontSizes = {
  small: 12,
  medium: 16,
  large: 26,
}
