export const replaceAll = (str: string = "", find: string, replace: string) =>
	str.replace(new RegExp(find, "g"), replace)

export const preventStringCharacters = (
	text: string,
	getFieldValue: (value: string) => void
) => {
	if (isNaN(Number(replaceAll(text, " ", "")))) {
		getFieldValue(text.slice(0, -1))
		return false
	}
	return true
}

export const formatCardNumber = text => {
	const cleanText = replaceAll(text, " ", "")
	if (cleanText.length >= 16) {
		const cardNumber = cleanText
			.substring(0, 16)
			.match(/(\d{4})(\d{4})(\d{4})(\d{4})/)
		return `${cardNumber[1]} ${cardNumber[2]} ${cardNumber[3]} ${cardNumber[4]}`
	}
	return (text = `${text} `)
}

export const addGaps = (text: string = "", gaps: number[]) => {
	const offsets = [0].concat(gaps).concat([text.length])

	return offsets
		.map((end, index) => {
			if (index === 0) {
				return ""
			}
			const start = offsets[index - 1]
			return text.substr(start, end - start)
		})
		.filter(part => part !== "")
		.join(" ")
}


const addMinutes = (date, minutes) => new Date(date.getTime() + minutes*60000);
export const countDown = (
  {
    minutesLeft,
    onTimeUpdate,
    onFinish,
  }:
  {
    minutesLeft: number
    onTimeUpdate: (timeLeft: string) => void
    onFinish: () => void
  }
): NodeJS.Timeout => {
  const countDownDate = addMinutes(new Date(), minutesLeft).getTime();

  const updateTime = setInterval(() => {
    const now = new Date().getTime();
    const distance = countDownDate - now;

    const calcBase = 1000 * 60;
    const minutes = Math.floor((distance % (calcBase * 60)) / (calcBase));
    const seconds = Math.floor((distance % (calcBase)) / 1000);

    if (distance < 0) {
      onFinish();
      clearInterval(updateTime);
    } else {
      onTimeUpdate(`${minutes < 10 ? `0${minutes}` : minutes}:${seconds < 10 ? `0${seconds}` : seconds}`)
    }
  }, 1000);

  return updateTime;
}

export const generateToken = (length: number = 6, extraChar: string = '0') => {
  const randomNumber = Math.floor(0 + Math.random() * 999999);
  const token = randomNumber.toString().padEnd(length, extraChar);
  return token;
}

export const phoneMask = (value: string) => value.trim().replace(/^(\d{2})(\d{4,5})(\d{4})$/g, '($1) $2-$3')

export const testPhoneMask = (value: string) => new RegExp(/\(\d{2}\)\s\d{4,5}-?\d{4}/g).test(value)