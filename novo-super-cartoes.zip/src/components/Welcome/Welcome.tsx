import * as React from 'react'
import { KeyboardAvoidingView, Platform, Alert, ActivityIndicator } from 'react-native'
import styled, { css } from 'styled-components/native'
import { NavigationScreenProps } from 'react-navigation';

import Text from '../common/Text/Text'
import Logo from '../common/Logo/Logo'
import InputText from '../common/Input/InputText'
import Button from '../common/Button/Button'
import { Formik } from 'formik'
import * as Yup from 'yup'
import { phoneMask, testPhoneMask } from "../../helpers/helpers"
import { withTemplate } from '../Template/withTemplate';
import { sendPhoneCode } from '../../api/sendPhoneCode';
import { STATUS_CODE } from '../../api/types';

/**************************************************
 ***** Styled Components
 **************************************************/
const Wrapper = styled.ScrollView`
  padding: 10px;
`

const MarginContainer = css`
  margin: 10px;
`

const CenterContainer = css`
  justify-content: center;
  align-items: center;
  align-self: center;
`

const MainContainer = styled.View`
  ${MarginContainer}
`

const LogoContainer = styled.View`
  ${MarginContainer}
`

const ContentContainer = styled.View`
  ${CenterContainer}
  flex-direction: column;
`

const InputContainer = styled.View`
  ${CenterContainer}
  width: 70%;
  margin-top: 30px;
`

const ButtonContainer = styled.View`
  ${MarginContainer}
  margin-top: 30px;
`

const TextContainer = styled.View`
  margin: 10px 0;
`

const TextStyled = styled(Text)`
  text-align: center;
`

const BottomContainer = styled.View`
  ${MarginContainer}
  align-items: center;
  flex-direction: row;
  justify-content: flex-end;
`

const SantanderLogo = styled.Image`
  height: 30px
  width: 100px;
  margin: 0 5px;
`

/**************************************************
 ***** Interfaces
 **************************************************/
interface WelcomeProps {
  navigation: NavigationScreenProps<any>
}

/**************************************************
 ***** Component
 **************************************************/
class Welcome extends React.PureComponent<WelcomeProps> {
  static navigationOptions = {
    header: null,
  }

  /**************************************************
  ***** Handlers
  **************************************************/

  /**************************************************
  ***** Logic
  **************************************************/
  handlePhoneNumberChange = (value, setFieldValue) => {
    setFieldValue('phoneNumber', phoneMask(value))
  }

  handlePhoneNumberBlur = (value, setFieldValue) => {
    setFieldValue('phoneNumber', phoneMask(value))
  }

  /**************************************************
   ***** Render
   **************************************************/
  render() {
    return (
      <KeyboardAvoidingView
        behavior={Platform.OS === 'ios' ? 'padding' : 'position'}
        keyboardVerticalOffset={Platform.select({ ios: 0, android: -200 })}
      >
        <Formik
          initialValues={{
            phoneNumber: '',
          }}
          onSubmit={async ({ phoneNumber }, { setSubmitting }) => {
            /*
            const sendCode = await sendPhoneCode({ phoneNumber })
            
            if (sendCode.status === STATUS_CODE.ERROR) {
              Alert.alert('Erro', 'Erro ao tentar enviar o código de validação. Por favor, tente novamente');
              setSubmitting(false)
              return null;
            }
            */
            this.props.navigation.navigate('PhoneNumberValidation', { phoneNumber })
          }}
          validationSchema={() => 
            Yup.object().shape({
              phoneNumber: Yup.string()
              .required('Informe seu telefone')
              .test({
                name: 'is-valid-country',
                message: 'Telefone inválido',
                test: phoneNumber => testPhoneMask(phoneNumber),
              })
            })
          }
        >
          {({
            handleChange,
            handleSubmit,
            values,
            setFieldValue,
            errors,
            touched,
            isValid,
            isSubmitting,
            setSubmitting,
          }) => (
            <Wrapper>
              <MainContainer>
                <LogoContainer>
                  <Logo />
                </LogoContainer>
                <ContentContainer>
                  <TextContainer>
                    <TextStyled>Seja bem-vindo ao novo aplicativo Super Cartões.</TextStyled>
                  </TextContainer>
                  <TextContainer>
                    <TextStyled>
                      Estamos de cara nova para mehorar a sua experiência.
                    </TextStyled>
                    <TextStyled>
                      Ficou mais fácil consultar o saldo do seu cartão
                      Superdigital
                    </TextStyled>
                  </TextContainer>
                  <TextContainer>
                    <TextStyled>Entre e aproveite.</TextStyled>
                  </TextContainer>
                  <TextContainer>
                    <TextStyled>Para começar, precisamos validar o seu celular.</TextStyled>
                  </TextContainer>
                </ContentContainer>
              </MainContainer>
              <InputContainer>
                <InputText
                  placeholder="Informe o número de seu celular"
                  keyboardType="numeric"
                  error={touched.phoneNumber && errors && errors.phoneNumber}
                  value={values.phoneNumber}
                  onChangeText={(value) => this.handlePhoneNumberChange(value, setFieldValue)}
                  onBlur={() => this.handlePhoneNumberBlur(values.phoneNumber, setFieldValue)}
                  maxLength={15}
                />
              </InputContainer>
              <ButtonContainer>
                {isSubmitting ?
                  <ActivityIndicator />
                  :
                  <Button
                    onPress={() => handleSubmit()}
                    disabled={!isValid || isSubmitting}
                    title="Enviar"
                  />
                }
              </ButtonContainer>
              <BottomContainer>
                <Text>Uma fintech</Text>
                <SantanderLogo source={require('../../assets/logo-santander.png')} />
              </BottomContainer>
            </Wrapper>
          )}
        </Formik>
      </KeyboardAvoidingView>
    )
  }
}

export default withTemplate(Welcome)
