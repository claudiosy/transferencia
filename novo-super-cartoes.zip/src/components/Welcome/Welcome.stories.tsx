import * as React from 'react'
import { storiesOf } from '@storybook/react-native'
import { action } from '@storybook/addon-actions'
import Welcome from './Welcome'

const navigation = {
  navigate: action('Navigate')
}

 storiesOf('Welcome', module)
  .add('default', () => (
    <Welcome navigation={navigation} />
  ))