import * as React from 'react'
import styled, { css } from 'styled-components/native'
import { NavigationScreenProps } from 'react-navigation'
import { FlatList, AsyncStorage } from 'react-native'
import moment from 'moment'
import Text from '../common/Text/Text'
import Logo from '../common/Logo/Logo'
import { colors, fontSizes } from '../../theme/theme'
import Icon from '../common/Icon/Icon'
import {
  getBankStatementData,
  getCardData,
  // getAccountCurrencyData
  BankStatementResponse,
  CardDataResponse,
} from '../../api/bankStatement'
import { STATUS_CODE, ApiReturn } from '../../api/types'

// **************************************************
// ***** Constants
// **************************************************
const HEADER_TITLE = {
  date: 'Data',
  history: 'Histórico',
  currency: 'Moeda',
  cost: 'Valor',
}
// **************************************************
// ***** Styled Components
// **************************************************
const Wrapper = styled.View`
  height: 100%;
  width: 100%;
  flex-direction: column;
`

const HeaderContainer = styled.View`
  flex-direction: row;
  width: 100%;
`

const CenterContainer = css`
  justify-content: center;
  align-items: center;
  align-self: center;
`

const AccountDetails = styled.View`
  ${CenterContainer} flex: 1;
  background-color: ${colors.background.primary};
  width: 100%;
`

const AccountItemContainer = styled.View`
  margin: 5px;
`

const DisclaimerContainer = styled.View`
  margin-top: 15px;
`

const ListContainer = styled.View`
  background-color: ${colors.white};
  flex: 3;
  width: 100%;
`

const ItemContainer = styled.View`
  width: 100%;
  flex-direction: row;
  justify-content: flex-start;
  align-items: flex-start;
`

const Item = styled.View`
  flex-wrap: wrap;
  flex: 1;
  margin: 5px;
`

const LargeItem = styled(Item)`
  flex: 3;
`

const CloseIconButton = styled.TouchableOpacity`
  position: absolute;
  right: 10;
  top: 10;
`

const LogoContainer = styled.View`
  position: absolute;
  left: 10;
  top: 10;
`

const LogoStyled = styled(Logo)`
  width: 60px;
  height: 45px;
`

const TextCentered = styled(Text)`
  text-align: center;
  font-weight: 600;
`

const RetryButton = styled.TouchableOpacity`
  flex-direction: row;
  flex-wrap: wrap;
`

// **************************************************
// ***** Interfaces
// **************************************************
interface NavigationProps {
  authorization: string
}

export interface BankStatementProps {
  navigation: NavigationScreenProps<NavigationProps>
}

interface State {
  bankStatementData: ApiReturn<BankStatementResponse>
  cardData: ApiReturn<CardDataResponse>
}

// **************************************************
// ***** Component
// **************************************************
class BankStatement extends React.PureComponent<BankStatementProps, State> {
  // **************************************************
  // ***** Life Cycle
  // **************************************************
  constructor(props: BankStatementProps) {
    super(props)

    this.state = {
      bankStatementData: {
        status: null,
        response: null,
      },
      cardData: {
        status: null,
        response: null,
      },
    }
  }

  async componentDidMount() {
    const { authorization } = this.props.navigation.state.params
    const bankStatementData = await this.fetchBankStatementData({
      authorization,
    })
    const cardData = await this.fetchCardData({ authorization })

    await AsyncStorage.setItem(
      'CARD_NUMBER',
      cardData.response.NumeroCartaoMascarado
    )

    this.setState({
      bankStatementData,
      cardData,
    })
  }

  // **************************************************
  // ***** Logic
  // **************************************************
  fetchBankStatementData = ({ authorization }) =>
    getBankStatementData({ authorization })
  fetchCardData = ({ authorization }) => getCardData({ authorization })
  keyExtractor = (item, index) => item.id
  signOut = () => this.props.navigation.replace('Login')
  isValidStatus = (object: { response?: any; status: string }) =>
    object.response && object.response !== STATUS_CODE.ERROR

  // **************************************************
  // ***** Render
  // **************************************************
  renderHeader = () => {
    /*
    const { response } = this.state.bankStatementData;

    const data = response.statementData[0];
    if (!data) return null;
    return (
      <HeaderContainer>
        {
          Object.keys(data).map((item, index) => {
            if (!HEADER_TITLE[item]) return null;

            return HEADER_TITLE[item] === HEADER_TITLE.history ?
              <LargeItem key={index}>
                <TextCentered color={colors.black}>{HEADER_TITLE[item]}</TextCentered>
              </LargeItem>
            :
              <Item key={index}>
                <TextCentered color={colors.black}>{HEADER_TITLE[item]}</TextCentered>
              </Item>
          })
        }
      </HeaderContainer>
    )
    */
    const { response } = this.state.bankStatementData
    const data = response.statementData[0]
    if (!data) return null

    const headerTitle = ['date', 'history', 'currency', 'cost']
    return (
      <HeaderContainer>
        {headerTitle.map((item, index) => {
          if (!HEADER_TITLE[item]) return null

          return HEADER_TITLE[item] === HEADER_TITLE.history ? (
            <LargeItem key={index}>
              <TextCentered color={colors.black}>
                {HEADER_TITLE[item]}
              </TextCentered>
            </LargeItem>
          ) : (
            <Item key={index}>
              <TextCentered color={colors.black}>
                {HEADER_TITLE[item]}
              </TextCentered>
            </Item>
          )
        })}
      </HeaderContainer>
    )
  }
  renderItem = ({ item }) => {
    const { id, date, history, cost } = item
    const { SiglaMoeda, SimboloMoeda } = this.state.cardData.response

    return (
      <ItemContainer key={id}>
        <Item>
          <Text fontSize={fontSizes.small} color={colors.black}>{moment(date).format('DD-MM')}</Text>
        </Item>
        <LargeItem>
          <Text fontSize={fontSizes.small} color={colors.black}>{history}</Text>
        </LargeItem>
        <Item>
          <Text fontSize={fontSizes.small} color={colors.black}>{SiglaMoeda}</Text>
        </Item>
        <Item>
          <Text fontSize={fontSizes.small} color={colors.black}>{SimboloMoeda + cost}</Text>
        </Item>
      </ItemContainer>
    )
  }

  renderRetry = (onPress: () => void) => (
    <RetryButton onPress={onPress}>
      <Text>Erro. Tentar novamente</Text>
      <Icon name="refresh" size="small" />
    </RetryButton>
  )

  render() {
    const { bankStatementData, cardData } = this.state

    if (!this.isValidStatus(bankStatementData)) {
      return (
        <Wrapper>
          <Text>Nenhum registro encontrado.</Text>
        </Wrapper>
      )
    }

    const { statementData, totalItems } = bankStatementData.response

    const hasCardData = this.isValidStatus(cardData)

    const {
      SimboloMoeda,
      SaldoDisponivel,
      NumeroCartaoMascarado,
    } = cardData.response
    const balance = hasCardData && `${SimboloMoeda + SaldoDisponivel}`
    const cardNumber = hasCardData && `${NumeroCartaoMascarado}`

    return (
      <Wrapper>
        <AccountDetails>
          {hasCardData ? (
            <React.Fragment>
              <AccountItemContainer>
                <Text>{`Saldo: ${balance}`}</Text>
              </AccountItemContainer>
              <AccountItemContainer>
                <Text>{cardNumber}</Text>
              </AccountItemContainer>
            </React.Fragment>
          ) : (
            this.renderRetry(() => this.fetchCardData)
          )}

          <DisclaimerContainer>
            <Text>{`Exibindo os últimos ${totalItems} lançamentos`}</Text>
          </DisclaimerContainer>
          <LogoContainer>
            <LogoStyled />
          </LogoContainer>
          <CloseIconButton onPress={() => this.signOut()}>
            <Icon name="close" size="small" />
          </CloseIconButton>
        </AccountDetails>
        <ListContainer>
          <FlatList
            keyExtractor={this.keyExtractor}
            data={statementData}
            renderItem={this.renderItem}
            ListHeaderComponent={this.renderHeader}
          />
        </ListContainer>
      </Wrapper>
    )
  }
}

export default BankStatement
