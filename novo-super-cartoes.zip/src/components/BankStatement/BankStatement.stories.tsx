import * as React from 'react'
import { storiesOf } from '@storybook/react-native'
import { action } from '@storybook/addon-actions'
import styled from 'styled-components/native'
import BankStatement from './BankStatement'

const Wrapper = styled.View`
  flex: 1;
  justify-content: center;
  align-items: center;
  height: 100%;
`

const statementData = [
  {
    id: '001',
    date: new Date(),
    history: 'Transferência (Mobile) para Lorem Ipsum',
    currency: 'BRL',
    cost: 'R$ -10,00'
  },
  {
    id: '002',
    date: new Date(),
    history: 'Dinheiro enviado por Lorem Ipsum',
    currency: 'BRL',
    cost: 'R$ 100,00'
  },
  {
    id: '003',
    date: new Date(),
    history: 'Transferência (Mobile) para Lorem Ipsum',
    currency: 'BRL',
    cost: 'R$ -20,00'
  },
  {
    id: '004',
    date: new Date(),
    history: 'Transferência (Mobile) para Lorem Ipsum',
    currency: 'BRL',
    cost: 'R$ -5,00'
  }
]

const balance = 'R$ 65,00'

const cardNumber = '9876 54XX XXXX 3210'

const totalItems = 20

 storiesOf('BankStatement', module)
   .add('default', () => (
     <Wrapper>
       <BankStatement
          navigation={{
            state: {
              params: {
                cardNumber,
                balance,
                statementData,
                totalItems,
              }
            }
          }}
       />
    </Wrapper>
 ))