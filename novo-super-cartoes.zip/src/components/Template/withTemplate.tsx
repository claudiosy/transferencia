import * as React from 'react'
import Template from './Template';

// **************************************************
// ***** Components
// **************************************************

const withTemplate = <P extends object>(Component: React.ComponentType<P>) => {
 // **************************************************
 // ***** Render
 // **************************************************
  return class TemplateComponent extends React.PureComponent<P> {
    render() {
      return (
        <Template>
          <Component {...this.props} />
        </Template>
      )
    }
  }
}

export { withTemplate }