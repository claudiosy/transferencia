import * as React from 'react';
import { KeyboardAvoidingView, Platform, AsyncStorage, Alert } from 'react-native'
import styled from 'styled-components/native'
import { NavigationScreenProps } from 'react-navigation';
import Text from '../common/Text/Text'
import Logo from '../common/Logo/Logo'
import LoginForm from '../LoginForm/LoginForm'
import { withTemplate } from '../Template/withTemplate';
import { authenticateAccount } from '../../api/authentication'

import { STATUS_CODE } from '../../api/types';

/**************************************************
***** Styled Components
**************************************************/
const Wrapper = styled.View`
  flex: 1;
  flex-direction: column;
  justify-content: space-between;
  padding: 10px;
` 

const MarginContainer = styled.View`
  margin: 10px;
`

const MainContainer = styled(MarginContainer)``

const LogoContainer = styled.View`
  margin: 10px;
`

const ContentContainer = styled.View`
  flex-direction: column;
`

const BottomContainer = styled(MarginContainer)`
  align-items: center;
  flex-direction: row;
  justify-content: flex-end;
`

const SantanderLogo = styled.Image`
  height: 30px
  width: 100px;
  margin: 0 5px;
`

/**************************************************
***** Interfaces
**************************************************/
interface State {
  cardNumber: string
}
interface LoginProps {
  navigation: NavigationScreenProps<any>
}

/**************************************************
***** Component
**************************************************/
class Login extends React.PureComponent<LoginProps, State> {
  static navigationOptions = {
    header: null
  }

  /**************************************************
  ***** Life Cycle
  **************************************************/
  constructor(props) {
    super(props)

    this.state = {
      cardNumber: null
    }
  }

  async componentDidMount() {
    const cardNumber = await AsyncStorage.getItem('CARD_NUMBER')
    this.setState({ cardNumber })
  }

  /**************************************************
  ***** Handlers
  **************************************************/
  submitHandler = async ({ cardNumber, password }: { cardNumber: string, password: string }) => {
    const authentication = await authenticateAccount({ login: cardNumber, password })
    /*
    if (authentication.status === STATUS_CODE.ERROR) {
      Alert.alert('Erro', authentication.message);
      return null;
    }

    const { authorization } = authentication.response.headers
    */
   const authorization = '000'
    this.props.navigation.navigate('BankStatement', { authorization })

  }

  /**************************************************
  ***** Render
  **************************************************/
  render() {
    return (
      <KeyboardAvoidingView
        behavior={(Platform.OS === 'ios') ? 'padding' : 'position'}
        keyboardVerticalOffset={Platform.select({ ios: 0, android: -50 })}
      >
        <Wrapper>
          <MainContainer>
            <LogoContainer>
              <Logo />
            </LogoContainer>
            <ContentContainer>
              <Text>Consulte o saldo e extrato do seu cartão Superdigital</Text>
            </ContentContainer>
            <LoginForm
              cardNumber={this.state.cardNumber}
              onSubmit={(values) => this.submitHandler(values)}
            />
          </MainContainer>
          <BottomContainer>
            <Text>Uma fintech</Text>
            <SantanderLogo source={require('../../assets/logo-santander.png')} />
          </BottomContainer>
        </Wrapper>
      </KeyboardAvoidingView>
    )
  }
}

export default withTemplate(Login);