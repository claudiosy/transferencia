import * as React from 'react'
import { ImageProps, Image } from 'react-native'
import styled from 'styled-components/native'

/**************************************************
***** Styled Components
**************************************************/
const Wrapper = styled.View`
  align-items: center;
  justify-content: center;
  padding: 10px;
`

/**************************************************
***** Component
**************************************************/
const Logo = (props: Partial<ImageProps>) => (
  <Wrapper>
    <Image {...props} source={require('../../../assets/logo-superdigital.png')} />
  </Wrapper>
)

export default Logo;