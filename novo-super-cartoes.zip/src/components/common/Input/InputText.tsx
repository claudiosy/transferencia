import * as React from 'react'
import styled from 'styled-components/native'

import InputErrorText from "./InputErrorText"

import { colors } from '../../../theme/theme'
import { TextInputProps } from 'react-native';

/**************************************************
***** Styled Components
**************************************************/
const InputContainer = styled.View`
  flex-direction: column;
  alignSelf: stretch;
`
const TextFieldStyled = styled.TextInput.attrs({
  placeholderTextColor: colors.text,
})`
  height: 40px;
  background: ${colors.none};
  color: ${colors.text};
  border-bottom-width: 1px;
  border-color: ${colors.white};
`
/**************************************************
***** Interfaces
**************************************************/
export interface InputProps {
  placeholder?: string
  label?: string
  name?: string
  value?: string
  onChange?: () => void
  error?: string
}

/**************************************************
***** Component
**************************************************/
const Input = ({
  placeholder,
  label,
  name,
  value,
  onChange,
  error,
  ...props
}: InputProps & TextInputProps) => (
  <InputContainer>
    <TextFieldStyled
      placeholder={placeholder}
      value={value}
      onChange={onChange}
      {...props}
    />
    <InputErrorText error={error ? error : ''}/>
  </InputContainer>
)

export default Input
