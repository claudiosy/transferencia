import * as React from 'react'
import { storiesOf } from '@storybook/react-native'
import { action } from '@storybook/addon-actions'
import InputOutlined from './InputOutlined'
import InputText from './InputText'
import Template from '../../Template/Template'

 storiesOf('Input', module)
 .add('Default', () => (
  <Template>
    <InputText
       placeholder='Número do cartão'
       label='Número do cartão'
       name='cardNumber'
       onChange={action('Changed')}
       error='Cartão obrigatório'
    />
 </Template>
))
   .add('Outlined', () => (
     <Template>
       <InputOutlined
          placeholder='Número do cartão'
          label='Número do cartão'
          name='cardNumber'
          onChange={action('Changed')}
          error='Cartão obrigatório'
       />
    </Template>
 ))