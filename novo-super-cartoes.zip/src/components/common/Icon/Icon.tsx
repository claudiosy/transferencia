import * as React from 'react'
import Icon from 'react-native-vector-icons/FontAwesome'
import styled from 'styled-components/native'
import { colors, icons } from '../../../theme/theme'

// **************************************************
// *****  Styled Components
// **************************************************
const Wrapper = styled.View`
  justify-content: center;
  align-items: center;
`
const StyledIcon = styled(Icon)`
  color: ${colors.primary};
`

// **************************************************
// *****  Interfaces
// **************************************************
interface Props extends Partial<React.StatelessComponent> {
  name: string
  className?: string
  size?: 'small' | 'medium' | 'large'
}

// **************************************************
// ***** Component
// **************************************************
const IconComponent = ({ name, className, size, ...props }: Props) => (
  <Wrapper>
    <StyledIcon name={name} size={size ? icons[size] : icons.medium} className={className} {...props} />
  </Wrapper>
)

export default IconComponent
