import * as React from 'react'
import { storiesOf } from '@storybook/react-native'
import Icon from './Icon'
import Template from '../../Template/Template'

 storiesOf('Icon', module)
  .add('small', () => (
    <Template>
      <Icon name='user' size={'small'} />
    </Template>
  ))
  .add('default', () => (
    <Template>
      <Icon name='user' />
    </Template>
  ))
  .add('large', () => (
    <Template>
      <Icon name='user' size={'large'} />
    </Template>
  ))