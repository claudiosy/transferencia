import * as React from 'react'
import { KeyboardAvoidingView, Platform, Alert } from 'react-native'
import styled, { css } from 'styled-components/native'
import { NavigationScreenProps } from 'react-navigation';
import { Formik } from 'formik'
import * as Yup from 'yup'
import Text from '../common/Text/Text'
import InputText from '../common/Input/InputText'
import { colors } from '../../theme/theme';
import { countDown } from '../../helpers/helpers';
import Button from '../common/Button/Button'
import Icon from '../common/Icon/Icon'
import { validatePhoneCode } from '../../api/validatePhoneCode'
import { authenticateAccount } from '../../api/authentication'

import { STATUS_CODE } from '../../api/types';

/**************************************************
***** Contants
*************************************************/
const MINUTES_LEFT = 5;

/**************************************************
 ***** Styled Components
 **************************************************/
const Wrapper = styled.View`
  padding: 10px;
  height: 100%;
  width: 100%;
`

const MarginContainer = css`
  margin: 10px;
`

const CenterContainer = css`
  justify-content: center;
  align-items: center;
  align-self: center;
`

const TopContainer = styled.View`
  ${MarginContainer}
  flex: 1;
  flex-direction: row;
  justify-content: center;
`

const CounterContainer = styled.View`
  ${CenterContainer}
  ${MarginContainer}
  flex: 1;
`

const InputContainer = styled.View`
  ${CenterContainer}
  flex-direction: column;
  flex: 1;
  width: 90%;
`
const ExpiredContainer = styled.View`
  ${CenterContainer}
  margin: 10px;
  flex-direction: column;
`

const TextContainer = styled.View`
  margin: 10px 0;
`

const TextStyled = styled(Text)`
  text-align: center;
`

const InputStyled = styled(InputText)`
  border-color: ${colors.black}${colors.opacity.p20};
  color: ${colors.black};
`

const PhoneIcon = styled.View`
  margin-right: 15px;
`

const CloseIconButton = styled.TouchableOpacity`
  position: absolute;
  right: 5;
`;

const ButtonStyled = styled(Button)`
  margin-top: 10px;
`

/**************************************************
 ***** Interfaces
 **************************************************/
interface NavigationProps {
  phoneNumber: string
}

interface PhoneNumberValidationProps {
  navigation: NavigationScreenProps<NavigationProps>
}

interface State {
  timeLeft: string
  hasTimedOut: boolean
}
/**************************************************
 ***** Component
 **************************************************/
class Welcome extends React.PureComponent<PhoneNumberValidationProps, State> {
  timer;

  static navigationOptions = {
    header: null,
  }

  constructor(props) {
    super(props)
    this.state = {
      timeLeft: null,
      hasTimedOut: false,
    }
  }

  componentDidMount() {
    this.setTimer()
  }

  /**************************************************
  ***** Handlers
  **************************************************/
  refreshButton = () => {
    this.setState({
      hasTimedOut: false,
    })
    this.setTimer();
  }

  submitHandler = async ({ validationCode }: { validationCode: string }) => {
    const { phoneNumber } = this.props.navigation.state.params
    /*
    validatePhoneCode({ phoneCode: validationCode, phoneNumber })
    const validateCode = await validatePhoneCode({ phoneCode: validationCode, phoneNumber })
    
    if (validateCode.status === STATUS_CODE.ERROR) {
      Alert.alert('Erro', validateCode.message);
      return null;
    }
    */
   const authorization = '000'
   this.clearTimer();
   this.props.navigation.navigate('BankStatement', { authorization })
  }

  handleGoBack = () => {
    this.clearTimer()
    this.goBack()
  }
  /**************************************************
  ***** Logic
  **************************************************/
  setTimer = () => {
    this.timer = countDown({
      minutesLeft: MINUTES_LEFT,
      onTimeUpdate: (timeLeft: string) => {
        this.setState({ timeLeft })
      },
      onFinish: () => {
          this.setState({ hasTimedOut: true });
      },
    });
  }
  clearTimer = () => clearInterval(this.timer);
  goBack = () => this.props.navigation.replace('Welcome')

  /**************************************************
   ***** Render
   **************************************************/
  render() {
    const { timeLeft, hasTimedOut } = this.state;
    return (
      <KeyboardAvoidingView
        behavior={Platform.OS === 'ios' ? 'padding' : 'position'}
        keyboardVerticalOffset={Platform.select({ ios: 0, android: -200 })}
      >
        <Formik
          initialValues={{
            validationCode: '',
          }}
          onSubmit={values => this.submitHandler(values)}
          validationSchema={() =>
            Yup.object().shape({
              validationCode: Yup.number().required('Informe o código de validação'),
            })
          }
        >
          {({
            handleChange,
            values,
            errors,
            touched,
            isValid,
            isSubmitting,
            submitForm,
          }) => (
            <Wrapper>
              <TopContainer>
                <PhoneIcon>
                  <Icon name='mobile' />
                </PhoneIcon>
                <TextStyled color={colors.black}>Tempo para validação</TextStyled>
                <CloseIconButton onPress={() => this.handleGoBack()}>
                  <Icon name='close' size='small' />
                </CloseIconButton>
              </TopContainer>
              <CounterContainer>
                <TextStyled fontSize={60} color={colors.black}>{timeLeft}</TextStyled>
                {hasTimedOut &&
                  <ExpiredContainer>
                    <TextStyled color={colors.error}>Tempo expirado.</TextStyled>
                    <ButtonStyled textColor={`${colors.black + colors.opacity.p20}`} onPress={() => this.refreshButton()} title='Enviar novo token' />
                  </ExpiredContainer>
                }
              </CounterContainer>
              <InputContainer>
                <TextContainer>
                  <TextStyled color={colors.black}>Digite o código de validação que você recebeu por SMS.</TextStyled>
                </TextContainer>
                <InputStyled
                  placeholder=""
                  keyboardType="numeric"
                  error={touched.validationCode && errors && errors.validationCode}
                  value={values.validationCode}
                  onChangeText={handleChange('validationCode')}
                  editable={!hasTimedOut}
                  onBlur={() => isValid && !isSubmitting && submitForm()}
                />
              </InputContainer>
            </Wrapper>
          )}
        </Formik>
      </KeyboardAvoidingView>
    )
  }
}

export default Welcome
