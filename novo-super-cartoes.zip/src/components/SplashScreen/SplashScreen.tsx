import * as React from 'react'
import { AsyncStorage, ActivityIndicator } from "react-native"
import { NavigationScreenProps } from 'react-navigation';
import { withTemplate } from '../Template/withTemplate';

// **************************************************
// ***** Interfaces
// **************************************************
export interface SplashScreenProps {
  navigation: NavigationScreenProps
}

interface State {}

// **************************************************
// ***** Component
// **************************************************
class SplashScreen extends React.PureComponent<SplashScreenProps, State> {
 // **************************************************
 // ***** Life Cycle
 // **************************************************
 constructor(props) {
  super(props)
  this.state = {
    initialRouteName: 'SplashScreen'
  }
}

async componentDidMount() {
  // await AsyncStorage.setItem('CARD_NUMBER', '') 
  const initialRouteName = await AsyncStorage.getItem('CARD_NUMBER') ? 'Login' : 'Welcome'
  this.props.navigation.navigate(initialRouteName);
}
 // **************************************************
 // ***** Render
 // **************************************************
  render() {
    return (
      <ActivityIndicator />
    )
  }
}

export default withTemplate(SplashScreen)