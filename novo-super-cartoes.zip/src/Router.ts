import * as React from 'react';
import { createStackNavigator, createSwitchNavigator } from 'react-navigation';
import { SHOW_STORYBOOK } from 'react-native-dotenv';

import Welcome from './components/Welcome/Welcome';
import Login from './components/Login/Login';
import PhoneNumberValidation from './components/PhoneNumberValidation/PhoneNumberValidation';
import BankStatement from './components/BankStatement/BankStatement';
import SplashScreen from './components/SplashScreen/SplashScreen';
import Storybook from '../storybook';

const FirstAccessStack = createStackNavigator(
  {
    Welcome: {
      screen: Welcome,
    },
    Login: {
      screen: Login,
    },
    PhoneNumberValidation: {
      screen: PhoneNumberValidation,
    },
    BankStatement: {
      screen: BankStatement,
    },
  },
  {
    initialRouteName: 'Welcome',
    headerMode: 'none',
    navigationOptions: {
      headerVisible: false,
    }
  }
);

const LoginStack = createStackNavigator(
  {
    Welcome: {
      screen: Welcome,
    },
    Login: {
      screen: Login,
    },
    PhoneNumberValidation: {
      screen: PhoneNumberValidation,
    },
    BankStatement: {
      screen: BankStatement,
    },
  },
  {
    initialRouteName: 'Login',
    headerMode: 'none',
    navigationOptions: {
      headerVisible: false,
    }
  }
);

const StorybookStack = createStackNavigator(
  {
    Storybook: {
      screen: Storybook,
    },
  },
  {
    initialRouteName: 'Storybook',
    headerMode: 'none',
    navigationOptions: {
      headerVisible: false,
    }
  }
);

export default createSwitchNavigator(
  {
    SplashScreen: SplashScreen,
    FirstAccessStack: FirstAccessStack,
    LoginStack: LoginStack,
    StorybookStack: StorybookStack,
  },
  {
    // initialRouteName: SHOW_STORYBOOK ? 'Storybook' : 'SplashScreen',
    initialRouteName: 'SplashScreen',
  }
);