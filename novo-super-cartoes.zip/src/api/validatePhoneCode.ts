import { API_URL, ENV } from 'react-native-dotenv';
import { STATUS_CODE, ApiReturn } from './types'

const mockStatementData = {
  response: {
    Sucesso: true,
    Dados: {},
  },
  status: STATUS_CODE.SUCCESS,
  message: null,
}

interface ValidatePhoneCodeProps {
  phoneCode: string
  phoneNumber: string
}

interface PhoneCodeReturn {
  Sucesso: boolean
  Dados: object
}

export const validatePhoneCode = async ({ phoneNumber, phoneCode }: ValidatePhoneCodeProps): Promise<ApiReturn<PhoneCodeReturn>> => {
  if (ENV === 'dev') {
    return mockStatementData;
  }

  const body = {
    Celular: phoneNumber,
    Email: "mock@email.com",
    FinalidadeToken: 13,
    FormaEnvioToken: 1,
    Token: phoneCode    
  }

  try {
    const response = await fetch(`${API_URL}/api/seguranca/token/off/validar/individual`, {
      method: 'post',
      body: JSON.stringify(body),
      headers: new Headers({
        'Content-Type': 'application/json',
        'SD-Platform': 'Mobile.iOS',
        'Accept': 'application/json',
        'SD-Language': 'pt_BR',
        'SD-Id': 'b683e8d8066124a9ff6d7b398ec4e0f2'
      }),
    })
    const { data } = await response.json()
    return { status: STATUS_CODE.SUCCESS, response: data }
  } catch(error) {
    return { status: STATUS_CODE.ERROR, message: error }
  }
}