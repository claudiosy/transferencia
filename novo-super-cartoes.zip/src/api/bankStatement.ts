import moment from 'moment'
import { API_URL, ENV } from 'react-native-dotenv';
import { STATUS_CODE, ApiReturn } from './types'

const mockCardData = {
  response: {
    NomePortador: "Lorem Ipsum",
    StatusCartao: "01",
    TipoIndividualizacaoId: 0,
    NumeroCartaoMascarado: "XXXX XXXX XXXX 9999",
    SiglaMoeda: "BRL",
    SimboloMoeda: "R$",
    MoedaID: 1,
    SaldoDisponivel: 0,
    CartaoId: 1234567,
    DataValidade: "2024-12-31T00:00:00",
    ModalidadeId: 3,
    ParaTerceiros: false,
    Apelido: "Lorem Ipsum",
    PossuiChip: false,
    ContaCorrenteId: 9876543
  },
  status: STATUS_CODE.SUCCESS,
}

const mockStatementData = {
  response: {
    statementData: [
      {
        id: '001',
        date: new Date(),
        history: 'Transferência (Mobile) para Lorem Ipsum',
        cost: '-10,00'
      },
      {
        id: '002',
        date: new Date(),
        history: 'Dinheiro enviado por Lorem Ipsum',
        cost: '100,00'
      },
      {
        id: '003',
        date: new Date(),
        history: 'Transferência (Mobile) para Lorem Ipsum',
        cost: '-20,00'
      },
      {
        id: '004',
        date: new Date(),
        history: 'Transferência (Mobile) para Lorem Ipsum',
        cost: '-5,00'
      }
    ],
    totalItems: 20,
  },
  status: STATUS_CODE.SUCCESS,
}

interface AccountProps {
  deviceId?: string
  cardNumber?: string
  authorization?: string
}

export interface BankStatementResponse {
  statementData: any,
  totalItems: number
}

export interface CardDataResponse {
  NomePortador: string
  StatusCartao: string
  TipoIndividualizacaoId: number
  NumeroCartaoMascarado: string
  SiglaMoeda: string
  SimboloMoeda: string
  MoedaID: number
  SaldoDisponivel: number
  CartaoId: number
  DataValidade: string
  ModalidadeId: number
  ParaTerceiros: boolean
  Apelido: string
  PossuiChip: boolean
  ContaCorrenteId: number
}


export const getBankStatementData = async ({ authorization, cardNumber }: AccountProps): Promise<ApiReturn<BankStatementResponse>> => {
  if (ENV === 'dev') {
    return mockStatementData;
  }

  const currentDate = new Date();
  const lastThirdyDays =  new Date().setDate(currentDate.getDate() - 30);

  try {
    const response = await fetch(`${API_URL}/api/cartao/${cardNumber}/extrato/${moment(currentDate).format('YYYY-MM-DD')}/${moment(lastThirdyDays).format('YYYY-MM-DD')}`, {
      method: 'GET',
      headers: new Headers({
        'Content-Type': 'application/json',
        'SD-Platform': 'Mobile.iOS',
        'Accept': 'application/json',
        'SD-Language': 'pt_BR',
        'SD-Id': 'b683e8d8066124a9ff6d7b398ec4e0f2',
        'Authorization': authorization
      }),
    })
    const { data } = await response.json()
    return { status: STATUS_CODE.SUCCESS, response: data }
  } catch (error) {
    return { status: STATUS_CODE.ERROR, response: error }
  }
}

export const getCardData = async ({ authorization }: AccountProps): Promise<ApiReturn<CardDataResponse>> => {
  if (ENV === 'dev') {
    return mockCardData;
  }

  try {
    const response = await fetch(`${API_URL}/api/cartao/1/obterCartoes/1`, {
      method: 'GET',
      headers: new Headers({
        'Content-Type': 'application/json',
        'SD-Platform': 'Mobile.iOS',
        'Accept': 'application/json',
        'SD-Language': 'pt_BR',
        'SD-Id': 'b683e8d8066124a9ff6d7b398ec4e0f2',
        'Authorization': authorization,
      }),
    })
    const { data } = await response.json()
    return { status: STATUS_CODE.SUCCESS, response: data }
  } catch (error) {
    return { status: STATUS_CODE.ERROR, response: error }
  }
}
