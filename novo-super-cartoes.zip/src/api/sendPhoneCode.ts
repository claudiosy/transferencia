import { API_URL } from 'react-native-dotenv';

import { generateToken } from "../helpers/helpers";

import { STATUS_CODE } from './types';

interface SendPhoneCodeProps {
  phoneNumber: string
}

export const sendPhoneCode = async ({ phoneNumber }: SendPhoneCodeProps) => {
  const data = {
    Celular: phoneNumber,
    Email: "mock@email.com",
    Finalidade: 13,
	  FormaEnvio: 1  
  }

  try {
    const response = await fetch(`${API_URL}/seguranca/token/off/enviar`, {      
      method: 'POST',
      body: JSON.stringify(data),
      headers: new Headers({
        'Content-Type': 'application/json',
        'SD-Platform': 'Mobile.iOS',
        'Accept': 'application/json',
        'SD-Language': 'pt_BR',
        'SD-Id': 'b683e8d8066124a9ff6d7b398ec4e0f2'
      }),
    })
    return { status: STATUS_CODE.SUCCESS, message: response.json() }
  } catch(error) {
    return { status: STATUS_CODE.ERROR, message: error }
  }
}