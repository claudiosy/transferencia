export enum STATUS_CODE {
  SUCCESS = 'success',
  ERROR = 'error',
}

export interface ApiReturn<T> {
  response?: T
  status: string
  message?: string
}