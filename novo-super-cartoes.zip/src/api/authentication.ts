import DeviceInfo from 'react-native-device-info';
import { API_URL, ENV } from 'react-native-dotenv';
import { STATUS_CODE, ApiReturn } from './types'

const mockStatementData = {
  response: {
    Sucesso: true,
    Dados: {},
    headers: {
      authorization: 'bearer 99999'
    }
  },
  status: STATUS_CODE.SUCCESS,
  message: null,
}

interface AuthenticateProps {
  login: string
  password: string
}

interface AuthenticateResponse {
  Sucesso: boolean
  Dados: object
  headers: {
    authorization: string
  }
}

export const authenticateAccount = async ({ login, password }: AuthenticateProps): Promise<ApiReturn<AuthenticateResponse>> => {
  if (ENV === 'dev') {
    return mockStatementData;
  }

  const body = {
    "CPF": login,
    "Senha": password
  }

  try {
    const response = await fetch(`${API_URL}/api/autenticacao`, {
      method: 'POST',
      body: JSON.stringify(body),
      headers: new Headers({
        'Content-Type': 'application/json',
        'SD-Platform': 'Mobile.iOS',
        'Accept': 'application/json',
        'SD-Language': 'pt_BR',
        'SD-Id': 'b683e8d8066124a9ff6d7b398ec4e0f2',
      }),
    })
    const { data } = await response.json()
    return { status: STATUS_CODE.SUCCESS, response: data }
  } catch (error) {
    return { status: STATUS_CODE.ERROR, message: error }
  }
}

export const authenticateAccountWithCard = async ({ login, password }: AuthenticateProps): Promise<ApiReturn<AuthenticateResponse>> => {
  if (ENV === 'dev') {
    return mockStatementData;
  }

  const body = {
    "deviceId": DeviceInfo.getUniqueID(),
    "numeroCartao": login,
    "senha": password
  }

  try {
    const response = await fetch(`${API_URL}/cartao/validardados`, {
      method: 'POST',
      body: JSON.stringify(body),
      headers: new Headers({
        'Content-Type': 'application/json',
        'SD-Platform': 'Mobile.iOS',
        'Accept': 'application/json',
        'SD-Language': 'pt_BR',
        'SD-Id': 'b683e8d8066124a9ff6d7b398ec4e0f2',
      }),
    })
    const { data } = await response.json()
    return { status: STATUS_CODE.SUCCESS, response: data }
  } catch (error) {
    return { status: STATUS_CODE.ERROR, message: error }
  }
}