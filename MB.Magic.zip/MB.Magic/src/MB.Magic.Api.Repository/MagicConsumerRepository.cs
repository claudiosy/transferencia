using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using MB.Magic.Api.Domain.Models;
using MB.Magic.Api.Domain.Repository;
using MongoDB.Driver;

namespace MB.Magic.Api.Repository
{    
    public class MagicConsumerRepository : IMagicConsumerRepository
    {
        const string MONGO_DATABASE = "mb_magic_api";
        const string MONGO_COLLECTION = "magic";
        private readonly IMongoClient _client;
        private readonly IMongoCollection<MagicModel> _collection;

        public MagicConsumerRepository(IMongoClient client)
        {
            _client = client;
            IMongoDatabase database = _client.GetDatabase(MONGO_DATABASE);
            _collection = database.GetCollection<MagicModel>(MONGO_COLLECTION);
        }
        public async Task Save(MagicModel value)
        {
            await _collection.ReplaceOneAsync(doc => doc.Id == value.Id, value, new ReplaceOptions{ IsUpsert = true  });
        }
    }
}