using System;
using System.Diagnostics;
using System.Threading.Tasks;
using MB.Magic.Api.Domain.Models;
using MB.Magic.Api.Domain.Repository;
using Microsoft.Extensions.Logging;
using Modal.Extensions.ADO;
using MongoDB.Driver;

namespace MB.Magic.Api.Repository
{
    public class MagicApiRepository : IMagicApiRepository
    {
        const string SQL = "SELECT REQUEST_ROUTE_URI, REQUEST_METHOD, REQUEST_HEADER_KEY, REQUEST_IP, REQUEST_DATE, RESPONSE_STATUSCODE, ACCOUNT FROM TAGGING_REQUEST";
        const string MONGO_DATABASE = "mb_magic_api";
        const string MONGO_COLLECTION = "magic";
        private readonly ILogger<MagicApiRepository> _logger;
        private readonly IMongoClient _client;
        private readonly IMongoCollection<MagicModel> _collection;
        private readonly IDbConnectionPool _connection;

        public MagicApiRepository(
            ILogger<MagicApiRepository> logger,
            IMongoClient client,
            IOraclePool pool)
        {
            _logger = logger;
            _client = client;

            IMongoDatabase database = _client.GetDatabase(MONGO_DATABASE);
            _collection = database.GetCollection<MagicModel>(MONGO_COLLECTION);
            _connection = pool.Get();
        }
        public async Task<MagicModel> Get(string id)
        {
            _logger.LogInformation($"Obtendo item do Banco de Dados {id}");
            return await _collection.Find(doc => doc.Id == id).FirstOrDefaultAsync();
        }

        public async Task<MagicModel[]> List()
        {
            _logger.LogInformation($"Obtendo lista do Banco de Dados");
            var data = await _collection.Find(doc => true).ToListAsync();
            return data.ToArray();
        }

        public async Task<ApiRoutes[]> ListApiRoutes()
        {
            _logger.LogInformation($"Obtendo lista de rotas do Banco de Dados Oracle");
            using var command = _connection.CreateCommand();
            command.CommandText = SQL;
            command.CommandTimeout = 10;
            command.CommandType = System.Data.CommandType.Text;

            Stopwatch time = new Stopwatch();
            time.Start();

            using var table = await _connection.ExecuteReaderAsync(command);
            time.Stop();

            int maxItens = Math.Min(table.Rows.Count, 10);

            ApiRoutes[] routes = new ApiRoutes[maxItens];

            for (int i = 0; i < maxItens; i++)
            {
                var row = table.Rows[i];
                routes[i] = new ApiRoutes
                {
                    RouteUri = row.ToValue<string>("REQUEST_ROUTE_URI"),
                    Method = row.ToValue<string>("REQUEST_METHOD"),
                    HeadersKey = row.ToValueOrDefault<string>("REQUEST_HEADER_KEY"),
                    Ip = row.ToValueOrDefault<string>("REQUEST_IP"),
                    Date = row.ToValue<DateTime>("REQUEST_DATE"),
                    ResponseStatusCode = row.ToValue<int>("RESPONSE_STATUSCODE"),
                    Account = row.ToValue<int>("ACCOUNT"),
                };
            }
            
            _logger.LogInformation($"Itens encontrados: {table.Rows.Count} em {time.ElapsedMilliseconds} ms| Itens processados: {maxItens}");
            return routes;
        }
    }
}