﻿using System;
using MB.Core.Constants;
using MB.Core.Extensions;
using MB.Core.HealthChecks;
using MB.Magic.Api.Domain.Options;
using MB.Magic.Api.Domain.Repository;
using MB.Magic.Api.Domain.Service;
using MB.Magic.Api.Repository;
using MB.Magic.Api.Service.Api;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Modal.Core.Extensions.Policies.Options;
using Modal.Extensions.ADO;

namespace MB.Magic.Api.Service
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }
        
        public void ConfigureServices(IServiceCollection services)
        {  
            var circuitOptions = Configuration.GetSection("CircuitBreakerOptions").Get<CircuitBreakerOptions>();
            Uri magicConsumerApi = new Uri(Configuration.GetValue<string>("MagicConsumerApi:BaseAddress"));

            services
                .Configure<MagicOptions>(Configuration.GetSection("MagicOptions"))
                .Configure<AppConfigOptions>(Configuration.GetSection("AppConfigOptions"));

            services                
                .AddOraclePool(Configuration.GetConnectionString("SMC"), maxPool: 20)
                .AddMongoDB(Configuration.GetConnectionString("MongoDB"))
                .AddRabbitServiceBus(Configuration);
            
            services
                .AddTransient<IMagicApiService, MagicApiService>()
                .AddTransient<IMagicApiRepository, MagicApiRepository>()
                .AddSingleton<IConfigService, ConfigService>();

            
            services
                .AddHttpClient<IMagicConsumerApi, MagicConsumerApi>(
                    (provider, client) => client.BaseAddress = magicConsumerApi)
                .AddPolicyRetry(countRetry: 3, delayMilliseconds: 500)
                .AddPolicyCircuitAndReport("MagicConsumerApi", circuitOptions);            

            services
                .AddDefaultHealthCheck()                
                .AddOraclePoolCheck("SMC", new string [] { HealthCheckConstants.READY, HealthCheckConstants.DEPENDENCIES })
                .AddMongoDBCheck("MongoDB", new string [] { HealthCheckConstants.READY, HealthCheckConstants.DEPENDENCIES })
                .AddCheckBus("RabbitMQ", new string [] { HealthCheckConstants.READY, HealthCheckConstants.DEPENDENCIES })
                .AddRedisCheck("Redis")
                .AddCheckTelnet("magicConsumerApi", magicConsumerApi);

            services
                .AddDefaultController();

            services
                .AddHealthCheckPublisher(Configuration);
        }
        
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {            
            app.MapAll(env);            
        }
    }
}

