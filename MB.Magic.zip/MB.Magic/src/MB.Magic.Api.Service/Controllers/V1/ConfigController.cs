﻿using System;
using System.Threading.Tasks;
using MB.Magic.Api.Domain.Options;
using MB.Magic.Api.Domain.Service;
using MB.Magic.Api.Service.Api;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;

namespace MB.Magic.Api.Service.Controllers.V1
{
    [ApiController]
    [Route("api/v{version:apiVersion}/config")]
    public class ConfigController : ControllerBase
    {             
        private readonly ILogger<ConfigController> _logger;
        private readonly AppConfigOptions _options;
        private readonly IConfiguration _contiguration;
        private readonly IConfigService _configService;
        private readonly IMagicConsumerApi _api;

        public ConfigController(
            ILogger<ConfigController> logger,
            IOptions<AppConfigOptions> options,
            IConfiguration configuration,
            IConfigService configService,
            IMagicConsumerApi api)
        {
            _logger = logger;
            _options = options.Value;
            _contiguration = configuration;
            _configService = configService;
            _api = api;
        }
        
        [HttpGet]
        public IActionResult Get()
        {
            try
            {
                return Ok(_options);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Não foi possível obter o options!!");
                return BadRequest("Não foi possível obter o options!!");
            }
        }

        [HttpGet("{key}")]
        public IActionResult Get(string key)
        {
            try
            {                               
                return Ok(_contiguration[key]);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Key: {key}] Não foi possível obter a configuração!!");
                return BadRequest($"Key: {key}] Não foi possível obter a configuração!!");
            }
        }

        [HttpGet("from-service")]
        public IActionResult GetService()
        {
            try
            {                               
                return Ok(_configService.Get());
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Não foi possível obter a configuração do service!!");
                return BadRequest($"Não foi possível obter a configuração do service!!");
            }
        }

        [HttpPost("enable-consumer")]
        public async Task<IActionResult> EnableConsumer()
        {
            try
            {
                if(await _api.EnableConsumer())                               
                    return Ok();
                
                return BadRequest("Não foi possível habilitar o consumer.");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Não foi possível habilitar o consumer!!");
                return BadRequest($"Não foi possível habilitar o consumer!!");
            }
        }

        [HttpPost("disable-consumer")]
        public async Task<IActionResult> DisableConsumer()
        {
            try
            {
                if(await _api.DisableConsumer())                               
                    return Ok();
                
                return BadRequest("Não foi possível dasabilitar o consumer.");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Não foi possível dasabilitar o consumer!!");
                return BadRequest($"Não foi possível dasabilitar o consumer!!");
            }
        }
    }
}
