﻿using System;
using System.Threading.Tasks;
using MB.Core.Caching;
using MB.Magic.Api.Domain.Models;
using MB.Magic.Api.Domain.Service;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

namespace MB.Magic.Api.Service.Controllers.V1
{
    [ApiController]
    [Route("api/v{version:apiVersion}/oracle-bd-api-routes")]
    public class OracleBDApiRoutesController : ControllerBase
    {             
        const byte ERROR_LIST = 001;
        private readonly ILogger<OracleBDApiRoutesController> _logger;
        private readonly IMagicApiService _service;        

        public OracleBDApiRoutesController(
            ILogger<OracleBDApiRoutesController> logger,
            IMagicApiService service)
        {
            _logger = logger;
            _service = service;            
        }        

        [HttpGet]
        public async Task<IActionResult> List()
        {
            try
            {
                return Ok(await _service.ListApiRoutes());
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"[{ERROR_LIST}] Não foi possível processar a requisição!!");
                return BadRequest("Não foi possível processar a requisição!!");
            }
        }        
    }
}
