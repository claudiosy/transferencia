﻿using System;
using System.Threading.Tasks;
using MB.Core.Caching;
using MB.Magic.Api.Domain.Models;
using MB.Magic.Api.Domain.Service;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

namespace MB.Magic.Api.Service.Controllers.V1
{
    [ApiController]
    [Route("api/v{version:apiVersion}/magic")]
    public class MagicController : ControllerBase
    {     
        const byte ERROR_POST = 001;
        const byte ERROR_GET = 002;
        const byte ERROR_LIST = 003;
        private readonly ILogger<MagicController> _logger;
        private readonly IMagicApiService _service;        

        public MagicController(
            ILogger<MagicController> logger,
            IMagicApiService service)
        {
            _logger = logger;
            _service = service;            
        }

        [HttpPost]
        public async Task<IActionResult> Post([FromBody] MagicModel value)
        {
            try
            {
                await _service.Send(value);
                return Ok();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"[{ERROR_POST}] Não foi possível processar a requisição!!");
                return BadRequest("Não foi possível processar a requisição!!");
            }
        }

        [HttpGet]
        public async Task<IActionResult> List()
        {
            try
            {
                return Ok(await _service.List());
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"[{ERROR_LIST}] Não foi possível processar a requisição!!");
                return BadRequest("Não foi possível processar a requisição!!");
            }
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> Get(string id)
        {
            try
            {               
                var value = await _service.Get(id);
                if(value == null)
                    return StatusCode(404, null);

                return Ok(value);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"[{ERROR_GET}][Id: {id}] Não foi possível processar a requisição!!");
                return BadRequest("Não foi possível processar a requisição!!");
            }
        }

        [HttpGet("meuip")]
        public IActionResult MeuIp()
        {
            try
            {
                return Ok(this.GetIpAddress());
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Não foi possível obter o IP!!");
                return BadRequest("Não foi possível obter o IP!!");
            }
        }        

        [HttpGet("Forwarded")]
        public IActionResult Forwarded()
        {
            try
            {
                return Ok(this.GetIpAddressForwarded());
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Não foi possível obter o Forwarded!!");
                return BadRequest("Não foi possível obter o Forwarded!!");
            }
        }

        [HttpGet("Headers")]
        public IActionResult Headers()
        {
            try
            {
                return Ok(Request.Headers);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Não foi possível obter os Headers!!");
                return BadRequest("Não foi possível obter os Headers!!");
            }
        }
    }
}
