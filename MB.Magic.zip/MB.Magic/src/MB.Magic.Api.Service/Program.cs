﻿using System.Threading.Tasks;
using MB.Core;

namespace MB.Magic.Api.Service
{
    public class Program
    {
        public static async Task Main(string[] args)
        {                        
            await Microservice<Startup>.Run("MB.Magic.Api.Service", args);
        }
    }
}

