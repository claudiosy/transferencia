using System.Threading.Tasks;

namespace MB.Magic.Api.Service.Api
{
    public interface IMagicConsumerApi
    {
        Task<bool> EnableConsumer();
        Task<bool> DisableConsumer();
    }
}