using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;

namespace MB.Magic.Api.Service.Api
{
    public class MagicConsumerApi : IMagicConsumerApi
    {
        const string URI_ENABLE = "/api/v1/flag/consumer/enable";
        const string URI_DISABLE = "/api/v1/flag/consumer/disable";
        private readonly HttpClient _client;

        public MagicConsumerApi(HttpClient client)
        {
            _client = client;
        }
        public async Task<bool> EnableConsumer()
        {
            using HttpContent content = new StringContent(string.Empty);
            using HttpResponseMessage response = await _client.PostAsync(URI_ENABLE, content);

            return response.IsSuccessStatusCode;
        }
        public async Task<bool> DisableConsumer()
        {
            using HttpContent content = new StringContent(string.Empty);
            using HttpResponseMessage response = await _client.PostAsync(URI_DISABLE, content);

            return response.IsSuccessStatusCode;
        }        
    }
}