using System.Threading.Tasks;
using MB.Magic.Api.Domain.Models;

namespace MB.Magic.Api.Domain.Service
{
    public interface IMagicConsumerService
    {        
        Task Save(MagicModel value);
    }
}