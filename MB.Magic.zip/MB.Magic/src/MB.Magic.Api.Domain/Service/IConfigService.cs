using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using MB.Magic.Api.Domain.Options;

namespace MB.Magic.Api.Domain.Service
{
    public interface IConfigService
    {
        AppConfigOptions Get(); 
    }
}