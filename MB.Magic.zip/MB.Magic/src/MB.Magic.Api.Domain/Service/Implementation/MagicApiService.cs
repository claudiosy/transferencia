using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using MassTransit;
using MB.Core.Caching;
using MB.Magic.Api.Domain.Models;
using MB.Magic.Api.Domain.Options;
using MB.Magic.Api.Domain.Repository;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;

namespace MB.Magic.Api.Domain.Service
{
    public class MagicApiService : IMagicApiService
    {        
        private readonly IBusControl _bus;
        private readonly IMagicApiRepository _repository;
        private readonly ICache<MagicModel> _cache;        
        private readonly ICache _cacheGeneric;
        private readonly ILogger<MagicApiService> _logger;
        private readonly MagicOptions _options;

        public MagicApiService(
            ILogger<MagicApiService> logger,
            IOptions<MagicOptions> options,
            IBusControl bus, 
            IMagicApiRepository repository,
            ICache<MagicModel> cache,            
            ICache cacheGeneric)
        {
            _logger = logger;
            _options = options.Value;
            _bus = bus;
            _repository = repository;
            _cache = cache;            
            _cacheGeneric = cacheGeneric;
        }
        public async Task<MagicModel> Get(string id)
        {
            _logger.LogInformation($"Obtendo item do cache: {id}");
            return await _cache
                    .GetOrSet(id, TimeSpan.FromSeconds(_options.CacheTimeSeconds), async () => await _repository.Get(id));            
        }

        public async Task<MagicModel[]> List()
        {
            _logger.LogInformation($"Obtendo lista do cache");
            return await _cacheGeneric
                .GetOrSet(
                    "LIST",
                    TimeSpan.FromSeconds(_options.CacheTimeSeconds),
                    async () => await _repository.List());
        }       

        public async Task Send(MagicModel value)
        {
            await _bus.Send(_options.QueueName, value);
        }

        public async Task<ApiRoutes[]> ListApiRoutes()
        {
            _logger.LogInformation($"Obtendo lista de rotas do cache");
            return await _cacheGeneric.GetOrSet(
                "LISTA:ORACLE",
                TimeSpan.FromSeconds(_options.CacheTimeSeconds),
                 async () => await _repository.ListApiRoutes());
        }
    }
}