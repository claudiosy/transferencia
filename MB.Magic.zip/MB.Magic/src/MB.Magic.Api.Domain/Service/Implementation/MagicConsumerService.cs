using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using MB.Magic.Api.Domain.Models;
using MB.Magic.Api.Domain.Repository;

namespace MB.Magic.Api.Domain.Service
{
    public class MagicConsumerService : IMagicConsumerService
    {
        private readonly IMagicConsumerRepository _repository;

        public MagicConsumerService(IMagicConsumerRepository repository)
        {
            _repository = repository;
        }
        public async Task Save(MagicModel value)
        {
            await _repository.Save(value);
        }
    }
}