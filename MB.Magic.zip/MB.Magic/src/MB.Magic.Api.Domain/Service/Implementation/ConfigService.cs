using MB.Magic.Api.Domain.Options;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;

namespace MB.Magic.Api.Domain.Service
{
    public class ConfigService : IConfigService
    {
        private readonly ILogger<ConfigService> _logger;
        private readonly IOptionsMonitor<AppConfigOptions> _monitor;

        public ConfigService(
            ILogger<ConfigService> logger,
            IOptionsMonitor<AppConfigOptions> monitor)
        {
            _logger = logger;
            _monitor = monitor;
            _monitor.OnChange(SetOptions);
        }

        private void SetOptions(AppConfigOptions value, string key)
        {
            _logger.LogInformation($"{nameof(AppConfigOptions)} Changed {key}| {nameof(AppConfigOptions.MyId)}: {value.MyId}| {nameof(AppConfigOptions.MyName)}: {value.MyName}");
        }

        public AppConfigOptions Get()
        {
            return _monitor.CurrentValue;
        }
    }
}