using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using MB.Magic.Api.Domain.Models;

namespace MB.Magic.Api.Domain.Repository
{
    public interface IMagicConsumerRepository
    {        
        Task Save(MagicModel value);
    }
}