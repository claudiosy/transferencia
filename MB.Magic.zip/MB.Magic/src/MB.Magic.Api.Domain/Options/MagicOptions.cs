using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MB.Magic.Api.Domain.Options
{
    public class MagicOptions
    {
        public string QueueName { get; set; }
        public int CacheTimeSeconds { get; set; }
    }
}