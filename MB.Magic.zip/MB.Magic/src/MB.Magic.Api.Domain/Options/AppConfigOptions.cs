using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MB.Magic.Api.Domain.Options
{
    public class AppConfigOptions
    {
        public int MyId { get; set; }
        public string MyName { get; set; }
    }
}