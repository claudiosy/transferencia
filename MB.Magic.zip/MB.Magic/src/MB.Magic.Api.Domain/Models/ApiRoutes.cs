using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MB.Magic.Api.Domain.Models
{
    public class ApiRoutes
    {
        public string RouteUri { get; set; }
        public string Method {get; set;}
        public string HeadersKey {get; set;}
        public string Ip { get; set; }
        public DateTime Date {get; set;}
        public int ResponseStatusCode {get;set;}
        public int Account {get;set;}
        public int Duration {get; set;}
    }
}