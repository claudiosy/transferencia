using MB.Core.Constants;
using MB.Core.Extensions;
using MB.Magic.Api.Domain.Options;
using MB.Magic.Api.Domain.Repository;
using MB.Magic.Api.Domain.Service;
using MB.Magic.Api.Repository;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

namespace MB.Magic.Api.Consumer
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }
        
        public void ConfigureServices(IServiceCollection services)
        {  

             services
                .Configure<MagicOptions>(Configuration.GetSection("MagicOptions"));

            services                                
                .AddMongoDB(Configuration.GetConnectionString("MongoDB"))
                .AddRabbitServiceBus(Configuration);

            services
                .AddTransient<IMagicConsumerService, MagicConsumerService>()
                .AddTransient<IMagicConsumerRepository, MagicConsumerRepository>();

            services
                .AddDefaultHealthCheck()                
                .AddMongoDBCheck("MongoDB", HealthCheckConstants.READY, HealthCheckConstants.DEPENDENCIES)
                .AddCheckBus("RabbitMQ", HealthCheckConstants.READY, HealthCheckConstants.DEPENDENCIES);

            services
                .AddDefaultController();
            
            services
                .AddHealthCheckPublisher(Configuration);
        }
        
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {            
            app.MapAll(env);
        }
    }
}
