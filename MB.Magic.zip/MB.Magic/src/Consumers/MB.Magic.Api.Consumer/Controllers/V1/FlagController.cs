﻿using System;
using System.Threading.Tasks;
using MassTransit;
using MB.Core.Caching;
using MB.Magic.Api.Domain.Models;
using MB.Magic.Api.Domain.Options;
using MB.Magic.Api.Domain.Service;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;

namespace MB.Magic.Api.Service.Controllers.V1
{
    [ApiController]
    [Route("api/v{version:apiVersion}/flag")]
    public class FlagController : ControllerBase
    {             
        private readonly ILogger<FlagController> _logger;
        private readonly IBusControl _bus;

        public FlagController(
            ILogger<FlagController> logger,
            IBusControl bus)
        {
            _logger = logger;            
            _bus = bus;
        }

        

        [HttpPost("consumer/enable")]
        public async Task<IActionResult> EnableConsumer()
        {
            try
            {                
                await _bus.StartAsync(); 
                _logger.LogInformation("Consumer habilitado.");
                return Ok();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Não foi possível habilitar o consumer!!");
                return BadRequest("Não foi possível habilitar o consumer!!");
            }
        }

        [HttpPost("consumer/disable")]
        public async Task<IActionResult> DisableConsumer()
        {
            try
            {                           
                await _bus.StopAsync();
                _logger.LogInformation("Consumer desabilitado.");
                return Ok();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Não foi possível desabilitar o consumer!!");
                return BadRequest("Não foi possível desabilitar o consumer!!");
            }
        }        
    }
}
