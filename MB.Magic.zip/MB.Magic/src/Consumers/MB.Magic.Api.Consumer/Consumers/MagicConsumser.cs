using System;
using System.Threading.Tasks;
using MassTransit;
using MB.Magic.Api.Domain.Models;
using MB.Magic.Api.Domain.Service;
using Microsoft.Extensions.Logging;
using Modal.Extensions.RabbitMQ.Attributes;

namespace MB.Magic.Api.Consumer
{
    [Queue(ConfigQueueNameKey = "MagicOptions:QueueName", RetryCount = 3, RetryIntervalSeconds = 2)]
    public class MagicConsumser : IConsumer<MagicModel>
    {
        private readonly ILogger<MagicModel> _logger;
        private readonly IMagicConsumerService _service;

        public MagicConsumser(
            ILogger<MagicModel> logger,
            IMagicConsumerService service)
        {
            _logger = logger;
            _service = service;
        }
        public async Task Consume(ConsumeContext<MagicModel> context)
        {
            try
            {
                _logger.LogInformation($"Recebido: Magic {context.Message.Id}|{context.Message?.Name}|{context.Message.Description}|{context.Message.Enabled}");
                await _service.Save(context.Message);
                _logger.LogInformation($"Salvo com sucesso: Magic {context.Message.Id}|{context.Message?.Name}|{context.Message.Description}|{context.Message.Enabled}");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Falha ao salvar: {context.MessageId}|{context.Message?.Name}");
                throw;
            }            
        }
    }
}