using System.Threading.Tasks;
using MB.Core;
using MB.WindowsService;

namespace MB.Magic.Api.Consumer
{
    public class Program
    {
        public static async Task Main(string[] args)
        {                        
            await Microservice<Startup>.Run("MB.Magic.Api.Consumer", args);
        }
    }
}
