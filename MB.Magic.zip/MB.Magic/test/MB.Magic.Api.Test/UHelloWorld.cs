using System;
using Xunit;

namespace MB.Api.Test
{
    public class UHelloWorld
    {
        [Fact]
        public void Hello()
        {
            Assert.True(true);
        }
    }
}
