export const fontSizes = {
  small: '12px',
  medium: '20px',
  large: '26px',
}
