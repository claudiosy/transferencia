export const icons = {
  small: '',
  medium: '',
  large: '',
}
