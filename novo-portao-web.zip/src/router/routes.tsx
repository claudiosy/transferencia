import * as React from 'react'
import { BrowserRouter as Router, Route, Switch } from 'react-router-dom'

import Template from '../components/Template/Template'
import Login from '../components/Login/Login'
import SignUp from '../components/SignUp/SignUp'
import UserContext from '../context/UserContext'

const Routes = () => (
  <Router>
    <Switch>
      <Template>
        <UserContext>
          <Route exact path="/" component={Login} />
          <Route exact path="/signup" component={SignUp} />
        </UserContext>
      </Template>
      {/* <Route component={NotFound} /> */}
    </Switch>
  </Router>
)

export default Routes
