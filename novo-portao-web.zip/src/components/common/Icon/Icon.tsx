import * as React from 'react'
import { Icon } from '@material-ui/core'
import styled from 'styled-components'
import { colors } from '../../../theme/theme'

// **************************************************
// *****  Styled Components
// **************************************************
const StyledIcon = styled(Icon).attrs({
  style: {
    color: colors.primary,
    fontSize: '20px',
  },
})<Props>``

// **************************************************
// *****  Interfaces
// **************************************************
interface Props extends Partial<React.StatelessComponent> {
  name: string
  className?: string
  style?: React.CSSProperties
}

// **************************************************
// ***** Component
// **************************************************
const IconComponent = ({ name, className, ...props }: Props) => (
  <StyledIcon className={className} style={props.style} {...props}>
    {name}
  </StyledIcon>
)

export default IconComponent
