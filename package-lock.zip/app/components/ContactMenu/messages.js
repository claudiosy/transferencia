/*
 * ContactMenu Messages
 *
 * This contains all the text for the ContactMenu component.
 */
import { defineMessages } from 'react-intl';

export default defineMessages({
  menuButton: {
    id: 'superdigital.components.ContactMenu.menuButton',
    defaultMessage: 'Atendimento',
  },
  menuItemOne: {
    id: 'superdigital.components.ContactMenu.menuItemOne',
    defaultMessage: 'Central de Atendimento',
  },
  menuItemTwo: {
    id: 'superdigital.components.ContactMenu.menuItemTwo',
    defaultMessage: 'SAC',
  },
  menuItemThree: {
    id: 'superdigital.components.ContactMenu.menuItemThree',
    defaultMessage: 'Ouvidoria',
  },
  menuItemOneHint: {
    id: 'superdigital.components.ContactMenu.menuItemOneHint',
    defaultMessage: '11 4090-1450 (Capitais e regiões metropolitanas)',
  },
  menuItemOneHintLineTwo: {
    id: 'superdigital.components.ContactMenu.menuItemOneHintLineTwo',
    defaultMessage: '0800-090-1450 (Demais localidades)',
  },
  menuItemTwoHintLineOne: {
    id: 'superdigital.components.ContactMenu.menuItemTwoHintLineOne',
    defaultMessage: '0800-787-3772',
  },
  menuItemTwoHintLineTwo: {
    id: 'superdigital.components.ContactMenu.menuItemTwoHintLineTwo',
    defaultMessage: 'Deficiente auditivo e',
  },
  menuItemTwoHintLineThree: {
    id: 'superdigital.components.ContactMenu.menuItemTwoHintLineThree',
    defaultMessage: 'de fala no: 0800-771-0401',
  },
  menuItemThreeHintLineOne: {
    id: 'superdigital.components.ContactMenu.menuItemThreeHintLineOne',
    defaultMessage: '0800-757-3777',
  },
  menuItemThreeHintLineTwo: {
    id: 'superdigital.components.ContactMenu.menuItemThreeHintLineTwo',
    defaultMessage: 'Deficiente auditivo e',
  },
  menuItemThreeHintLineThree: {
    id: 'superdigital.components.ContactMenu.menuItemThreeHintLineThree',
    defaultMessage: 'de fala no: 0800-771-0301',
  },
});
