import React from 'react';

import { FormattedMessage, injectIntl, intlShape } from 'react-intl';
import messages from './messages';
import styles from './styles.css';
import proceedIcon from 'containers/App/proceed-icon.png';
import isMobile from 'utils/isMobile';

class ContactMenu extends React.Component { // eslint-disable-line react/prefer-stateless-function
  constructor() {
    super();
    this.state = { open: false, overflow: false, hintOneVisible: false, hintTwoVisible: false, hintThreeVisible: false };
    this.handleClick = this.handleClick.bind(this);
    this.showHint = this.showHint.bind(this);
  }
  handleClick() {
    this.setState({ open: !this.state.open });
    if (!this.state.open) {
      this.overflowTimeout = setTimeout(() => {
        if (isMobile()) window.scrollTo(0, document.body.scrollHeight);
        this.setState({ overflow: true });
      }, 600);
    } else {
      this.setState({ overflow: false, hintOneVisible: false, hintTwoVisible: false, hintThreeVisible: false });
      clearTimeout(this.overflowTimeout);
    }
  }
  showHint(which) {
    if (which === 1) this.setState({ hintOneVisible: true, hintTwoVisible: false, hintThreeVisible: false });
    if (which === 2) this.setState({ hintTwoVisible: true, hintOneVisible: false, hintThreeVisible: false });
    if (which === 3) this.setState({ hintThreeVisible: true, hintOneVisible: false, hintTwoVisible: false });
  }
  render() {
    const { formatMessage } = this.props.intl;
    let menuItemOne = formatMessage(messages.menuItemOne);
    let menuItemTwo = formatMessage(messages.menuItemTwo);
    let menuItemThree = formatMessage(messages.menuItemThree);

    if (isMobile() && this.state.hintOneVisible) {
      menuItemOne = (<span>
        <FormattedMessage {...messages.menuItemOneHint} />
        <br />
        <FormattedMessage {...messages.menuItemOneHintLineTwo} />
      </span>);
    }
    if (isMobile() && this.state.hintTwoVisible) {
      menuItemTwo = (<span>
        <FormattedMessage {...messages.menuItemTwoHintLineOne} />
        <hr />
        <FormattedMessage {...messages.menuItemTwoHintLineTwo} />
        <br />
        <FormattedMessage {...messages.menuItemTwoHintLineThree} />
      </span>);
    }
    if (isMobile() && this.state.hintThreeVisible) {
      menuItemThree = (<span>
        <FormattedMessage {...messages.menuItemThreeHintLineOne} />
        <hr />
        <FormattedMessage {...messages.menuItemThreeHintLineTwo} />
        <br />
        <FormattedMessage {...messages.menuItemThreeHintLineThree} />
      </span>);
    }


    return (
      <ul className={`${styles.contactMenu} ${this.state.open && styles.open} ${this.state.overflow && styles.overflow}`}>
        <li>
          <button type="button" className={styles.contactButton} onClick={this.handleClick}>
            <FormattedMessage {...messages.menuButton} />&nbsp;&nbsp;&nbsp;<img src={proceedIcon} role="presentation" alt="" />
          </button>
        </li>
        <li>
          <button type="button" className={styles.contactItemButton} onClick={() => this.showHint(1)}>
            {menuItemOne}
            {!isMobile() && <div className={`${styles.hint} ${styles.hintLarge} ${this.state.hintOneVisible && styles.visible}`}>
              <FormattedMessage {...messages.menuItemOneHint} />
              <FormattedMessage {...messages.menuItemOneHintLineTwo} />
            </div>}
          </button>
        </li>
        <li className={(isMobile() && this.state.hintTwoVisible) && styles.autoHeight}>
          <button type="button" className={styles.contactItemButton} onClick={() => this.showHint(2)}>
            {menuItemTwo}
            {!isMobile() && <div className={`${styles.hint} ${this.state.hintTwoVisible && styles.visible}`}>
              <FormattedMessage {...messages.menuItemTwoHintLineOne} />
              <hr />
              <FormattedMessage {...messages.menuItemTwoHintLineTwo} />
              <FormattedMessage {...messages.menuItemTwoHintLineThree} />
            </div>}
          </button>
        </li>
        <li className={(isMobile() && this.state.hintThreeVisible) && styles.autoHeight}>
          <button type="button" className={styles.contactItemButton} onClick={() => this.showHint(3)}>
            {menuItemThree}
            {!isMobile() && <div className={`${styles.hint} ${this.state.hintThreeVisible && styles.visible}`}>
              <FormattedMessage {...messages.menuItemThreeHintLineOne} />
              <hr />
              <FormattedMessage {...messages.menuItemThreeHintLineTwo} />
              <FormattedMessage {...messages.menuItemThreeHintLineThree} />
            </div>}
          </button>
        </li>
      </ul>
    );
  }
}

ContactMenu.propTypes = {
  intl: intlShape.isRequired,
};

export default injectIntl(ContactMenu);
