import messages from 'containers/App/messages';

const validatePlanos = (valuesFromState, props) => {
  const { formatMessage } = props.intl;
  const errors = {};
  const values = valuesFromState.toJS();
  if (!values.TermoUso) {
    errors.TermoUso = formatMessage(messages.mandatoryField);
  }
  return errors;
};

export default validatePlanos;
