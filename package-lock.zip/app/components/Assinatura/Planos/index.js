import React from 'react';
import { connect } from 'react-redux';
import { reduxForm, change, formValueSelector } from 'redux-form/immutable';
import { FormattedNumber, injectIntl, intlShape } from 'react-intl';
import { Row, Col } from 'react-flexbox-grid/lib/index';
import FlatButton from 'material-ui/FlatButton';
import List from 'components/List';
import ListItem from 'components/ListItem';
import messages from './messages';
import styles from './styles.css';
import validatePlanos from './validation';
import openarrowIcon from 'containers/App/openarrow-icon.png';
import closearrowIcon from 'containers/App/closearrow-icon.png';
import checkIcon from 'containers/App/check-icon.png';

const Planos = props => { // eslint-disable-line react/prefer-stateless-function
  const { planos, handleSetPlano, handleOpenPlano, planoSelected } = props;
  const { formatMessage } = props.intl;
  const planosList = planos && planos.toJS().map((plano) => { // eslint-disable-line arrow-body-style
    return (
      <ListItem name={plano.PlanoId} key={plano.PlanoId} onClick={() => handleOpenPlano(plano.PlanoId, planoSelected)} autoHeight notButton={plano.PlanoAtual} >
        <div className={styles.formWrapperSucess}>
          <Row className={styles.itemPlano}>
            <Col sm={8} xs={12}>
              <span className={`${styles.lblTit}`}>{plano.Nome}</span>
              <img className={`${!plano.PlanoAtual ? styles.hide : ''} ${styles.rightIcon}`} src={checkIcon} role="presentation" />
              <span>{plano.Descricao}</span>
            </Col>
            <Col sm={4} xs={12}>
              <span className={`${styles.valor}`}>
                <i>{plano.SimboloMoeda}</i>
                <b><FormattedNumber style="decimal" minimumFractionDigits={2} value={plano.ValorPlano} /></b> / mês
                <FlatButton name="btnArrow" className={`${plano.PlanoAtual ? styles.hide : ''} ${styles.rightIcon} ${styles.arrowIcon}`} type="button" onClick={() => handleOpenPlano(plano.PlanoId, planoSelected)}>
                  <img src={planoSelected === plano.PlanoId ? closearrowIcon : openarrowIcon} role="presentation" />
                </FlatButton>
              </span>
            </Col>
          </Row>
          <Row center="xs" className={`${planoSelected === plano.PlanoId && !plano.PlanoAtual ? styles.block : ''} ${styles.hide}`}>
            <Col sm={12} xs={12}>
              <FlatButton name="btnTrocar" className={`${styles.btnEscolhePlano} redButton`} label={formatMessage(messages.escolhePlano)} onClick={() => handleSetPlano(plano.PlanoId)} />
            </Col>
          </Row>
        </div>
      </ListItem>
    );
  });

  return (
    <form>
      <List showHoverEffect behind={(planoSelected && planoSelected !== 0)} activeItem={planoSelected}>
        {planosList}
      </List>

      <div className={styles.infoPlanos}>
        <h4>Com a sua assinatura, você usa todas as funcionalidades Superdigital quantas vezes quiser sem pagar nada por isso. Se quiser algum serviço extra, você paga:</h4>
        <ul>
          <li>R$ 5,90 por saque no Brasil no Banco 24Horas.</li>
          <li>R$ 2,00 por emissão de saldo ou extrato no Banco 24Horas.</li>
          <li>R$ 5,90 por transferências para outros bancos.</li>
          <li>R$ 19,90 por saque no exterior na Rede Cirrus®.</li>
          <li>R$ 4,90 por cartão virtual emitido acima da franquia.</li>
          <li>R$ 14,90 por 2ª via de cartão emitido ou por cartão físico emitido acima da franquia.</li>
        </ul>
      </div>
    </form>
  );
};

Planos.propTypes = {
  initialValues: React.PropTypes.object,
  handleOpenPlano: React.PropTypes.func,
  handleSetPlano: React.PropTypes.func,
  handleSubmit: React.PropTypes.func,
  planoSelected: React.PropTypes.number,
  // idPlanoSelected: React.PropTypes.number,
  PlanoId: React.PropTypes.number,
  TermoUso: React.PropTypes.bool,
  AceitePromocoes: React.PropTypes.bool,
  planos: React.PropTypes.object,
  intl: intlShape.isRequired,
};

function mapDispatchToProps(dispatch) {
  return {
    handleOpenPlano: (plano, planoSelected) => {
      dispatch(change('planosAssForm', 'planoSelected', planoSelected === plano ? 0 : plano));
    },
    dispatch,
  };
}

const selector = formValueSelector('planosAssForm');
export default connect(
  state => {
    const planoSelected = selector(state, 'planoSelected');
    return {
      planoSelected,
    };
  }, mapDispatchToProps)(injectIntl(reduxForm({
    form: 'planosAssForm',
    validate: validatePlanos,
  })(Planos)));
