import { defineMessages } from 'react-intl';

export default defineMessages({
  btContinuar: {
    id: 'superdigital.Assinatura.Planos.btContinuar',
    defaultMessage: 'CONTINUAR',
  },
  escolhePlano: {
    id: 'superdigital.Assinatura.Planos.escolhePlano',
    defaultMessage: 'QUERO TROCAR PARA ESTA',
  },
  lblAceitePromocoes: {
    id: 'superdigital.Assinatura.Planos.lblAceitePromocoes',
    defaultMessage: 'Aceito receber e-mails promocionais ',
  },
});
