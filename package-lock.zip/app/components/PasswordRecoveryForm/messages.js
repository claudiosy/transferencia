import { defineMessages } from 'react-intl';

export default defineMessages({
  header: {
    id: 'superdigital.PasswordRecoveryForm.header',
    defaultMessage: 'Esqueci minha senha',
  },
  labelCPF: {
    id: 'superdigital.PasswordRecoveryForm.labelCPF',
    defaultMessage: 'CPF',
  },
  labelNacimento: {
    id: 'superdigital.PasswordRecoveryForm.labelNacimento',
    defaultMessage: 'Data de Nascimento',
  },
  labelDDD: {
    id: 'superdigital.PasswordRecoveryForm.labelDDD',
    defaultMessage: 'DDD',
  },
  labelTelefone: {
    id: 'superdigital.PasswordRecoveryForm.labelTelefone',
    defaultMessage: 'Celular',
  },
  labelEmail: {
    id: 'superdigital.PasswordRecoveryForm.labelEmail',
    defaultMessage: 'E-mail',
  },
  hintSelfie: {
    id: 'superdigital.PasswordRecoveryForm.hintSelfie',
    defaultMessage: 'SELFIE',
  },
  dropArquivoRG: {
    id: 'superdigital.PasswordRecoveryForm.dropArquivoRG',
    defaultMessage: 'Clique para selecionar o arquivo, ou arraste ele aqui (máx. 2Mb).',
  },
  continuarButton: {
    id: 'superdigital.PasswordRecoveryForm.continuarButton',
    defaultMessage: 'CONFIRMAR',
  },
  msgError: {
    id: 'superdigital.PasswordRecoveryForm.msgError',
    defaultMessage: 'Não foi possível enviar uma nova senha :(',
  },
  msgSucesso: {
    id: 'superdigital.PasswordRecoveryForm.msgSucesso',
    defaultMessage: 'Uma nova senha foi encaminhada ao seu e-mail cadastrado :)',
  },
  sendButton: {
    id: 'superdigital.PasswordRecoveryForm.sendButton',
    defaultMessage: 'RECEBER SENHA',
  },
  backButton: {
    id: 'superdigital.PasswordRecoveryForm.backButton',
    defaultMessage: 'Voltar',
  },
});
