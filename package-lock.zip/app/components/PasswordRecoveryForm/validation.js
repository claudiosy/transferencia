import messages from 'containers/App/messages';
import { validadeCPF } from 'containers/App/validation';
import moment from 'moment';

const validatePasswordRecovery = (valuesFromState, props) => {
  const { formatMessage } = props.intl;
  const errors = {};
  const values = valuesFromState.toJS();

  const dateNow = moment(new Date());
  if (!values.CPF || values.CPF.length < 14) {
    errors.CPF = formatMessage(messages.mandatoryField);
  }
  if (!validadeCPF(values.CPF)) {
    errors.CPF = formatMessage(messages.invalidCPF);
  }
  if (!values.Celular || values.Celular.length < 15) {
    errors.Celular = formatMessage(messages.mandatoryField);
  }
  if (values.Email && !/^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,4}$/i.test(values.Email)) {
    errors.Email = formatMessage(messages.invalidEmail);
  }
  if (values.DataNascimento && values.DataNascimento.length === 10 && dateNow.diff(moment(values.DataNascimento, 'DD-MM-YYYY'), 'days') < 6575) {
    errors.DataNascimento = formatMessage(messages.invalidData18Year);
  }
  if (!values.DataNascimento || values.DataNascimento.length < 10) {
    errors.DataNascimento = formatMessage(messages.mandatoryField);
  }
  if (!moment(values.DataNascimento, 'YYYY-MM-DD').isValid()) {
    errors.DataNascimento = formatMessage(messages.invalidData);
  }
  return errors;
};

export default validatePasswordRecovery;
