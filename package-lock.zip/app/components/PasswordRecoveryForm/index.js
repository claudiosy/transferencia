import React from 'react';
import { reduxForm, Field, change, formValueSelector } from 'redux-form/immutable';
import { connect } from 'react-redux';
import { TextField } from 'redux-form-material-ui';
import FlatButton from 'material-ui/FlatButton';
import Loader from 'components/Loader';
import { Row, Col } from 'react-flexbox-grid/lib/index';
import { normalizeCPF, normalizeData, normalizeCelular, formatDataEsqueci } from 'normalizers';
import validatePasswordRecovery from './validation';
import { FormattedMessage, injectIntl, intlShape } from 'react-intl';
import messages from './messages';
import Dropzone from 'react-dropzone';
import styles from './styles.css';
import iconConfirm from 'containers/App/confirm-icon.png';
import List from 'components/List';
import ListItem from 'components/ListItem';
import iconInfo from 'containers/App/icon-info-red.png';
import btnVoltar from 'containers/App/prev-icon.png';
import isMobile from 'utils/isMobile';

class PasswordRecoveryForm extends React.Component {
  constructor() {
    super();
    this.state = {
      arquivoSelfie: null,
    };
    this.onDrop = this.onDrop.bind(this);
  }
  onDrop(files, name) {
    const file = files[0];
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = () => {
      const fileInfo = {
        thumb: file.preview,
        base64: reader.result,
      };
      const obj = {};
      obj[name] = fileInfo;
      this.setState(obj);
      this.props.handleSetSelfie(fileInfo.base64);
    };
  }
  render() {
    const { handleSubmit, handleBack, pristine, submitting, loading, sucesso } = this.props;
    const { formatMessage } = this.props.intl;
    const { arquivoSelfie } = this.state;
    let content;
    const valueLeft = isMobile() ? '43%' : '60%';

    if (loading) {
      content = (<div><Loader left={valueLeft} /></div>);
    } else if (sucesso === true) {
      content = (
        <div>
          <Row center="sm">
            <Col sm={9} xs={12}>
              <List>
                <ListItem key={1} icon={iconInfo} notButton autoHeight>
                  <p>
                    <span><FormattedMessage {...messages.msgSucesso} /></span>
                  </p>
                </ListItem>
              </List>
            </Col>
          </Row>
          <Row center="xs">
            <Col sm={12} xs={12}>
              <FlatButton name="btnBack" className={styles.btnVoltar} label={formatMessage(messages.backButton)} onMouseUp={handleBack}>
                <img src={btnVoltar} role="presentation" alt="" />
              </FlatButton>
            </Col>
          </Row>
        </div>
      );
    } else {
      content = (
        <form onSubmit={handleSubmit}>
          <Field component={TextField} className="iptHidden" name="Selfie" type="hidden" value={arquivoSelfie && arquivoSelfie.base64} underlineShow={false} />
          <Row center="sm">
            <Col sm={9} xs={12}>
              <Row start="sm">
                <Col sm={6} xs={12} className="fieldWrapper">
                  <Field name="CPF" className={`${styles.fildImput} redInput`} component={TextField} floatingLabelText={formatMessage(messages.labelCPF)} label={formatMessage(messages.labelCPF)} type="tel" normalize={normalizeCPF} tabIndex="1" />
                </Col>
                <Col sm={6} xs={12} className="fieldWrapper">
                  <Field name="Email" className={`${styles.fildImput} redInput redInputRight`} component={TextField} floatingLabelText={formatMessage(messages.labelEmail)} label={formatMessage(messages.labelEmail)} tabIndex="3" />
                </Col>
              </Row>
              <Row>
                <Col sm={6} xs={12} className="fieldWrapper">
                  <Field name="Celular" className={`${styles.fildImput} redInput`} component={TextField} floatingLabelText={formatMessage(messages.labelTelefone)} label={formatMessage(messages.labelTelefone)} type="tel" normalize={normalizeCelular} format={normalizeCelular} tabIndex="4" />
                </Col>
                <Col sm={6} xs={12} className="fieldWrapper">
                  <Field name="DataNascimento" className={`${styles.fildImput} redInput redInputRight`} component={TextField} floatingLabelText={formatMessage(messages.labelNacimento)} label={formatMessage(messages.labelNacimento)} type="tel" normalize={normalizeData} format={formatDataEsqueci} tabIndex="5" />
                </Col>
              </Row>
              <Row>
                <Col xs={12} className="fieldWrapper">
                  <Dropzone accept="image/*" onDrop={(event) => this.onDrop(event, 'arquivoSelfie')} className={styles.dropzone} activeClassName={styles.dropzoneActive} maxSize="2097152">
                    <div name="selfie" className={`${styles.preview} ${!arquivoSelfie && styles.bg}`}>
                      <div style={{ backgroundImage: `url(${iconConfirm})` }} className={`${arquivoSelfie && styles.block} ${styles.hide} ${styles.confirImg} `}></div>
                      <img className={`${arquivoSelfie && styles.block} ${styles.hide} `} src={arquivoSelfie && arquivoSelfie.thumb} role="presentation" />
                    </div>
                    <div className={styles.lblTit}><FormattedMessage {...messages.hintSelfie} /></div>
                    <div className={styles.lblButton}><FormattedMessage {...messages.dropArquivoRG} /></div>
                  </Dropzone>
                </Col>
              </Row>
              <br />
              <Row>
                <Col xs={12} xs={12} className={`${arquivoSelfie && styles.block} ${styles.hide} ${styles.submitButtonWrapper}`}>
                  <FlatButton name="btnConfirmar" className="redButton" type="submit" label={formatMessage(messages.continuarButton)} disabled={pristine || submitting} tabIndex="8" />
                </Col>
              </Row>
            </Col>
          </Row>
        </form>
      );
    }
    return (
      <div className={styles.formWrapper}>
        {content}
      </div>
    );
  }
}

PasswordRecoveryForm.propTypes = {
  handleSubmit: React.PropTypes.func,
  handleBack: React.PropTypes.func,
  pristine: React.PropTypes.bool,
  loading: React.PropTypes.bool,
  sucesso: React.PropTypes.bool,
  message: React.PropTypes.string,
  submitting: React.PropTypes.bool,
  Selfie: React.PropTypes.string,
  CPF: React.PropTypes.string,
  Email: React.PropTypes.string,
  Celular: React.PropTypes.string,
  DataNascimento: React.PropTypes.string,
  handleSetSelfie: React.PropTypes.func,
  intl: intlShape.isRequired,
};

function mapDispatchToProps(dispatch) {
  return {
    handleSetSelfie: (fileBase64) => {
      dispatch(change('passwordRecoveryForm', 'Selfie', fileBase64));
    },
    dispatch,
  };
}

const selector = formValueSelector('passwordRecoveryForm');
export default connect(
  state => {
    const Selfie = selector(state, 'Selfie');
    return {
      Selfie,
    };
  }, mapDispatchToProps)(injectIntl(reduxForm({
    form: 'passwordRecoveryForm',
    validate: validatePasswordRecovery,
    enableReinitialize: true,
  })(PasswordRecoveryForm)));
