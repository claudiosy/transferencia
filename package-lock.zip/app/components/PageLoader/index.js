/**
*
* PageLoader
*
*/

import React from 'react';
import { Row, Col } from 'react-flexbox-grid/lib/index';
import Loader from 'components/Loader';

import styles from './styles.css';

function PageLoader() {
  return (
    <Row>
      <Col sm={8} className={styles.wrapper}>
        <Loader top="calc(50% - 28px)" />
      </Col>
    </Row>
  );
}

export default PageLoader;
