import React from 'react';
import styles from './styles.css';
import List from 'components/List';
import ListItem from 'components/ListItem';
import messages from './messages';
import { FormattedMessage } from 'react-intl';
import HeaderHolerite from 'components/Organizar/Holerite/HeaderHolerite';
import ContentHolerite from 'components/Organizar/Holerite/ContentHolerite';
import CircularProgress from 'material-ui/CircularProgress';
import iconInfo from 'containers/App/icon-info.png';

function Extrato(props) {
  const { loadingHolerite, historico, handleFiltroDatasSubmit, handleSetMonth, filtroExtrato, exibeFiltro, filtroDatas, onClick, column1Selection } = props;

  let count = 0;

  let valores;

  let extratoItem = '';
  const lengthMovimentacoes = historico.toJS().Movimentacoes && historico.toJS().Movimentacoes.length;

  const header = (<HeaderHolerite filtroDatas={filtroDatas} filtroExtrato={filtroExtrato} handleSetMonth={handleSetMonth} onSubmit={handleFiltroDatasSubmit} exibeFiltro={exibeFiltro} column1Selection={column1Selection} />);

  if (loadingHolerite) {
    extratoItem = (
      <span className={styles.loadingHistorico}>
        <CircularProgress size={0.3} />
        <FormattedMessage {...messages.loadingHistorico} />
      </span>
    );
  } else if (historico.toJS().length !== 0) {
    extratoItem = historico.toJS().map((item) => { // eslint-disable-line arrow-body-style
      count++;
      return (
        <div className={styles.divItem} onClick={() => onClick(item.Id)}>
          <ContentHolerite loadingHolerite={loadingHolerite} dadosHistorico={item} column1Selection={column1Selection} />
          <div className={`${count < lengthMovimentacoes ? styles.separator : ''}`}></div>
        </div>
      );
    });
    if (extratoItem.length === 0) {
      extratoItem = (
        <List>
          <ListItem key={1} icon={iconInfo} notButton showProceedIcon={false}>
            <FormattedMessage {...messages.noItens} />
          </ListItem>
        </List>
      );
    }
  }

  return (
    // eslint-disable-next-line react/jsx-boolean-value
    <div>
      <div className={`${styles.extratoWrapper}`}>
        {valores}
        {header}
        <div className={extratoItem.length > 0 && styles.separator}></div>
        {extratoItem}
      </div>
    </div>
  );
}

Extrato.propTypes = {
  loadingHolerite: React.PropTypes.bool,
  historico: React.PropTypes.object,
  filtroExtrato: React.PropTypes.object,
  handleSetMonth: React.PropTypes.func,
  handleFiltroDatasSubmit: React.PropTypes.func,
  exibeFiltro: React.PropTypes.bool,
  handleSelecaoFiltro: React.PropTypes.func,
  filtroDatas: React.PropTypes.bool,
  onClick: React.PropTypes.func,
  column1Selection: React.PropTypes.number,
};

export default Extrato;
