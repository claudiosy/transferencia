import React from 'react';
import { connect } from 'react-redux';
import styles from './styles.css';
import proceedIcon from 'containers/App/proceed-icon.png';
import prevIcon from 'containers/App/prev-icon.png';
import FlatButton from 'material-ui/FlatButton';
import { retornaMesExtenso, retornaUltimoDiaDoMes } from 'utils/datas';
import isMobile from 'utils/isMobile';
import { reduxForm, Field, change, formValueSelector } from 'redux-form/immutable';
import areIntlLocalesSupported from 'intl-locales-supported';
import { DatePicker } from 'redux-form-material-ui';
import { injectIntl, intlShape } from 'react-intl';
import { Row, Col } from 'react-flexbox-grid/lib/index';
import messages from './messages';
import openarrowIcon from 'containers/App/openarrow-grey-icon.png';
import closearrowIcon from 'containers/App/closearrow-grey-icon.png';
import closeIcon from 'containers/App/close.png';
import divisor from './divisor.png';
import calendarIcon from './calendario-icon.png';
import moment from 'moment';
import validateHeaderHoleriteForm from './validation';

import { toggleFiltroDatas } from 'containers/Organizar/HoleritePage/actions';

/* eslint-disable no-script-url */
function HeaderHolerite(props) {
  const { handleSubmit, handleSetMonth, filtroExtrato, filtroDatas, handleFiltroDatas, exibeFiltro, dataInicialValue, column1Selection } = props;
  const { DataInicio, DataFim } = filtroExtrato.toJS();
  const { formatMessage } = props.intl;
  const mesInicialExtenso = retornaMesExtenso(DataInicio.getMonth());
  const mesFinalExtenso = retornaMesExtenso(DataFim.getMonth());
  const maxDate = new Date();
  const fimAtual = new Date(new Date().getFullYear(), new Date().getMonth(), retornaUltimoDiaDoMes(new Date(new Date().getFullYear(), new Date().getMonth(), 1)));
  const desabilitaNext = fimAtual.toString() === DataFim.toString() && !exibeFiltro;

  let ano;
  let strPeriodoMes;
  let backButton = (
    <FlatButton name="btnBack" className={styles.backButton} onClick={() => handleSetMonth(-1)}>
      <img src={prevIcon} alt="" />
    </FlatButton>
  );

  if (exibeFiltro) {
    backButton = (
      <img src={calendarIcon} alt="" className={styles.calendar} />
    );
    ano = '';
    strPeriodoMes = moment(DataInicio).format(column1Selection === 0 && !isMobile ? 'DD/MM/YYYY' : 'DD/MM');
    strPeriodoMes += ' a ';
    strPeriodoMes += moment(DataFim).format(column1Selection === 0 && !isMobile ? 'DD/MM/YYYY' : 'DD/MM');
  } else {
    ano = DataFim.getFullYear();
    strPeriodoMes = mesInicialExtenso !== mesFinalExtenso ? `${mesInicialExtenso} a ${mesFinalExtenso}` : mesInicialExtenso;
  }

  let DateTimeFormat;
  let conteudoFiltroDatas;

  if (areIntlLocalesSupported('pt-BR')) {
    DateTimeFormat = global.Intl.DateTimeFormat;
  } else {
    const IntlPolyfill = require('intl'); // eslint-disable-line global-require
    DateTimeFormat = IntlPolyfill.DateTimeFormat;
    require('intl/locale-data/jsonp/pt-BR'); // eslint-disable-line global-require
  }

  if (filtroDatas) {
    conteudoFiltroDatas = (
      <form onSubmit={handleSubmit} className={`${styles.header} ${styles.noBorder}`}>
        <div>
          <Row>
            <Col sm={4} xs={6}>
              <Field
                className={`${styles.monthDatePicker} redInput`}
                name="periodoInicio"
                component={DatePicker}
                locale="pt-BR"
                cancelLabel="Cancelar"
                okLabel="OK"
                autoOk
                maxDate={maxDate}
                DateTimeFormat={DateTimeFormat}
                hintText={formatMessage(messages.labelPeriodoInicio)}
                tabIndex="1"
              />
            </Col>
            <Col sm={4} xs={6}>
              <Field
                className={styles.monthDatePicker}
                name="periodoFim"
                component={DatePicker}
                locale="pt-BR"
                cancelLabel="Cancelar"
                okLabel="OK"
                autoOk
                minDate={new Date(dataInicialValue)}
                maxDate={maxDate}
                DateTimeFormat={DateTimeFormat}
                hintText={formatMessage(messages.labelPeriodoFim)}
                tabIndex="2"
              />
            </Col>
            <Col sm={4} xs={12}>
              <FlatButton name="btnAplicar" className="redButton block" type="submit" label={formatMessage(messages.submitButton)} tabIndex="3" />
            </Col>
          </Row>
        </div>
      </form>
    );
  }

  return (
    <div className={styles.border}>
      <div className={`${styles.header} ${styles.headerMobile}`}>
        <div>
          {backButton}
          <img src={divisor} alt="" className={exibeFiltro ? styles.divisor1 : styles.divisorHide} />
          <span className={styles.periodo}>
            {strPeriodoMes} {ano}
            <FlatButton name="btnArrow" className={styles.openFilter} type="button" onMouseUp={handleFiltroDatas}>
              <img src={filtroDatas ? closearrowIcon : openarrowIcon} role="presentation" />
            </FlatButton>
          </span>
          <img src={divisor} alt="" className={exibeFiltro ? styles.divisor2 : styles.divisorHide} />
          <FlatButton name="btnNext" className={`${styles.nextButton} ${(desabilitaNext ? styles.desabilita : '')}`} onClick={() => handleSetMonth(exibeFiltro ? 0 : 1)} disabled={desabilitaNext} >
            <img src={exibeFiltro ? closeIcon : proceedIcon} alt="" />
          </FlatButton>
        </div>
      </div>
      {conteudoFiltroDatas}
    </div>
  );
}

HeaderHolerite.propTypes = {
  handleSubmit: React.PropTypes.func,
  filtroExtrato: React.PropTypes.object,
  handleSetMonth: React.PropTypes.func,
  handleFiltroDatas: React.PropTypes.func,
  filtroDatas: React.PropTypes.bool,
  periodoInicio: React.PropTypes.string,
  periodoFim: React.PropTypes.string,
  intl: intlShape.isRequired,
  exibeFiltro: React.PropTypes.bool,
  dataInicialValue: React.PropTypes.string,
  dataFinalValue: React.PropTypes.string,
  column1Selection: React.PropTypes.number,
};

function mapDispatchToProps(dispatch) {
  return {
    handleFiltroDatas: () => {
      dispatch(change('headerHoleriteForm', 'periodoInicio', ''));
      dispatch(change('headerHoleriteForm', 'periodoFim', ''));
      dispatch(toggleFiltroDatas());
    },
    dispatch,
  };
}

const selector = formValueSelector('headerHoleriteForm');
export default connect(
  state => {
    const dataInicialValue = selector(state, 'periodoInicio');
    const dataFinalValue = selector(state, 'periodoFim');

    return {
      dataInicialValue,
      dataFinalValue,
    };
  }, mapDispatchToProps)(injectIntl(reduxForm({
    form: 'headerHoleriteForm',
    validate: validateHeaderHoleriteForm,
    enableReinitialize: true,
  })(HeaderHolerite)));
