import messages from 'containers/App/messages';
import moment from 'moment';

const validateHeaderHoleriteForm = (valuesFromState, props) => {
  const { formatMessage } = props.intl;
  const errors = {};
  const values = valuesFromState.toJS();
  if (!values.periodoInicio || values.periodoInicio.length < 10) {
    errors.periodoInicio = formatMessage(messages.mandatoryField);
  }
  if (!moment(values.periodoInicio, 'YYYY-MM-DD').isValid()) {
    errors.periodoInicio = formatMessage(messages.invalidData);
  }

  if (!values.periodoFim || values.periodoFim.length < 10) {
    errors.periodoFim = formatMessage(messages.mandatoryField);
  }
  if (!moment(values.periodoFim, 'YYYY-MM-DD').isValid()) {
    errors.periodoFim = formatMessage(messages.invalidData);
  }
  return errors;
};

export default validateHeaderHoleriteForm;
