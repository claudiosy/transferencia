import { defineMessages } from 'react-intl';

export default defineMessages({
  labelPeriodoInicio: {
    id: 'app.components.Organizar.Holerite.HeaderHolerite.labelPeriodoInicio',
    defaultMessage: 'Data início',
  },
  labelPeriodoFim: {
    id: 'app.components.Organizar.Holerite.HeaderHolerite.labelPeriodoFim',
    defaultMessage: 'Data fim',
  },
  submitButton: {
    id: 'app.components.Organizar.Holerite.HeaderHolerite.submitButton',
    defaultMessage: 'Aplicar',
  },
});
