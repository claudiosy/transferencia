import { defineMessages } from 'react-intl';

export default defineMessages({
  header: {
    id: 'app.components.Organizar.Historico.Extrato.header',
    defaultMessage: 'EXTRATO',
  },
  loadingCartoes: {
    id: 'app.components.Organizar.Historico.Extrato.loadingCartoes',
    defaultMessage: 'Carregando cartões...',
  },
  loadingHistorico: {
    id: 'app.components.Organizar.Historico.Extrato.loadingHistorico',
    defaultMessage: 'Carregando o histórico...',
  },
  noItens: {
    id: 'app.components.Organizar.Historico.Extrato.noItens',
    defaultMessage: 'Não achamos movimentações nesse período',
  },
});
