import React from 'react';
import styles from './styles.css';
import List from 'components/List';
import ListItem from 'components/ListItem';
import messages from './messages';
import { FormattedMessage } from 'react-intl';
import SelecaoMoeda from 'components/Organizar/Historico/SelecaoMoeda';
import HeaderExtrato from 'components/Organizar/Historico/HeaderExtrato';
import FilterExtrato from 'components/Organizar/Historico/FilterExtrato';
import ContentHistorico from 'components/Organizar/Historico/ContentHistorico';
import CircularProgress from 'material-ui/CircularProgress';
import iconInfo from 'containers/App/icon-info.png';

function Extrato(props) {
  const { loadingMoeda, moedas, cartoes, loadingHistorico, historico, handleFiltroDatasSubmit, handleSetMonth, filtroExtrato, handleSelecaoMoeda, exibeFiltro, handleSelecaoFiltro, filtroDatas, onClick, handleTags, handleClearFilter, column1Selection, loadingCartoes } = props;
  const { Entradas, Saidas } = historico.toJS();

  let count = 0;

  let valores;
  let header;
  let filtro;

  let extratoItem = '';
  const lengthMovimentacoes = historico.toJS().Movimentacoes && historico.toJS().Movimentacoes.length;
  if (loadingMoeda) {
    valores = (
      <span className={styles.loadingHistorico}>
        <CircularProgress size={0.3} />
        <FormattedMessage {...messages.loadingHistorico} />
      </span>
    );
  } else {
    valores = (
      <SelecaoMoeda moedas={moedas} entradas={Entradas} saidas={Saidas} handleSelecaoMoeda={handleSelecaoMoeda} initialValues={filtroExtrato} />
    );

    header = (<HeaderExtrato filtroDatas={filtroDatas} filtroExtrato={filtroExtrato} handleSetMonth={handleSetMonth} onSubmit={handleFiltroDatasSubmit} exibeFiltro={exibeFiltro} column1Selection={column1Selection} />);
    if (loadingCartoes) {
      filtro = (
        <span className={styles.loadingHistorico}>
          <CircularProgress size={0.3} />
          <FormattedMessage {...messages.loadingCartoes} />
        </span>
      );
    } else {
      filtro = (<FilterExtrato handleSelecaoFiltro={handleSelecaoFiltro} initialValues={filtroExtrato} filtroExtrato={filtroExtrato} handleTags={handleTags} handleClearFilter={handleClearFilter} column1Selection={column1Selection} cartoes={cartoes} />);
    }

    if (loadingHistorico) {
      extratoItem = (
        <span className={styles.loadingHistorico}>
          <CircularProgress size={0.3} />
          <FormattedMessage {...messages.loadingHistorico} />
        </span>
      );
    } else if (historico.toJS().length !== 0) {
      extratoItem = historico.toJS().Movimentacoes.map((item) => { // eslint-disable-line arrow-body-style
        count++;
        return (
          <div className={styles.divItem} onClick={() => onClick(item.Id, item.Tipo)}>
            <ContentHistorico loadingHistorico={loadingHistorico} dadosHistorico={item} column1Selection={column1Selection} />
            <div className={`${count < lengthMovimentacoes ? styles.separator : ''}`}></div>
          </div>
        );
      });
      if (extratoItem.length === 0) {
        extratoItem = (
          <List>
            <ListItem key={1} icon={iconInfo} notButton showProceedIcon={false}>
              <FormattedMessage {...messages.noItens} />
            </ListItem>
          </List>
        );
      }
    }
  }

  return (
    // eslint-disable-next-line react/jsx-boolean-value
    <div>
      <div className={`${styles.extratoWrapper}`}>
        {valores}
        {header}
        {filtro}
        <div className={extratoItem.length > 0 && styles.separator}></div>
        {extratoItem}
      </div>
    </div>
  );
}

Extrato.propTypes = {
  moedas: React.PropTypes.object,
  cartoes: React.PropTypes.object,
  loadingMoeda: React.PropTypes.bool,
  loadingHistorico: React.PropTypes.bool,
  historico: React.PropTypes.object,
  filtroExtrato: React.PropTypes.object,
  handleSetMonth: React.PropTypes.func,
  handleFiltroDatasSubmit: React.PropTypes.func,
  handleSelecaoMoeda: React.PropTypes.func,
  exibeFiltro: React.PropTypes.bool,
  handleSelecaoFiltro: React.PropTypes.func,
  filtroDatas: React.PropTypes.bool,
  onClick: React.PropTypes.func,
  handleTags: React.PropTypes.func,
  handleClearFilter: React.PropTypes.func,
  column1Selection: React.PropTypes.number,
  loadingCartoes: React.PropTypes.bool,
};

export default Extrato;
