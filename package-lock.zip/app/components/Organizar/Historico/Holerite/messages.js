import { defineMessages } from 'react-intl';

export default defineMessages({
  reciboPagto: {
    id: 'app.components.Organizar.Historico.Holerite.reciboPagto',
    defaultMessage: 'Recibo de pagamento de Salário',
  },
  nomeFuncionario: {
    id: 'app.components.Organizar.Historico.Holerite.nomeFuncionario',
    defaultMessage: 'Nome Funcionário',
  },
  cpf: {
    id: 'app.components.Organizar.Historico.Holerite.cpf',
    defaultMessage: 'CPF',
  },
  cargo: {
    id: 'app.components.Organizar.Historico.Holerite.cargo',
    defaultMessage: 'Cargo',
  },
  cbo: {
    id: 'app.components.Organizar.Historico.Holerite.cbo',
    defaultMessage: 'CBO',
  },
  cod: {
    id: 'app.components.Organizar.Historico.Holerite.cod',
    defaultMessage: 'Cód',
  },
  descricao: {
    id: 'app.components.Organizar.Historico.Holerite.descricao',
    defaultMessage: 'Descrição',
  },
  referencia: {
    id: 'app.components.Organizar.Historico.Holerite.referencia',
    defaultMessage: 'Referência',
  },
  proventos: {
    id: 'app.components.Organizar.Historico.Holerite.proventos',
    defaultMessage: 'Proventos',
  },
  descontos: {
    id: 'app.components.Organizar.Historico.Holerite.descontos',
    defaultMessage: 'Descontos',
  },
  totalProventos: {
    id: 'app.components.Organizar.Historico.Holerite.totalProventos',
    defaultMessage: 'Total Proventos',
  },
  totalDescontos: {
    id: 'app.components.Organizar.Historico.Holerite.totalDescontos',
    defaultMessage: 'Total Descontos',
  },
  valorLiquido: {
    id: 'app.components.Organizar.Historico.Holerite.valorLiquido',
    defaultMessage: 'Valor Líquido',
  },
  salarioBase: {
    id: 'app.components.Organizar.Historico.Holerite.salarioBase',
    defaultMessage: 'Salário Base',
  },
  contINSS: {
    id: 'app.components.Organizar.Historico.Holerite.contINSS',
    defaultMessage: 'Sal.Contr. INSS',
  },
  baseFGTS: {
    id: 'app.components.Organizar.Historico.Holerite.baseFGTS',
    defaultMessage: 'Base Cálc. FGTS',
  },
  fgts: {
    id: 'app.components.Organizar.Historico.Holerite.fgts',
    defaultMessage: 'FGTS do Mês',
  },
  baseIRRF: {
    id: 'app.components.Organizar.Historico.Holerite.baseIRRF',
    defaultMessage: 'Base Cálc. IRRF',
  },
  hintImprimir: {
    id: 'app.components.Organizar.Historico.Holerite.hintImprimir',
    defaultMessage: 'Imprimir',
  },
});
