import React from 'react';
import { reduxForm } from 'redux-form/immutable';
import { injectIntl, intlShape, FormattedMessage, FormattedNumber } from 'react-intl';
import styles from './styles.css';
import messages from './messages';
// import FlatButton from 'material-ui/FlatButton';
import Loader from 'components/Loader';

function renderItens(itens) {
  let count = 0;
  if (!itens) {
    return null;
  }
  return itens.map((item) => { // eslint-disable-line
    count++;
    return (
      <tr height="15" valign="top">
        <td id={`${'itemCodigo'}${count}`} className={styles.direita} height="15">{item.Codigo}</td>
        <td id={`${'itemDescricao'}${count}`} className={`${styles.bordaLeft} ${styles.esquerda}`} height="15" align="left">{item.Descricao}</td>
        <td id={`${'itemRef'}${count}`} className={`${styles.direita} ${styles.bordaLeft}`} height="15">{item.Referencia}</td>
        <td id={`${'itemProvento'}${count}`} className={`${styles.direita} ${styles.bordaLeft}`} height="15" width="50px"><FormattedNumber style="decimal" minimumFractionDigits={2} value={item.Provento} /></td>
        <td id={`${'itemDesconto'}${count}`} className={`${styles.direita} ${styles.bordaLeft}`} height="15"><FormattedNumber style="decimal" minimumFractionDigits={2} value={item.Desconto} /></td>
      </tr>
    );
  });
}

class Holerite extends React.Component { // eslint-disable-line react/prefer-stateless-function
  render() {
    const { loading, dadosHolerite } = this.props;
    // const { formatMessage } = this.props.intl;
    const { CNPJ,
            RazaoSocial,
            MesAno,
            Nome,
            CPF,
            Cargo,
            CBO,
            TotalProventos,
            TotalDescontos,
            TotalLiquido,
            SalarioBase,
            SalarioContribuicao,
            BaseFGTS,
            ValorFGTS,
            BaseIRRF,
            LancamentosHolerite } = dadosHolerite.toJS();

    if (loading) {
      return (
        <Loader top={0} />
      );
    }

    return (
      <div id="divHolerite" className={styles.divHolerite} >
        <table className={styles.tbPrincipal} >
          <tbody>
            <tr style={{ height: '0px' }}>
              <td style={{ width: '48px' }}></td>
              <td style={{ width: '82px' }}></td>
              <td style={{ width: '84px' }}></td>
              <td style={{ width: '46px' }}></td>
              <td style={{ width: '79px' }}></td>
              <td style={{ width: '51px' }}></td>
              <td style={{ width: '39px' }}></td>
              <td style={{ width: '92px' }}></td>
              <td style={{ width: '29px' }}></td>
              <td style={{ width: '104px' }}></td>
            </tr>
            <tr style={{ height: '36px' }}>
              <td id="cab1_1" className={`${styles.bordas} ${styles.esquerda}`} colSpan="5" valign="top">{RazaoSocial}<br />CNPJ: {CNPJ}</td>
              <td id="cab1_2" className={`${styles.bordas} ${styles.esquerda}`} colSpan="5" valign="top"><FormattedMessage {...messages.reciboPagto} /><br />{MesAno}</td>
            </tr>
            <tr style={{ height: '27px' }}>
              <td id="cab2_1" className={`${styles.bordas} ${styles.esquerda}`} colSpan="3"><FormattedMessage {...messages.nomeFuncionario} /><br />{Nome}</td>
              <td id="cab2_2" className={`${styles.bordas} ${styles.esquerda}`} colSpan="4"><FormattedMessage {...messages.cpf} /><br />{CPF}</td>
              <td id="cab2_3" className={`${styles.bordas} ${styles.esquerda}`} colSpan="2"><FormattedMessage {...messages.cargo} /><br />{Cargo}</td>
              <td id="cab2_4" className={`${styles.bordas} ${styles.esquerda}`} colSpan="1"><FormattedMessage {...messages.cbo} /><br />{CBO}</td>
            </tr>
            <tr>
              <td id="sep1" className={styles.bordas} colSpan="10">&nbsp;</td>
            </tr>
            <tr>
              <td colSpan="10">
                <table width="100%">
                  <tbody>
                    <tr>
                      <td id="cab3_1" className={`${styles.bordas} ${styles.esquerda}`}><FormattedMessage {...messages.cod} /></td>
                      <td id="cab3_2" className={`${styles.bordas} ${styles.esquerda}`}><FormattedMessage {...messages.descricao} /></td>
                      <td id="cab3_3" className={`${styles.bordas} ${styles.esquerda}`}><FormattedMessage {...messages.referencia} /></td>
                      <td id="cab3_4" className={`${styles.bordas} ${styles.esquerda}`}><FormattedMessage {...messages.proventos} /></td>
                      <td id="cab3_5" className={`${styles.bordas} ${styles.esquerda}`}><FormattedMessage {...messages.descontos} /></td>
                    </tr>
                    {renderItens(LancamentosHolerite)}
                  </tbody>
                </table>
              </td>
            </tr>
            <tr align="left" valign="top">
              <td id="tot1" className={styles.bordas} colSpan="7" rowSpan="2">&nbsp;</td>
              <td id="tot2" className={styles.bordas} colSpan="2" height="27">
                <div className={styles.direita}><FormattedMessage {...messages.totalProventos} /><br /><FormattedNumber style="decimal" minimumFractionDigits={2} value={TotalProventos} /></div>
              </td>
              <td id="tot3" className={styles.bordas} width="104" height="27">
                <div className={styles.direita}><FormattedMessage {...messages.totalDescontos} /><br /><FormattedNumber style="decimal" minimumFractionDigits={2} value={TotalDescontos} /></div>
              </td>
            </tr>
            <tr align="left" valign="top">
              <td id="tot4" className={styles.bordas} colSpan="2" height="15">
                <div className={styles.direita}><FormattedMessage {...messages.valorLiquido} /></div>
              </td>
              <td id="tot5" className={styles.bordas} width="88" height="15" valign="bottom">
                <div className={styles.direita}>R$ <FormattedNumber style="decimal" minimumFractionDigits={2} value={TotalLiquido} /></div>
              </td>
            </tr>
            <tr align="left" valign="top" height="28">
              <td id="rod1" className={`${styles.bordas} ${styles.esquerda}`} colSpan="2" height="28"><FormattedMessage {...messages.salarioBase} /><br />
                <div id="divrod1" className={styles.direita}><FormattedNumber style="decimal" minimumFractionDigits={2} value={SalarioBase} /></div>
              </td>
              <td id="rod2" className={`${styles.bordas} ${styles.esquerda}`} colSpan="2" height="28"><FormattedMessage {...messages.contINSS} /><br />
                <div id="divrod2" className={styles.direita}><FormattedNumber style="decimal" minimumFractionDigits={2} value={SalarioContribuicao} /></div>
              </td>
              <td id="rod3" className={`${styles.bordas} ${styles.esquerda}`} colSpan="2" height="28"><FormattedMessage {...messages.baseFGTS} /><br />
                <div id="divrod3" className={styles.direita}><FormattedNumber style="decimal" minimumFractionDigits={2} value={BaseFGTS} /></div>
              </td>
              <td id="rod4" className={`${styles.bordas} ${styles.esquerda}`} colSpan="2" height="28"><FormattedMessage {...messages.fgts} /><br />
                <div id="divrod4" className={styles.direita}><FormattedNumber style="decimal" minimumFractionDigits={2} value={ValorFGTS} /></div>
              </td>
              <td id="rod5" className={`${styles.bordas} ${styles.esquerda}`} colSpan="2" height="28"><FormattedMessage {...messages.baseIRRF} /><br />
                <div id="divrod5" className={styles.direita}><FormattedNumber style="decimal" minimumFractionDigits={2} value={BaseIRRF} /></div>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    );
  }
}

Holerite.propTypes = {
  loading: React.PropTypes.bool,
  dadosHolerite: React.PropTypes.object,
  intl: intlShape.isRequired,
};

export default injectIntl(reduxForm({
  form: 'holerite',
})(Holerite));
