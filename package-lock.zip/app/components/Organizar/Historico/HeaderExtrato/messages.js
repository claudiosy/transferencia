import { defineMessages } from 'react-intl';

export default defineMessages({
  labelPeriodoInicio: {
    id: 'app.components.Organizar.Historico.HeaderExtrato.labelPeriodoInicio',
    defaultMessage: 'Data início',
  },
  labelPeriodoFim: {
    id: 'app.components.Organizar.Historico.HeaderExtrato.labelPeriodoFim',
    defaultMessage: 'Data fim',
  },
  submitButton: {
    id: 'app.components.Organizar.Historico.HeaderExtrato.submitButton',
    defaultMessage: 'Aplicar',
  },
});
