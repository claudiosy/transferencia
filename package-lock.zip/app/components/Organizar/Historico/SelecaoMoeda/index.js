import React from 'react';
import { reduxForm, Field } from 'redux-form/immutable';
import { SelectField } from 'redux-form-material-ui';
import MenuItem from 'material-ui/MenuItem';
import { injectIntl, intlShape } from 'react-intl';
import { Row, Col } from 'react-flexbox-grid/lib/index';
import styles from './styles.css';
import messages from './messages';
import divisor from './divisor.png';
import greenBallIcon from 'containers/App/greenBall-icon.png';
import redBallIcon from 'containers/App/redBall-icon.png';

class SelecaoMoeda extends React.Component { // eslint-disable-line react/prefer-stateless-function
  render() {
    const { moedas, entradas, saidas, handleSelecaoMoeda } = this.props;
    const { formatMessage } = this.props.intl;

    const moedaList = moedas.toJS().map((ticket) => { // eslint-disable-line arrow-body-style
      return (
        <MenuItem value={ticket.Sigla} primaryText={ticket.Sigla} />
      );
    });

    return (
      <div className={styles.divSelecaoMoeda}>
        <form>
          <Row>
            <Col sm={2}>
              <Field name="SiglaMoeda" component={SelectField} className={styles.moeda} onChange={(event, key) => handleSelecaoMoeda(key)} underlineShow={false} tabIndex="1" >
                {moedaList}
              </Field>
            </Col>
            <Col sm={2}>
              <img src={divisor} alt="" className={styles.divisor} />
              <img src={greenBallIcon} alt="" className={styles.iconEntrada} />
              <img src={redBallIcon} alt="" className={styles.iconSaida} />
              <span className={styles.labelEntrada}>{formatMessage(messages.labelEntrada)}</span>
              <span className={styles.labelSaida}>{formatMessage(messages.labelSaida)}</span>
            </Col>
            <Col sm={8}>
              <span className={styles.valorEntrada}>{entradas}</span>
              <span className={styles.valorSaida}>{saidas && saidas.replace('-', ' ')}</span>
            </Col>
          </Row>
        </form>
      </div>
    );
  }
}

SelecaoMoeda.propTypes = {
  moedas: React.PropTypes.object,
  entradas: React.PropTypes.string,
  saidas: React.PropTypes.string,
  intl: intlShape.isRequired,
  handleSelecaoMoeda: React.PropTypes.func,
};

export default injectIntl(reduxForm({
  form: 'selecaoMoeda',
})(SelecaoMoeda));
