import { defineMessages } from 'react-intl';

export default defineMessages({
  labelEntrada: {
    id: 'app.components.Organizar.Historico.SelecaoMoeda.labelEntrada',
    defaultMessage: 'ENTRADA',
  },
  labelSaida: {
    id: 'app.components.Organizar.Historico.SelecaoMoeda.labelSaida',
    defaultMessage: 'SAÍDA',
  },
});
