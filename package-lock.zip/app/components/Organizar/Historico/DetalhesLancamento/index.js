import React from 'react';
import { reduxForm, Field } from 'redux-form/immutable';
import FlatButton from 'material-ui/FlatButton';
import CircularProgress from 'material-ui/CircularProgress';
import ChipInput from 'material-ui-chip-input';

import { injectIntl, intlShape, FormattedMessage, FormattedNumber } from 'react-intl';

import messages from './messages';
import styles from './styles.css';

import List from 'components/List';
import ListItem from 'components/ListItem';

import dolarIcon from './dolar-icon.png';
import cartoesIcon from './cartoes-icon.png';
import categoriaIcon from './tag-icon.png';
import addIcon from './adicionar-icon.png';
import openArrowIcon from './openarrow-icon.png';
import iconInfo from 'containers/App/icon-info.png';

const handleTagPlusClick = () => {
  const eventObj = document.createEventObject ? document.createEventObject() : document.createEvent('Events');

  if (eventObj.initEvent) {
    eventObj.initEvent('keydown', true, true);
  }

  eventObj.keyCode = 13;
  eventObj.which = 13;

  const el = document.getElementsByName('Tags')[0];
  el.dispatchEvent ? el.dispatchEvent(eventObj) : el.fireEvent('onkeydown', eventObj); // eslint-disable-line no-unused-expressions
};

const DetalhesLancamento = props => { // eslint-disable-line react/prefer-stateless-function
  const { handleSubmit, loading, message, dadosLancamentoModel } = props;
  const { formatMessage } = props.intl;
  const { Autenticacao, Data, FinalCartao, NomeNoCartao, Categoria, Valor } = dadosLancamentoModel.toJS();
  let content;

  if (message) {
    content = (
      <List>
        <ListItem key={1} icon={iconInfo} notButton showProceedIcon={false}>
          {message}
        </ListItem>
      </List>
    );
  } else if (loading) {
    content = (
      <span className={styles.loadingHistorico}>
        <CircularProgress size={0.3} />
        <FormattedMessage {...messages.loadingDetalhes} />
      </span>
    );
  } else {
    content = (
      <form onSubmit={handleSubmit}>
        <List>
          <ListItem key={1} notButton>
            <div className={styles.valores}>
              <span className={styles.moeda}>R$</span>
              <span className={styles.labelValor}><FormattedNumber style="decimal" minimumFractionDigits={2} value={Valor.toString().replace('-', '')} /></span>
            </div>
          </ListItem>
          <ListItem key={2} icon={dolarIcon} notButton>
            <span><FormattedMessage {...messages.labelAutenticacao} /> {Autenticacao}</span>
            <span className={styles.labelHora}>{Data.substring(11, 16)}</span>
          </ListItem>
          <ListItem key={3} icon={cartoesIcon} notButton>
            <span><FormattedMessage {...messages.labelCartao} /> </span>
            <span className={styles.labelFinalCartao}><FormattedMessage {...messages.labelFinalCartao} /></span>
            <span className={styles.labelNumFinalCartao}>{FinalCartao}</span>
            <span className={styles.labelNomeCartao}>{NomeNoCartao}</span>
          </ListItem>
          <ListItem key={4} icon={categoriaIcon} notButton>
            <span><FormattedMessage {...messages.labelCategoria} /> </span>
            <span className={styles.labelCategoria}>{Categoria}</span>
            <img src={openArrowIcon} alt="" className={styles.openArrow} />
          </ListItem>
          <ListItem key={5} icon={categoriaIcon} notButton autoHeight>
            <Field name="Tags" component={ChipInput} className="redInput chipInput" clearOnBlur={false} placeholder={formatMessage(messages.labelTags)} tabIndex="1" />
            <FlatButton name="btnAdd" className={styles.btnAdd} type="button" onMouseUp={() => handleTagPlusClick()} tabIndex="2">
              <img src={addIcon} alt="" />
            </FlatButton>
          </ListItem>
        </List>
      </form>
    );
  }
  return (
    <div className={styles.formWrapper}>
      {content}
    </div>);
};

DetalhesLancamento.propTypes = {
  handleStepChange: React.PropTypes.func,
  onDelete: React.PropTypes.func,
  handleSubmit: React.PropTypes.func,
  pristine: React.PropTypes.bool,
  loading: React.PropTypes.bool,
  message: React.PropTypes.string,
  submitting: React.PropTypes.bool,
  dadosLancamentoModel: React.PropTypes.object,
  identificacao: React.PropTypes.string,
  data: React.PropTypes.string,
  intl: intlShape.isRequired,
};

export default injectIntl(reduxForm({
  form: 'detalhesLancamentoForm',
  enableReinitialize: true,
})(DetalhesLancamento));
