import { defineMessages } from 'react-intl';

export default defineMessages({
  loadingDetalhes: {
    id: 'app.components.Organizar.Historico.DetalhesLancamento.loadingDetalhes',
    defaultMessage: 'Carregando detalhes do lançamento...',
  },
  labelAutenticacao: {
    id: 'app.components.Organizar.Historico.DetalhesLancamento.labelAutenticacao',
    defaultMessage: 'AUT',
  },
  labelCartao: {
    id: 'app.components.Organizar.Historico.DetalhesLancamento.labelCartao',
    defaultMessage: 'Cartão',
  },
  labelFinalCartao: {
    id: 'app.components.Organizar.Historico.DetalhesLancamento.labelFinalCartao',
    defaultMessage: 'FINAL',
  },
  labelCategoria: {
    id: 'app.components.Organizar.Historico.DetalhesLancamento.labelCategoria',
    defaultMessage: 'Categoria',
  },
  labelTags: {
    id: 'app.components.Organizar.Historico.DetalhesLancamento.labelTags',
    defaultMessage: 'COLOCAR UMA TAG',
  },
  ButtonNaoFizEstaCompra: {
    id: 'app.components.Organizar.Historico.DetalhesLancamento.ButtonNaoFizEstaCompra',
    defaultMessage: 'NÃO FIZ ESTA COMPRA',
  },
});
