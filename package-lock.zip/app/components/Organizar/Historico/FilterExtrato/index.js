import React from 'react';
import { reduxForm /* , Field*/ } from 'redux-form/immutable';
import FlatButton from 'material-ui/FlatButton';
import RaisedButton from 'material-ui/RaisedButton';
import Popover from 'material-ui/Popover';
import Menu from 'material-ui/Menu';
import MenuItem from 'material-ui/MenuItem';
import ArrowDropRight from 'material-ui/svg-icons/navigation-arrow-drop-right';
// import ChipInput from 'material-ui-chip-input';
import Chips from 'components/Chips';
import { injectIntl, intlShape } from 'react-intl';
import List from 'components/List';
import ListItem from 'components/ListItem';
import styles from './styles.css';
import filterIcon from 'containers/App/filter-icon.png';
import searchIcon from 'containers/App/search-icon.png';
// import addIcon from './adicionar-icon.png';
import closeIcon from 'containers/App/close.png';
import openarrowIcon from 'containers/App/openarrow-grey-icon.png';
import messages from './messages';

import isMobile from 'utils/isMobile';

function renderChildren(names, props, handleRequestClose) {
  return names.toJS().map((cartoes, key) => { // eslint-disable-line
    return (
      <MenuItem primaryText={cartoes.DescricaoCartao} onTouchTap={() => props.handleSelecaoFiltro(0, cartoes.ContaCorrenteId, cartoes.DescricaoCartao)} onClick={handleRequestClose} />
    );
  });
}

class FilterExtrato extends React.Component { // eslint-disable-line react/prefer-stateless-function
  constructor(props) {
    super(props);

    this.state = {
      open: false,
    };
  }

  handleTouchTap = (event) => {
    event.preventDefault();

    this.setState({
      open: true,
      anchorEl: event.currentTarget,
    });
  };

  handleRequestClose = () => {
    this.setState({
      open: false,
    });
  };

  render() {
    const { filtroExtrato, handleSelecaoFiltro /* , handleTags*/, handleClearFilter, column1Selection, cartoes } = this.props;
    const { formatMessage } = this.props.intl;
    const { TipoConta, TipoLancamentoId, DescricaoCartao } = filtroExtrato.toJS();
    let labelFiltro = formatMessage(messages.labelFilter);

    if (TipoConta === 'CA') {
      labelFiltro = DescricaoCartao;
    } else if (TipoLancamentoId === 12) {
      labelFiltro = formatMessage(messages.transferencias);
    } else if (TipoLancamentoId === 5) {
      labelFiltro = formatMessage(messages.pagamentos);
    }

    const showClearFilter = TipoConta !== '' || TipoLancamentoId !== '';
    const clearFilter = showClearFilter && (
      <FlatButton name="btnClear" className={styles.closeButton} onClick={() => handleClearFilter()}>
        <img src={closeIcon} alt="" />
      </FlatButton>
    );

    let content = (
      <List>
        <ListItem key={1} icon={filterIcon} notButton autoHeight>
          <div className={styles.filterExtrato}>
            <RaisedButton name="cboFilter" label={labelFiltro} className={styles.cboFilter} onTouchTap={this.handleTouchTap} tabIndex="1" />
            <img src={openarrowIcon} alt="" className={`${styles.imgArrowDown} ${showClearFilter && styles.wClear}`} />
            <Popover
              open={this.state.open}
              anchorEl={this.state.anchorEl}
              anchorOrigin={{ horizontal: 'left', vertical: 'bottom' }}
              targetOrigin={{ horizontal: 'left', vertical: 'top' }}
              onRequestClose={this.handleRequestClose}
            >
              <Menu>
                <MenuItem
                  value={0}
                  primaryText={formatMessage(messages.cartoes)}
                  rightIcon={<ArrowDropRight />}
                  menuItems={renderChildren(cartoes, this.props, this.handleRequestClose)}
                />
                <MenuItem value={12} primaryText={formatMessage(messages.transferencias)} onTouchTap={() => handleSelecaoFiltro(12, '', '')} onClick={this.handleRequestClose} />
                <MenuItem value={5} primaryText={formatMessage(messages.pagamentos)} onTouchTap={() => handleSelecaoFiltro(5, '', '')} onClick={this.handleRequestClose} />
              </Menu>
            </Popover>
            {clearFilter}
          </div>
          <img src={searchIcon} alt="" className={styles.imgSearch} />
          <Chips />
        </ListItem>
      </List>
    );

    if (isMobile() || column1Selection) {
      content = (
        <List>
          <ListItem key={1} icon={filterIcon} notButton autoHeight>
            <div className={styles.filterExtrato}>
              <RaisedButton name="cboFilter" label={labelFiltro} className={styles.cboFilter} onTouchTap={this.handleTouchTap} tabIndex="1" />
              <img src={openarrowIcon} alt="" className={`${styles.imgArrowDown} ${showClearFilter && styles.wClear}`} />
              <Popover
                open={this.state.open}
                anchorEl={this.state.anchorEl}
                anchorOrigin={{ horizontal: 'left', vertical: 'bottom' }}
                targetOrigin={{ horizontal: 'left', vertical: 'top' }}
                onRequestClose={this.handleRequestClose}
              >
                <Menu>
                  <MenuItem
                    value={0}
                    primaryText={formatMessage(messages.cartoes)}
                    rightIcon={<ArrowDropRight />}
                    menuItems={renderChildren(cartoes, this.props, this.handleRequestClose)}
                  />
                  <MenuItem value={12} primaryText={formatMessage(messages.transferencias)} onTouchTap={() => handleSelecaoFiltro(12, '', '')} onClick={this.handleRequestClose} />
                  <MenuItem value={5} primaryText={formatMessage(messages.pagamentos)} onTouchTap={() => handleSelecaoFiltro(5, '', '')} onClick={this.handleRequestClose} />
                </Menu>
              </Popover>
              {clearFilter}
            </div>
          </ListItem>
          <ListItem key={2} icon={searchIcon} notButton autoHeight>
            <Chips />
          </ListItem>
        </List>
      );
    }

    return (
      <div className={styles.contentfilter}>
        {content}
      </div>
    );
  }
}

FilterExtrato.propTypes = {
  filtroExtrato: React.PropTypes.object,
  handleSelecaoFiltro: React.PropTypes.func,
  intl: intlShape.isRequired,
  handleTags: React.PropTypes.func,
  handleClearFilter: React.PropTypes.func,
  column1Selection: React.PropTypes.number,
  cartoes: React.PropTypes.object,
};

export default injectIntl(reduxForm({
  form: 'filterExtrato',
})(FilterExtrato));
