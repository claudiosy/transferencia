import { defineMessages } from 'react-intl';

export default defineMessages({
  labelFilter: {
    id: 'app.components.Organizar.Historico.FilterExtrato.labelFilter',
    defaultMessage: 'FILTRAR POR',
  },
  cartoes: {
    id: 'app.components.Organizar.Historico.FilterExtrato.cartoes',
    defaultMessage: 'CARTÕES',
  },
  transferencias: {
    id: 'app.components.Organizar.Historico.FilterExtrato.transferencias',
    defaultMessage: 'TRANSFERÊNCIAS',
  },
  pagamentos: {
    id: 'app.components.Organizar.Historico.FilterExtrato.pagamentos',
    defaultMessage: 'PAGAMENTOS',
  },
  busca: {
    id: 'app.components.Organizar.Historico.FilterExtrato.busca',
    defaultMessage: 'Busca...',
  },
});
