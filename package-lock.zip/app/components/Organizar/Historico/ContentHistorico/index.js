import React from 'react';
import { injectIntl, FormattedNumber } from 'react-intl';
import { retornaIconHistorico } from 'utils/icons';
import styles from './styles.css';

import greenBallIcon from 'containers/App/greenBall-icon.png';
import redBallIcon from 'containers/App/redBall-icon.png';

function ContentHistorico(props) {
  const { dadosHistorico, column1Selection } = props;
  const dataExtrato = new Date(dadosHistorico.Data).toLocaleDateString('pt-BR').substring(0, 5);
  const { Valor, Descricao, Moeda, Tipo } = dadosHistorico;
  const colors = ['#AAAAAA', '#444444', '#777777'];
  const desc = Descricao.split('|').map((item, i) => { // eslint-disable-line arrow-body-style
    return item && (<span style={{ color: colors[i] }}>{item}<br /></span>);
  });

  return (
    <div className={`${styles.detailsRow} ${column1Selection && styles.blocked}`}>
      <span>
        <img src={retornaIconHistorico(Tipo)} className={styles.iconLancto} alt="" />
      </span>
      <div className={styles.date}>{dataExtrato}</div>
      <div className={styles.detalhe}>
        {desc}
      </div>
      <img className={`${styles.ball} ${column1Selection && styles.blocked}`} src={Valor < 0 ? redBallIcon : greenBallIcon} alt="" />
      <div className={`${styles.valor} ${column1Selection && styles.blocked}`}>
        <span className={styles.spanValor}>
          {Moeda}
          <FormattedNumber style="decimal" minimumFractionDigits={2} value={Valor.toString().replace('-', '')} />
        </span>
      </div>
    </div>
  );
}

ContentHistorico.propTypes = {
  dadosHistorico: React.PropTypes.object,
  column1Selection: React.PropTypes.number,
};

export default injectIntl(ContentHistorico);
