import { defineMessages } from 'react-intl';

export default defineMessages({
  infoConfirm: {
    id: 'app.components.Organizar.Cartoes.ExcluirCartaoConfirmacao.infoConfirm',
    defaultMessage: 'DEPOIS DE CONFIRMAR, SEU CARTÃO NÃO PODERÁ MAIS SER USADO.',
  },
  buttonConfirmar: {
    id: 'app.components.Organizar.Cartoes.ExcluirCartaoConfirmacao.buttonConfirmar',
    defaultMessage: 'Confirmar',
  },
});
