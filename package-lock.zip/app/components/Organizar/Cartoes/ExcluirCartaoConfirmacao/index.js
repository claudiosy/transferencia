import React from 'react';

import FlatButton from 'material-ui/FlatButton';
import { FormattedMessage, injectIntl, intlShape } from 'react-intl';
import messages from './messages';
import List from 'components/List';
import ListItem from 'components/ListItem';
import styles from './styles.css';
import infoIcon from './info-icon.png';

const ExcluirCartaoConfirmacao = props => {
  const { onConfirm } = props;
  const { formatMessage } = props.intl;

  const content = (
    <form className={styles.ListLong}>
      <List>
        <ListItem key={1} notButton icon={infoIcon} >
          <FormattedMessage {...messages.infoConfirm} />
        </ListItem>
      </List>
      <FlatButton name="btnConfirmar" onMouseUp={onConfirm} className="redButton big centered" label={formatMessage(messages.buttonConfirmar)} tabIndex="1" />
    </form>
  );

  return (
    <div>
      {content}
    </div>
  );
};

ExcluirCartaoConfirmacao.propTypes = {
  onConfirm: React.PropTypes.func,
  intl: intlShape.isRequired,
};

export default injectIntl(ExcluirCartaoConfirmacao);
