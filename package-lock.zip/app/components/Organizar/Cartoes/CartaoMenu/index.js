import React from 'react';

import List from 'components/List';
import ListItem from 'components/ListItem';
import { FormattedMessage, injectIntl, intlShape } from 'react-intl';
import messages from './messages';
import styles from './styles.css';

import DadosCard from 'components/Organizar/Cartoes/DadosCard';
import iconInfo from 'containers/App/icon-info.png';

/* eslint-disable arrow-body-style */

function CartaoMenu(props) {
  const { handleToggle, columnSelection, columnOrder, handleStepMenuChange, cartoes, idCartao, showInformativeSenha } = props;
  const dadosCartao = cartoes.toJS().filter((card) => {
    return card.CartaoId === idCartao;
  })[0];
  const { formatMessage } = props.intl;

  let background;
  if (dadosCartao.StatusCartao === '20') {
    background = 'rgba(183,183,183,1)';
  } else if (dadosCartao.TipoIndividualizacaoId === 3) {
    background = 'white';
  } else {
    background = 'linear-gradient(45deg,  rgba(0,171,187,1) 0%,rgba(84,0,163,1) 100%)';
  }

  if (showInformativeSenha) {
    return (
      <List showProceedIcon showHoverEffect>
        <ListItem key={1} informative autoHeight icon={iconInfo} showProceedIcon={false} notButton>
          <span style={{ fontSize: 14, paddingTop: 10, paddingBottom: 10 }}>{formatMessage(messages.informativeSenha)}</span>
        </ListItem>
      </List>
    );
  }

  return (
    <div>
      <div style={{ background }} className={`${styles.headerCard} ${(dadosCartao.TipoIndividualizacaoId === 3 && styles.virtCard)}`}><DadosCard dadosCartao={dadosCartao} handleToggle={handleToggle} /></div>

      <List showProceedIcon showHoverEffect behind={columnSelection !== 0} activeItem={columnSelection}>
        <ListItem key={1} invisibled={dadosCartao.TipoIndividualizacaoId !== 3} onClick={() => handleStepMenuChange(columnOrder, 1, 0, idCartao, dadosCartao.ModalidadeId)}>
          <FormattedMessage {...messages.hintVerDados} />
        </ListItem>
        <ListItem key={2} onClick={() => handleStepMenuChange(columnOrder, 2, 0, idCartao, dadosCartao.ModalidadeId)}>
          <FormattedMessage {...messages.hintExtrato} />
        </ListItem>
        <ListItem key={3} onClick={() => handleStepMenuChange(columnOrder, 3, dadosCartao.TipoIndividualizacaoId, idCartao, dadosCartao.ModalidadeId)}>
          <FormattedMessage {...messages.hintAdicionar} />
        </ListItem>
        <ListItem key={4} invisibled={dadosCartao.TipoIndividualizacaoId === 0 || dadosCartao.ModalidadeId === 184} onClick={() => handleStepMenuChange(columnOrder, 4, 0, idCartao, dadosCartao.ModalidadeId)}>
          <FormattedMessage {...messages.hintResgatar} />
        </ListItem>
        <ListItem key={5} invisibled={dadosCartao.TipoIndividualizacaoId === 3} onClick={() => handleStepMenuChange(columnOrder, 5, 0, idCartao, dadosCartao.ModalidadeId)}>
          <FormattedMessage {...messages.hintAvisoViagem} />
        </ListItem>
        <ListItem key={6} invisibled={dadosCartao.TipoIndividualizacaoId === 3} onClick={() => handleStepMenuChange(columnOrder, 6, 0, idCartao, dadosCartao.ModalidadeId)}>
          <FormattedMessage {...messages.hintLimiteDiario} />
        </ListItem>
        <ListItem key={7} invisibled={dadosCartao.TipoIndividualizacaoId === 0 || dadosCartao.TipoIndividualizacaoId === 3} onClick={() => handleStepMenuChange(columnOrder, 7, 0, idCartao, dadosCartao.ModalidadeId)}>
          <FormattedMessage {...messages.hintAlterarSenha} />
        </ListItem>
        <ListItem key={8} onClick={() => handleStepMenuChange(columnOrder, 8, 0, idCartao, dadosCartao.ModalidadeId)}>
          <FormattedMessage {...messages.hintCancelarCartao} />
        </ListItem>
        <ListItem key={9} invisibled={dadosCartao.TipoIndividualizacaoId === 3} onClick={() => handleStepMenuChange(columnOrder, 9, 0, idCartao, dadosCartao.ModalidadeId)}>
          <FormattedMessage {...messages.hint2ViaCartao} />
        </ListItem>
      </List>
    </div>
  );
}

CartaoMenu.propTypes = {
  cartoes: React.PropTypes.object,
  idCartao: React.PropTypes.number,
  columnSelection: React.PropTypes.number,
  columnOrder: React.PropTypes.number,
  handleStepMenuChange: React.PropTypes.func,
  handleToggle: React.PropTypes.func,
  tipoCard: React.PropTypes.number,
  showInformativeSenha: React.PropTypes.bool,
  intl: intlShape.isRequired,
};

export default injectIntl(CartaoMenu);
