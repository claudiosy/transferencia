import { defineMessages } from 'react-intl';

export default defineMessages({
  hintVerDados: {
    id: 'app.components.Organizar.Cartoes.CartaoMenu.hintVerDados',
    defaultMessage: 'VER DADOS',
  },
  hintExtrato: {
    id: 'app.components.Organizar.Cartoes.CartaoMenu.hintExtrato',
    defaultMessage: 'EXTRATO',
  },
  hintAdicionar: {
    id: 'app.components.Organizar.Cartoes.CartaoMenu.hintAdicionar',
    defaultMessage: 'ADICIONAR $',
  },
  hintAvisoViagem: {
    id: 'app.components.Organizar.Cartoes.CartaoMenu.hintAvisoViagem',
    defaultMessage: 'AVISO VIAGEM',
  },
  hintLimiteDiario: {
    id: 'app.components.Organizar.Cartoes.CartaoMenu.hintLimiteDiario',
    defaultMessage: 'LIMITE DIÁRIO',
  },
  hintCancelarCartao: {
    id: 'app.components.Organizar.Cartoes.CartaoMenu.hintCancelarCartao',
    defaultMessage: 'CANCELAR CARTÃO',
  },
  hint2ViaCartao: {
    id: 'app.components.Organizar.Cartoes.CartaoMenu.hint2ViaCartao',
    defaultMessage: 'SEGUNDA VIA CARTÃO',
  },
  hintResgatar: {
    id: 'app.components.Organizar.Cartoes.CartaoMenu.hintResgatar',
    defaultMessage: 'RESGATAR $',
  },
  hintAlterarSenha: {
    id: 'app.components.Organizar.Cartoes.CartaoMenu.hintAlterarSenha',
    defaultMessage: 'TROCAR SENHA MOVIMENTAR',
  },
  informativeSenha: {
    id: 'app.components.Organizar.Cartoes.CartaoMenu.informativeSenha',
    defaultMessage: 'Sua senha foi alterada. Para validar e começar a usar sua nova senha, por favor se dirija ao caixa eletrônico da rede 24 horas, insira seu cartão, digite a senha atual para acessar o menu de opções, selecione a opção “Outros Serviços” e tecle “Entra”; digite e confirme a nova senha. Pronto! A nova senha estará disponível para uso.',
  },
});
