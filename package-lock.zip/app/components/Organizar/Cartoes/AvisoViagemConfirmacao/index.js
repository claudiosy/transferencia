import React from 'react';

import FlatButton from 'material-ui/FlatButton';
import { FormattedMessage, injectIntl, intlShape } from 'react-intl';
import messages from './messages';
import List from 'components/List';
import ListItem from 'components/ListItem';
/* eslint-disable arrow-body-style */

const AvisoViagemConfirmacao = props => {
  const { onConfirm, confirmData, destinos } = props;
  const { PaisId, InicioViagem, FimViagem } = confirmData.toJS();
  const { formatMessage } = props.intl;
  const destinoPais = destinos.toJS().filter((destino) => {
    return destino.Id === PaisId;
  })[0];

  const content = (
    <form>
      <h4 className="list-title">{formatMessage(messages.header)} </h4>
      <List>
        <ListItem key={1} notButton >
          <FormattedMessage {...messages.labelDestino} />
          <span className="align-right">{destinoPais.NomePais}</span>
        </ListItem>
        <ListItem key={2} notButton>
          <FormattedMessage {...messages.labelPeriodo} />
          <span className="align-right">{InicioViagem.toLocaleDateString('pt-BR')} <span style={{ margin: '0px 10px' }}>a</span> {FimViagem.toLocaleDateString('pt-BR')}</span>
        </ListItem>
      </List>
      <FlatButton name="btnConfirmar" onMouseUp={onConfirm} className="redButton big centered" label={formatMessage(messages.buttonConfirmar)} tabIndex="1" />
    </form>
  );

  return (
    <div>
      {content}
    </div>
  );
};

AvisoViagemConfirmacao.propTypes = {
  destinos: React.PropTypes.object,
  onConfirm: React.PropTypes.func,
  confirmData: React.PropTypes.object,
  intl: intlShape.isRequired,
};

export default injectIntl(AvisoViagemConfirmacao);
