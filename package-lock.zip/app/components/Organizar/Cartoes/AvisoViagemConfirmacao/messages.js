import { defineMessages } from 'react-intl';

export default defineMessages({
  header: {
    id: 'app.components.Organizar.Cartoes.AvisoViagemConfirmacao.header',
    defaultMessage: 'Confirme os dados:',
  },
  labelDestino: {
    id: 'app.components.Organizar.Cartoes.AvisoViagemConfirmacao.labelLimiteCompra',
    defaultMessage: 'Destino:',
  },
  labelPeriodo: {
    id: 'app.components.Organizar.Cartoes.AvisoViagemConfirmacao.labelLimiteSaque',
    defaultMessage: 'Período:',
  },
  buttonConfirmar: {
    id: 'app.components.Organizar.Cartoes.AvisoViagemConfirmacao.buttonConfirmar',
    defaultMessage: 'Confirmar',
  },
});
