import React from 'react';
import { injectIntl, FormattedNumber } from 'react-intl';
import styles from './styles.css';
import iconCard from './cartoes-icon.png';

function ContentExtrato(props) {
  const { dadosExtrato } = props;
  const colors = ['#333333', '#AAAAAA', '#666666'];
  const formattedDescricao = dadosExtrato.Descricao.split('|').map((item, i) => { // eslint-disable-line arrow-body-style
    return item && (<span style={{ color: colors[i] }}>{item}<br /></span>);
  });
  const dataExtrato = new Date(dadosExtrato.Data).toLocaleDateString('pt-BR').substring(0, 5);
  return (
    <div className={styles.detailsRow}>
      <img src={iconCard} alt="" className={styles.icon} />
      <div className={styles.date}>{dataExtrato}</div>
      <div className={styles.detalhe}>
        <span className={styles.descricao}>{formattedDescricao}</span>
        <span>{dadosExtrato.Estabelecimento}</span>
      </div>
      <div className={styles.valor}>{dadosExtrato.Moeda}<FormattedNumber style="decimal" minimumFractionDigits={2} value={dadosExtrato.Valor} /></div>
    </div>
  );
}

ContentExtrato.propTypes = {
  dadosExtrato: React.PropTypes.object,
};

export default injectIntl(ContentExtrato);
