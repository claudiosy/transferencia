import React from 'react';
import { connect } from 'react-redux';
import styles from './styles.css';
import proceedIcon from 'containers/App/proceed-icon.png';
import prevIcon from 'containers/App/prev-icon.png';
import FlatButton from 'material-ui/FlatButton';
import { retornaMesExtenso, retornaUltimoDiaDoMes } from 'utils/datas';
import { reduxForm, Field, /* reset, */ change, formValueSelector } from 'redux-form/immutable';
import areIntlLocalesSupported from 'intl-locales-supported';
import { DatePicker } from 'redux-form-material-ui';
import { injectIntl, intlShape } from 'react-intl';
import { Row, Col } from 'react-flexbox-grid/lib/index';
import validateHeaderExtratoForm from './validation';
import messages from './messages';
import openarrowIcon from 'containers/App/gray-openarrow-icon.png';
import closearrowIcon from 'containers/App/gray-closearrow-icon.png';
import { toggleFiltroDatas } from 'containers/Organizar/CartoesPage/actions';
import closeIcon from 'containers/App/close.png';
import moment from 'moment';

/* eslint-disable no-script-url */
const HeaderExtrato = props => {
  const { handleSubmit, handleResetMonth, handleSetMonth, filtroExtrato, filtroDatas, handleFiltroDatas, dataInicialValue, datesFiltered } = props;
  const { dataInicial, dataFinal } = filtroExtrato.toJS();
  const { formatMessage } = props.intl;
  const mesInicialExtenso = retornaMesExtenso(dataInicial.getMonth());
  const mesFinalExtenso = retornaMesExtenso(dataFinal.getMonth());
  const strPeriodoMes = mesInicialExtenso !== mesFinalExtenso ? `${mesInicialExtenso} a ${mesFinalExtenso}` : mesInicialExtenso;
  const inicioAtual = new Date(moment(new Date()).subtract(2, 'months')._d.getMonth() + 1 + '/01/' + moment(new Date()).subtract(2, 'months')._d.getFullYear()); // eslint-disable-line
  const fimAtual = new Date(new Date().getFullYear(), new Date().getMonth(), retornaUltimoDiaDoMes(new Date(new Date().getFullYear(), new Date().getMonth(), 1)));
  const minDate = moment(new Date()).subtract(90, 'days')._d; // eslint-disable-line
  const maxDate = new Date();

  let DateTimeFormat;
  let conteudoFiltroDatas;

  const desabilitaBack = datesFiltered || dataInicial.toString() === inicioAtual.toString() || dataInicial < inicioAtual;
  const desabilitaNext = dataFinal.toString() === fimAtual.toString() || datesFiltered;

  if (areIntlLocalesSupported('pt-BR')) {
    DateTimeFormat = global.Intl.DateTimeFormat;
  } else {
    const IntlPolyfill = require('intl'); // eslint-disable-line global-require
    DateTimeFormat = IntlPolyfill.DateTimeFormat;
    require('intl/locale-data/jsonp/pt-BR'); // eslint-disable-line global-require
  }

  if (filtroDatas) {
    conteudoFiltroDatas = (
      <form onSubmit={handleSubmit} className={`${styles.header}`}>
        <div>
          <Row>
            <Col sm={4} xs={6}>
              <Field
                className={`${styles.monthDatePicker} redInput`}
                name="dataInicial"
                component={DatePicker}
                locale="pt-BR"
                cancelLabel="Cancelar"
                okLabel="OK"
                autoOk
                minDate={minDate}
                maxDate={maxDate}
                DateTimeFormat={DateTimeFormat}
                hintText={formatMessage(messages.labelPeriodoInicio)}
                tabIndex="1"
              />
            </Col>
            <Col sm={4} xs={6}>
              <Field
                className={styles.monthDatePicker}
                name="dataFinal"
                component={DatePicker}
                locale="pt-BR"
                cancelLabel="Cancelar"
                okLabel="OK"
                autoOk
                minDate={!dataInicialValue ? minDate : new Date(dataInicialValue)}
                maxDate={maxDate}
                DateTimeFormat={DateTimeFormat}
                hintText={formatMessage(messages.labelPeriodoFim)}
                tabIndex="2"
              />
            </Col>
            <Col sm={4} xs={12}>
              <FlatButton name="btnAplicar" className="redButton block" type="submit" label={formatMessage(messages.submitButton)} tabIndex="3" />
            </Col>
          </Row>
        </div>
      </form>
    );
  } else if (datesFiltered) {
    const diaInicial = dataInicial.toLocaleDateString('pt-BR').substring(0, 2);
    const diaFinal = dataFinal.toLocaleDateString('pt-BR').substring(0, 2);
    const strPeriodoFiltered = mesInicialExtenso !== mesFinalExtenso ? `${diaInicial} DE ${mesInicialExtenso} ${dataInicial.getFullYear()} A ${diaFinal} DE ${mesFinalExtenso} ${dataFinal.getFullYear()}` : `${diaInicial} A ${diaFinal} DE ${mesFinalExtenso} ${dataFinal.getFullYear()}`;
    conteudoFiltroDatas = (
      <div className={`${styles.header}`}>
        <Row>
          <Col sm={12}>
            <span className={styles.periodoFiltered}>{strPeriodoFiltered}</span>
            <a href="javascript:;" className={styles.rightIcon} onClick={() => handleResetMonth()}>
              <img src={closeIcon} alt="" />
            </a>
          </Col>
        </Row>
      </div>
    );
  }

  return (
    <div>
      <div className={`${styles.header}`}>
        <div>
          <FlatButton name="btnBack" className={`${styles.backButton} ${(desabilitaBack ? styles.desabilita : '')}`} onClick={() => handleSetMonth(-1)} disabled={desabilitaBack} >
            <img src={prevIcon} alt="" />
          </FlatButton>
          <span>
            {strPeriodoMes} {dataFinal.getFullYear()}
            <FlatButton name="btnArrow" className={styles.openFilter} type="button" onMouseUp={handleFiltroDatas}>
              <img src={filtroDatas ? closearrowIcon : openarrowIcon} role="presentation" />
            </FlatButton>
          </span>
          <FlatButton name="btnNext" className={`${styles.nextButton} ${(desabilitaNext ? styles.desabilita : '')}`} onClick={() => handleSetMonth(1)} disabled={desabilitaNext} >
            <img src={proceedIcon} alt="" />
          </FlatButton>
        </div>
      </div>
      {conteudoFiltroDatas}
    </div>
  );
};

HeaderExtrato.propTypes = {
  handleSubmit: React.PropTypes.func,
  filtroExtrato: React.PropTypes.object,
  datesFiltered: React.PropTypes.bool,
  handleSetMonth: React.PropTypes.func,
  handleResetMonth: React.PropTypes.func,
  handleFiltroDatas: React.PropTypes.func,
  filtroDatas: React.PropTypes.bool,
  dataInicial: React.PropTypes.string,
  dataFinal: React.PropTypes.string,
  dataInicialValue: React.PropTypes.string,
  dataFinalValue: React.PropTypes.string,
  intl: intlShape.isRequired,
};

function mapDispatchToProps(dispatch) {
  return {
    handleFiltroDatas: () => {
      // dispatch(reset('headerExtratoForm'));
      dispatch(change('headerExtratoForm', 'dataInicial', ''));
      dispatch(change('headerExtratoForm', 'dataFinal', ''));
      dispatch(toggleFiltroDatas());
    },
    dispatch,
  };
}

const selector = formValueSelector('headerExtratoForm');
export default connect(
  state => {
    const dataInicialValue = selector(state, 'dataInicial');
    const dataFinalValue = selector(state, 'dataFinal');
    return {
      dataInicialValue,
      dataFinalValue,
    };
  }, mapDispatchToProps)(injectIntl(reduxForm({
    form: 'headerExtratoForm',
    validate: validateHeaderExtratoForm,
    enableReinitialize: true,
  })(HeaderExtrato)));
