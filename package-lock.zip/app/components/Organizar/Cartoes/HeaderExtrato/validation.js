import messages from 'containers/App/messages';
import moment from 'moment';

const validateHeaderExtratoForm = (valuesFromState, props) => {
  const { formatMessage } = props.intl;
  const errors = {};
  const values = valuesFromState.toJS();
  if (!values.dataInicial || values.dataInicial.length < 10) {
    errors.dataInicial = formatMessage(messages.mandatoryField);
  }
  if (!moment(values.dataInicial, 'YYYY-MM-DD').isValid()) {
    errors.dataInicial = formatMessage(messages.invalidData);
  }

  if (!values.dataFinal || values.dataFinal.length < 10) {
    errors.dataFinal = formatMessage(messages.mandatoryField);
  }
  if (!moment(values.dataFinal, 'YYYY-MM-DD').isValid()) {
    errors.dataFinal = formatMessage(messages.invalidData);
  }
  return errors;
};

export default validateHeaderExtratoForm;
