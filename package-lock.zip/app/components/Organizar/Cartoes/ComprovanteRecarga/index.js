import React from 'react';
import { Grid } from 'react-flexbox-grid/lib/index';
import CircularProgress from 'material-ui/CircularProgress';

import FlatButton from 'material-ui/FlatButton';

import { injectIntl, intlShape } from 'react-intl';
import messages from './messages';
import styles from './styles.css';

import saveIcon from './save-icon.png';
import openArrow from './openarrow-icon.png';

/* eslint-disable no-script-url */

const ComprovanteRecarga = props => { // eslint-disable-line react/prefer-stateless-function
  const { loading, message, handleClick, dadosComprovante } = props;
  const { valor } = dadosComprovante.toJS();
  const { formatMessage } = props.intl;
  let content;

  if (message) {
    content = (<h2>{message}</h2>);
  } else if (loading) {
    content = (<div><CircularProgress /></div>);
  } else {
    content = (
      <Grid fluid>
        <div className={styles.topo}>
          <span className={styles.data}>Hoje</span>
        </div>
        <div className={styles.comprovante}>
          <div className={styles.groupRow}>
            <span className={styles.titulo}>COMPROVANTE <span className={styles.hora}>4:16 PM</span></span>
            <div className={styles.sep}>
              <span className={styles.moeda}>R$</span><span className={styles.valor}>{valor}</span>
            </div>
          </div>
          <div className={styles.groupRow}>
            <div className={styles.itemRow}>
              <span className={styles.subtituloClaro}>PROTOCOLO</span>
              <span className={styles.subtitulo}>8190224</span>
            </div>
            <div>
              <span className={styles.subtituloClaro}>AUTENTICAÇÃO</span>
              <span className={styles.subtitulo}>124545454-000005-02420-0000-421545154VB</span>
            </div>
          </div>
          <div className={styles.groupRow}>
            <a href="javascript:;">
              <div>
                <span className={styles.titulo}>COMPARTILHAR</span>
                <img src={openArrow} className={styles.openArrow} alt="" />
              </div>
            </a>
          </div>
          <div className={styles.lastGroupRow}>
            <FlatButton name="btnDetalhes" type="button" label={formatMessage(messages.ButtonDetalhe)} onClick={() => handleClick()} >
              <img src={saveIcon} alt="" />
            </FlatButton>
          </div>
        </div>
      </Grid>
    );
  }
  return (
    <div className={styles.formWrapper}>
      {content}
    </div>);
};

ComprovanteRecarga.propTypes = {
  pristine: React.PropTypes.bool,
  loading: React.PropTypes.bool,
  message: React.PropTypes.string,
  handleClick: React.PropTypes.func,
  dadosComprovante: React.PropTypes.object,
  intl: intlShape.isRequired,
};

export default injectIntl(ComprovanteRecarga);
