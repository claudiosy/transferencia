import { defineMessages } from 'react-intl';

export default defineMessages({
  header: {
    id: 'app.components.Organizar.Cartoes.ComprovanteRecarga.header',
    defaultMessage: 'Comprovante',
  },
  ButtonDetalhe: {
    id: 'app.components.Organizar.Cartoes.ComprovanteRecarga.ButtonDetalhe',
    defaultMessage: 'DETALHES',
  },
});
