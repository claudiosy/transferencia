import { defineMessages } from 'react-intl';

export default defineMessages({
  lblAssociarCartao: {
    id: 'app.components.Organizar.Cartoes.AssociarCartaoForm.lblAssociarCartao',
    defaultMessage: 'ASSOCIAR CARTÃO SUPERDIGITAL',
  },
  hintCartaoPrincipal: {
    id: 'app.components.Organizar.Cartoes.AssociarCartaoForm.hintCartaoPrincipal',
    defaultMessage: 'Este será o seu cartão principal?',
  },
  hintAdicionalDif: {
    id: 'app.components.Organizar.Cartoes.AssociarCartaoForm.hintAdicionalDif',
    defaultMessage: 'Esta cartão será usado por outra pessoa?',
  },
  hintSim: {
    id: 'app.components.Organizar.Cartoes.AssociarCartaoForm.hintSim',
    defaultMessage: 'Sim',
  },
  hintNao: {
    id: 'app.components.Organizar.Cartoes.AssociarCartaoForm.hintNao',
    defaultMessage: 'Não',
  },
  hintNumeroCartao: {
    id: 'app.components.Organizar.Cartoes.AssociarCartaoForm.hintNumeroCartao',
    defaultMessage: 'Número do Cartão',
  },
  hintCodVerificadorCartao: {
    id: 'app.components.Organizar.Cartoes.AssociarCartaoForm.hintCodVerificadorCartao',
    defaultMessage: 'Código Verificador do Cartão',
  },
  hintCPFAdicional: {
    id: 'app.components.Organizar.Cartoes.AssociarCartaoForm.hintCPFAdicional',
    defaultMessage: 'CPF do Adicional',
  },
  hintNomeCartao: {
    id: 'app.components.MOrganizar.Cartoes.AssociarCartaoForm.hintNomeCartao',
    defaultMessage: 'Nome do Cartão Adicional',
  },
  hintNascimentoAdicional: {
    id: 'app.components.Organizar.Cartoes.AssociarCartaoForm.hintNascimentoAdicional',
    defaultMessage: 'Data de Nascimento do Adicional',
  },
  hintCelAdicional: {
    id: 'app.components.Organizar.Cartoes.AssociarCartaoForm.hintCelAdicional',
    defaultMessage: 'Celular do Adicional',
  },
  hintApelido: {
    id: 'app.components.Organizar.Cartoes.AssociarCartaoForm.hintApelido',
    defaultMessage: 'Apelido do Cartão',
  },
  hintSenha: {
    id: 'app.components.Organizar.Cartoes.AssociarCartaoForm.hintSenha',
    defaultMessage: 'Senha do Cartão',
  },
  hintConfirmacaoSenha: {
    id: 'app.components.Organizar.Cartoes.AssociarCartaoForm.hintConfirmacaoSenha',
    defaultMessage: 'Confirmação da Senha do Cartão',
  },
  buttonCadastrar: {
    id: 'app.components.Organizar.Cartoes.AssociarCartaoForm.buttonCadastrar',
    defaultMessage: 'Continuar',
  },
  validationNomeCartao: {
    id: 'app.components.Organizar.Cartoes.AssociarCartaoForm.validationNomeCartao',
    defaultMessage: 'O nome deve conter ao menos duas palavras',
  },
});
