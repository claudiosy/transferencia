import React from 'react';
import { connect } from 'react-redux';
import { reduxForm, Field, change, formValueSelector } from 'redux-form/immutable';
import { TextField, Toggle } from 'redux-form-material-ui';
import FlatButton from 'material-ui/FlatButton';
import { Row, Col } from 'react-flexbox-grid/lib/index';
import validateAssociarCartaoForm from './validation';
import { injectIntl, intlShape } from 'react-intl';
import messages from './messages';
import List from 'components/List';
import ListItem from 'components/ListItem';
import Loader from 'components/Loader';
import { normalizeCPF, normalizeNomeCartao, normalizeData, normalizeCelular, normalizeNumeroCartao, normalizeDigitoBilhete, normalizeSenhaCard } from 'normalizers';
import cartaoIcon from 'containers/Organizar/CartoesPage/cartoes-icon.png';
import styles from './styles.css';
import isMobile from 'utils/isMobile';

class AssociarCartaoForm extends React.Component {
  constructor(props) {
    super(props);
    this.state = { senhaFocus: false };
  }
  render() {
    const { handleSubmit, pristine, submitting, loading, dados, handleVerificaCartaoComChip, handleToggleAssociar, handleToggleCartaoPrincipal, associarOutraPessoa, handleToggleClear, isCartaoComChip } = this.props;
    const { formatMessage } = this.props.intl;
    const stylesToggle = {
      thumbOff: {
        backgroundColor: '#fff',
      },
      trackOff: {
        backgroundColor: '#9f9f9f',
      },
    };
    let content;

    const contentForm = isMobile() ? (
      <div>
        <div className={`${styles.associarOutraPessoa} ${!associarOutraPessoa && styles.associarHidden}`}>
          <ListItem key={3} notButton>
            <Field name="CPFDoAdicional" component={TextField} className="redInput wFloatingLabel" floatingLabelText={formatMessage(messages.hintCPFAdicional)} normalize={normalizeCPF} tabIndex="3" />
          </ListItem>
          <ListItem key={4} notButton>
            <Field name="NomeCartao" component={TextField} className="redInput wFloatingLabel" floatingLabelText={formatMessage(messages.hintNomeCartao)} normalize={normalizeNomeCartao} tabIndex="4" />
          </ListItem>
          <ListItem key={5} notButton>
            <Field name="CelularDoAdicional" component={TextField} className="redInput wFloatingLabel" floatingLabelText={formatMessage(messages.hintCelAdicional)} normalize={normalizeCelular} tabIndex="5" />
          </ListItem>
          <ListItem key={6} notButton>
            <Field name="DataNascimentoDoAdicional" component={TextField} className="redInput wFloatingLabel" floatingLabelText={formatMessage(messages.hintNascimentoAdicional)} normalize={normalizeData} tabIndex="6" />
          </ListItem>
        </div>
        <div>
          <ListItem key={7} notButton>
            <Field name="NumeroCartao" component={TextField} onChange={(event, key) => { handleVerificaCartaoComChip(key); }} className="redInput wFloatingLabel" floatingLabelText={formatMessage(messages.hintNumeroCartao)} normalize={normalizeNumeroCartao} tabIndex="7" />
          </ListItem>
          <ListItem key={8} notButton>
            <Field name="CVV" component={TextField} className="redInput wFloatingLabel" floatingLabelText={formatMessage(messages.hintCodVerificadorCartao)} normalize={normalizeDigitoBilhete} tabIndex="8" />
          </ListItem>
          <ListItem key={9} notButton>
            <Field name="ApelidoCartao" component={TextField} className="redInput wFloatingLabel" floatingLabelText={formatMessage(messages.hintApelido)} tabIndex="9" />
          </ListItem>
        </div>
      </div>
    ) : (
      <div>
        <div className={`${styles.associarOutraPessoa} ${!associarOutraPessoa && styles.associarHidden}`}>
          <ListItem key={3} notButton>
            <Row>
              <Col sm={6} xs={12} className="fieldWrapper">
                <Field name="CPFDoAdicional" component={TextField} className="redInput wFloatingLabel" floatingLabelText={formatMessage(messages.hintCPFAdicional)} normalize={normalizeCPF} tabIndex="3" />
              </Col>
              <Col sm={6} xs={12} className="fieldWrapper" style={{ borderLeft: 'solid 1px #f2f2f2' }}>
                <Field name="NomeCartao" component={TextField} className="redInput wFloatingLabel" floatingLabelText={formatMessage(messages.hintNomeCartao)} normalize={normalizeNomeCartao} tabIndex="4" />
              </Col>
            </Row>
          </ListItem>
          <ListItem key={4} notButton>
            <Row>
              <Col sm={6} xs={12} className="fieldWrapper">
                <Field name="CelularDoAdicional" component={TextField} className="redInput wFloatingLabel" floatingLabelText={formatMessage(messages.hintCelAdicional)} normalize={normalizeCelular} tabIndex="5" />
              </Col>
              <Col sm={6} xs={12} className="fieldWrapper" style={{ borderLeft: 'solid 1px #f2f2f2' }}>
                <Field name="DataNascimentoDoAdicional" component={TextField} className="redInput wFloatingLabel" floatingLabelText={formatMessage(messages.hintNascimentoAdicional)} normalize={normalizeData} tabIndex="6" />
              </Col>
            </Row>
          </ListItem>
        </div>
        <div>
          <ListItem key={5} notButton>
            <Row>
              <Col sm={6} xs={12} className="fieldWrapper">
                <Field name="NumeroCartao" component={TextField} onChange={(event, key) => { handleVerificaCartaoComChip(key); }} className="redInput wFloatingLabel" floatingLabelText={formatMessage(messages.hintNumeroCartao)} normalize={normalizeNumeroCartao} tabIndex="7" />
              </Col>
              <Col sm={6} xs={12} className="fieldWrapper" style={{ borderLeft: 'solid 1px #f2f2f2' }}>
                <Field name="CVV" component={TextField} className="redInput wFloatingLabel" floatingLabelText={formatMessage(messages.hintCodVerificadorCartao)} normalize={normalizeDigitoBilhete} tabIndex="8" />
              </Col>
            </Row>
          </ListItem>
          <ListItem key={6} notButton>
            <Field name="ApelidoCartao" component={TextField} className="redInput wFloatingLabel" floatingLabelText={formatMessage(messages.hintApelido)} tabIndex="9" />
          </ListItem>
        </div>
      </div>
    );
    let contentSenha = null;

    if (!isCartaoComChip) {
      contentSenha = isMobile() ? (
        <div className={`${isCartaoComChip && styles.associarHidden}`}>
          <ListItem key={10} notButton>
            <Field name="PinCartao" component={TextField} type="password" className="redInput wFloatingLabel" floatingLabelText={formatMessage(messages.hintSenha)} normalize={normalizeSenhaCard} tabIndex="10" />
          </ListItem>
          <ListItem key={11} notButton>
            <Field name="ConfirmePinCartao" component={TextField} type="password" className="redInput wFloatingLabel" floatingLabelText={formatMessage(messages.hintConfirmacaoSenha)} normalize={normalizeSenhaCard} tabIndex="11" />
          </ListItem>
        </div>
      ) : (
        <ListItem key={10} notButton className={`${isCartaoComChip && styles.associarHidden}`}>
          <Row>
            <Col sm={6} xs={12} className="fieldWrapper">
              <Field name="PinCartao" component={TextField} type="password" className="redInput wFloatingLabel" floatingLabelText={formatMessage(messages.hintSenha)} normalize={normalizeSenhaCard} tabIndex="10" />
            </Col>
            <Col sm={6} xs={12} className="fieldWrapper" style={{ borderLeft: 'solid 1px #f2f2f2' }}>
              <Field name="ConfirmePinCartao" component={TextField} type="password" className="redInput wFloatingLabel" floatingLabelText={formatMessage(messages.hintConfirmacaoSenha)} normalize={normalizeSenhaCard} tabIndex="11" />
            </Col>
          </Row>
        </ListItem>
      );
    }

    if (loading) {
      content = (<Loader top={0} />);
    } else {
      content = (
        <form onSubmit={handleSubmit}>
          <List>
            <ListItem key={0} notButton icon={cartaoIcon}>
              <span>{formatMessage(messages.lblAssociarCartao)}</span>
            </ListItem>
            <ListItem key={1}>
              <Field
                name="CartaoPrincipal"
                component={Toggle}
                className={styles.lblToggle}
                label={formatMessage(messages.hintCartaoPrincipal)}
                tabIndex="1"
                thumbStyle={stylesToggle.thumbOff}
                trackStyle={stylesToggle.trackOff}
                onClick={(event) => {
                  event.stopPropagation();
                  handleToggleCartaoPrincipal();
                  handleToggleClear();
                }}
              />
              <spam className={styles.lblNao}>{formatMessage(messages.hintNao)}</spam>
              <spam className={styles.lblSim}>{formatMessage(messages.hintSim)}</spam>
            </ListItem>
            <div>
              <ListItem key={2}>
                <Field
                  name="UsadoPorOutraPessoa"
                  component={Toggle}
                  className={styles.lblToggle}
                  label={formatMessage(messages.hintAdicionalDif)}
                  tabIndex="2"
                  value="yes"
                  thumbStyle={stylesToggle.thumbOff}
                  trackStyle={stylesToggle.trackOff}
                  disabled={dados.toJS().TipoCartao === 0 ? 'disabled' : ''}
                  onClick={(event) => {
                    event.stopPropagation();
                    handleToggleAssociar();
                    handleToggleClear();
                  }}
                  onLoad={this.props.handleSetUsadoPorOutraPessoa(this.props.dados.toJS())}
                />
                <spam className={styles.lblNao}>{formatMessage(messages.hintNao)}</spam>
                <spam className={styles.lblSim}>{formatMessage(messages.hintSim)}</spam>
              </ListItem>
            </div>
            {contentForm}
            {contentSenha}
          </List>
          <FlatButton name="btnContinuar" type="submit" className="redButton big centered" label={formatMessage(messages.buttonCadastrar)} disabled={pristine || submitting} tabIndex={11} />
        </form>
      );
    }
    return (
      content
    );
  }
}

AssociarCartaoForm.propTypes = {
  pristine: React.PropTypes.bool,
  submitting: React.PropTypes.bool,
  dados: React.PropTypes.object,
  loading: React.PropTypes.bool,
  handleSubmit: React.PropTypes.func,
  columnOrder: React.PropTypes.number,
  intl: intlShape.isRequired,
  handleToggleAssociar: React.PropTypes.func,
  handleToggleCartaoPrincipal: React.PropTypes.func,
  associarOutraPessoa: React.PropTypes.bool,
  handleToggleClear: React.PropTypes.func,
  handleSetUsadoPorOutraPessoa: React.PropTypes.func,
  handleVerificaCartaoComChip: React.PropTypes.func,
  isCartaoComChip: React.PropTypes.bool,
};

function mapDispatchToProps(dispatch) {
  return {
    handleToggleClear: () => {
      dispatch(change('associarCartaoForm', 'CPFDoAdicional', ''));
      dispatch(change('associarCartaoForm', 'NomeCartao', ''));
      dispatch(change('associarCartaoForm', 'CelularDoAdicional', ''));
      dispatch(change('associarCartaoForm', 'DataNascimentoDoAdicional', ''));
    },
    handleSetUsadoPorOutraPessoa: (dados) => {
      dispatch(change('associarCartaoForm', 'UsadoPorOutraPessoa', dados.UsadoPorOutraPessoa)); // eslint-disable-line no-unneeded-ternary
    },
    dispatch,
  };
}

const selector = formValueSelector('associarCartaoForm');
export default connect(
  state => {
    const CPFDoAdicionalValue = selector(state, 'CPFDoAdicional');
    const NomeCartaoValue = selector(state, 'NomeCartao');
    const CelularDoAdicionalValue = selector(state, 'CelularDoAdicional');
    const DataNascimentoDoAdicionalValue = selector(state, 'DataNascimentoDoAdicional');
    return {
      CPFDoAdicionalValue,
      NomeCartaoValue,
      CelularDoAdicionalValue,
      DataNascimentoDoAdicionalValue,
    };
  }, mapDispatchToProps)(injectIntl(reduxForm({
    form: 'associarCartaoForm',
    validate: validateAssociarCartaoForm,
  })(AssociarCartaoForm)));
