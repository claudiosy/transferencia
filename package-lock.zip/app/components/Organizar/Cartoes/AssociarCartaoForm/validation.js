import messages from 'containers/App/messages';
import { validadeCPF } from 'containers/App/validation';
import { default as compMessages } from './messages';
import moment from 'moment';

const validateAssociarCartaoForm = (valuesFromState, props) => {
  const { formatMessage } = props.intl;
  const errors = {};
  const values = valuesFromState.toJS();
  const dateNow = moment(new Date());

  if (values.UsadoPorOutraPessoa) {
    if (!values.CPFDoAdicional) {
      errors.CPFDoAdicional = formatMessage(messages.mandatoryField);
    }
    if (!validadeCPF(values.CPFDoAdicional)) {
      errors.CPFDoAdicional = formatMessage(messages.invalidCPF);
    }
    if (!values.NomeCartao) {
      errors.NomeCartao = formatMessage(messages.mandatoryField);
    } else if (values.NomeCartao.split(' ').length < 2) {
      errors.NomeCartao = formatMessage(compMessages.validationNomeCartao);
    }
    if (!values.CelularDoAdicional || values.CelularDoAdicional.length < 15) {
      errors.CelularDoAdicional = formatMessage(messages.mandatoryField);
    }
    if (values.DataNascimentoDoAdicional && values.DataNascimentoDoAdicional.length === 10 && dateNow.diff(moment(values.DataNascimentoDoAdicional, 'DD-MM-YYYY'), 'days') < 6575) {
      errors.DataNascimentoDoAdicional = formatMessage(messages.invalidData18Year);
    }
    if (!values.DataNascimentoDoAdicional || values.DataNascimentoDoAdicional.length < 10) {
      errors.DataNascimentoDoAdicional = formatMessage(messages.mandatoryField);
    }
    if (!moment(values.DataNascimentoDoAdicional, 'YYYY-MM-DD').isValid()) {
      errors.DataNascimentoDoAdicional = formatMessage(messages.invalidData);
    }
  }
  if (!values.NumeroCartao || values.NumeroCartao.length < 19) {
    errors.NumeroCartao = formatMessage(messages.mandatoryField);
  }
  if (!values.CVV || values.CVV.length < 3) {
    errors.CVV = formatMessage(messages.mandatoryField);
  }
  if (!values.ApelidoCartao) {
    errors.ApelidoCartao = formatMessage(messages.mandatoryField);
  }


  if (!values.PinCartao || values.PinCartao.length < 4) {
    errors.PinCartao = formatMessage(messages.mandatoryField);
  }
  if (!values.ConfirmePinCartao || values.ConfirmePinCartao.length < 4) {
    errors.ConfirmePinCartao = formatMessage(messages.mandatoryField);
  }
  if (values.PinCartao && values.ConfirmePinCartao && values.PinCartao !== values.ConfirmePinCartao) {
    errors.PinCartao = formatMessage(messages.notMatchingSenha);
  }
  return errors;
};

export default validateAssociarCartaoForm;
