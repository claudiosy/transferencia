import { defineMessages } from 'react-intl';

export default defineMessages({
  labelCompras: {
    id: 'app.components.Organizar.Cartoes.LimiteDiario.labelCompras',
    defaultMessage: 'PARA COMPRAS',
  },
  labelSaque: {
    id: 'app.components.Organizar.Cartoes.LimiteDiario.labelSaque',
    defaultMessage: 'PARA SAQUES',
  },
  labelAdicionar: {
    id: 'app.components.Organizar.Cartoes.LimiteDiario.labelAdicionar',
    defaultMessage: 'PARA ADICIONAR',
  },
  buttonContinuar: {
    id: 'app.components.Organizar.Cartoes.LimiteDiario.buttonContinuar',
    defaultMessage: 'Continuar',
  },
});
