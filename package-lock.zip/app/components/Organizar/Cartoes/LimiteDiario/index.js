import React from 'react';
import { connect } from 'react-redux';
import { reduxForm, Field, formValueSelector } from 'redux-form/immutable';
import { Slider } from 'redux-form-material-ui';
import FlatButton from 'material-ui/FlatButton';
import { injectIntl, intlShape, FormattedNumber } from 'react-intl';
import messages from './messages';
import Loader from 'components/Loader';
import List from 'components/List';
import ListItem from 'components/ListItem';
import styles from './styles.css';

class LimiteDiario extends React.Component { // eslint-disable-line react/prefer-stateless-function
  render() {
    const { handleSubmit, limiteComprasValue, limiteSaqueValue, limits, loading } = this.props;
    const { LimiteCompra, LimiteSaque, LimiteCompraMaximo, LimiteSaqueMaximo } = limits.toJS();
    const { formatMessage } = this.props.intl;
    const minCompras = 0;
    const minSaque = 0;
    const intLimiteCompraMaximo = LimiteCompra > LimiteCompraMaximo ? LimiteCompra : LimiteCompraMaximo;
    const intLimiteSaqueMaximo = LimiteSaque > LimiteSaqueMaximo ? LimiteSaque : LimiteSaqueMaximo;
    let content = (
      <div className={styles.limits}>
        <List>
          <ListItem key={1} notButton >
            <span>{formatMessage(messages.labelCompras)}</span>
            <span className={styles.valor}><FormattedNumber style="currency" currency="BRL" value={limiteComprasValue} /></span>
            <Field
              name="LimiteCompra"
              component={Slider}
              min={minCompras}
              max={intLimiteCompraMaximo}
              step={10}
              tabIndex="1"
            />
            <span className={`${styles.descricaoValores} ${styles.itemLeft}`}><FormattedNumber minimumFractionDigits={2} style="currency" currency="BRL" value={minCompras} /></span>
            <span className={`${styles.descricaoValores} ${styles.itemRight}`}><FormattedNumber minimumFractionDigits={2} style="currency" currency="BRL" value={intLimiteCompraMaximo} /></span>
          </ListItem>
          <ListItem key={2} notButton >
            <span>{formatMessage(messages.labelSaque)} <span className={styles.valor}><FormattedNumber minimumFractionDigits={2} style="currency" currency="BRL" value={limiteSaqueValue} /></span></span>
            <Field
              name="LimiteSaque"
              component={Slider}
              min={minSaque}
              max={intLimiteSaqueMaximo}
              step={10}
              tabIndex="2"
            />
            <span className={`${styles.descricaoValores} ${styles.itemLeft}`}><FormattedNumber minimumFractionDigits={2} style="currency" currency="BRL" value={minSaque} /></span>
            <span className={`${styles.descricaoValores} ${styles.itemRight}`}><FormattedNumber minimumFractionDigits={2} style="currency" currency="BRL" value={intLimiteSaqueMaximo} /></span>
          </ListItem>
        </List>
        <FlatButton name="btnContinuar" type="submit" className="redButton big centered" label={formatMessage(messages.buttonContinuar)} tabIndex="4" />
      </div>
    );

    if (loading) {
      content = (<Loader />);
    }

    return (
      <form onSubmit={handleSubmit} className={styles.ListSlider}>
        {content}
      </form>
    );
  }
}

LimiteDiario.propTypes = {
  handleSubmit: React.PropTypes.func,
  limiteComprasValue: React.PropTypes.number,
  limiteSaqueValue: React.PropTypes.number,
  LimiteCompra: React.PropTypes.number,
  LimiteSaque: React.PropTypes.number,
  limits: React.PropTypes.object,
  loading: React.PropTypes.bool,
  open: React.PropTypes.bool,
  intl: intlShape.isRequired,
};

const selector = formValueSelector('limiteDiarioForm');
LimiteDiario = connect( // eslint-disable-line
  state => {
    // can select values individually
    const limiteComprasValue = selector(state, 'LimiteCompra');
    const limiteSaqueValue = selector(state, 'LimiteSaque');
    return {
      limiteComprasValue,
      limiteSaqueValue,
    };
  }
)(LimiteDiario);

export default injectIntl(reduxForm({
  form: 'limiteDiarioForm',
  enableReinitialize: true,
})(LimiteDiario));
