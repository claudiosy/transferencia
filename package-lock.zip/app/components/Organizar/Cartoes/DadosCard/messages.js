import { defineMessages } from 'react-intl';

export default defineMessages({
  validade: {
    id: 'app.components.Organizar.Cartoes.DadosCard.validade',
    defaultMessage: 'VALIDADE:',
  },
  cardAtivo: {
    id: 'app.components.Organizar.Cartoes.DadosCard.cardAtivo',
    defaultMessage: 'ATIVO',
  },
  cardBloqueado: {
    id: 'app.components.Organizar.Cartoes.DadosCard.cardBloqueado',
    defaultMessage: 'BLOQUEADO',
  },
});
