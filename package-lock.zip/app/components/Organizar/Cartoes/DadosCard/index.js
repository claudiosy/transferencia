import React from 'react';
import { injectIntl, intlShape, FormattedNumber } from 'react-intl';
import { connect } from 'react-redux';
import { Toggle } from 'redux-form-material-ui';
import moment from 'moment';
import messages from './messages';
import styles from './styles.css';
import { reduxForm, Field, change, formValueSelector } from 'redux-form/immutable';
import iconBandeiraCard from './bandeiraCard.png';
import comprasOnlineIcon from 'components/SideMenu/compras-online.png';
import personIcon from 'containers/App/white-person-icon.png';
// import iconBloqCard from './cardBloqueado.png';

class DadosCard extends React.Component {
  componentWillMount() {
    this.props.handleLoadStatus(this.props.dadosCartao.StatusCartao);
  }
  detailsHeader(objeto) {
    let content;
    if (objeto.TipoIndividualizacaoId === 0) {
      content = (<span>{objeto.Apelido}</span>);
    } else if (objeto.TipoIndividualizacaoId === 1) {
      content = (<span><img src={personIcon} className={styles.icon} alt="" />{objeto.Apelido}</span>);
    } else if (objeto.TipoIndividualizacaoId === 3) {
      content = (<span><img src={comprasOnlineIcon} className={styles.icon} alt="" style={{ width: '21px' }} />{objeto.Apelido}</span>);
    }
    return (
      <div style={{ width: '100%' }}>
        <div style={{ float: 'left' }}>
          <h1 className={styles.headerName}>{objeto.NomePortador}</h1>
          <h3 className={styles.headerTitle}>{content}</h3>
        </div>
        <span style={{ float: 'right' }}>
          <img src={iconBandeiraCard} className={styles.headerImg} alt="" />
        </span>
      </div>
    );
  }
  detailsRow(titulo, classe, moeda, siglaMoeda) {
    let content;
    if (moeda) {
      content = (<FormattedNumber minimumFractionDigits={2} style="currency" currency={siglaMoeda} value={titulo} />);
    } else {
      content = (titulo);
    }
    return (
      <div className={styles.detailsRow}>
        <h2 className={`${styles.detailsRowTitle} ${(classe ? styles.numberCard : '')}`}>
          {content}
        </h2>
      </div>
    );
  }

  render() {
    const { dadosCartao, flgStatusCartao, handleToggle } = this.props;
    const { formatMessage } = this.props.intl;
    const stylesToggle = {
      thumbOff: {
        backgroundColor: '#fff',
      },
      trackOff: {
        backgroundColor: 'red',
      },
    };
    const contentSaldo = dadosCartao.TipoIndividualizacaoId === 0 ? '' : this.detailsRow(dadosCartao.SaldoDisponivel, false, true, dadosCartao.SiglaMoeda);
    return (
      <form>
        <div className={`${styles.mainCard} ${dadosCartao.TipoIndividualizacaoId === 3 && styles.virtCard}`}>
          <header className={`card-header-details ${styles.cardHeader}`}>
            {this.detailsHeader(dadosCartao)}
          </header>
          <div>
            {this.detailsRow(dadosCartao.NumeroCartaoMascarado, true, false, '')}
            {contentSaldo}
            <span className={styles.contentImg}>
              <Field
                name="StatusCartao"
                component={Toggle}
                className={`${dadosCartao.StatusCartao === '20' ? '' : styles.toggleAtivo} ${styles.toggle}`}
                // label={formatMessage(messages.hintAdicionalDif)}
                tabIndex="2"
                thumbStyle={stylesToggle.thumbOff}
                trackStyle={stylesToggle.trackOff}
                // onToggle={handleToggle(flgStatusCartao, dadosCartao.StatusCartao)}
                onClick={(event) => {
                  event.stopPropagation();
                  handleToggle(flgStatusCartao, dadosCartao.StatusCartao, dadosCartao.CartaoId);
                }}
              />
              <h4>{dadosCartao.StatusCartao === '20' ? formatMessage(messages.cardBloqueado) : formatMessage(messages.cardAtivo) }</h4>
            </span>
          </div>
          <div>
            <span className={styles.cardFooter}>
              {formatMessage(messages.validade)}
              <h4>{moment(new Date(dadosCartao.DataValidade)).format('MM/YY')}</h4>
            </span>
          </div>
        </div>
      </form>
    );
  }
}

DadosCard.propTypes = {
  dadosCartao: React.PropTypes.object,
  flgStatusCartao: React.PropTypes.bool,
  handleLoadStatus: React.PropTypes.func,
  handleToggle: React.PropTypes.func,
  intl: intlShape.isRequired,
};

function mapDispatchToProps(dispatch) {
  return {
    handleLoadStatus: (StatusCartao) => {
      dispatch(change('dadosCardForm', 'StatusCartao', StatusCartao === '01' ? true : false)); // eslint-disable-line no-unneeded-ternary
    },
    dispatch,
  };
}

const selector = formValueSelector('dadosCardForm');
export default connect(
  state => {
    const flgStatusCartao = selector(state, 'StatusCartao');
    return {
      flgStatusCartao,
    };
  }, mapDispatchToProps)(injectIntl(reduxForm({
    form: 'dadosCardForm',
  })(DadosCard)));
