import { defineMessages } from 'react-intl';

export default defineMessages({
  hintNovaSenha: {
    id: 'app.components.Organizar.Cartoes.AlterarSenhaForm.hintNovaSenha',
    defaultMessage: 'NOVA SENHA',
  },
  hintConfirmNovaSenha: {
    id: 'app.components.Organizar.Cartoes.AlterarSenhaForm.hintConfirmNovaSenha',
    defaultMessage: 'CONFIRMAR NOVA SENHA',
  },
  buttonContinuar: {
    id: 'app.components.Organizar.Cartoes.AlterarSenhaForm.buttonContinuar',
    defaultMessage: 'Continuar',
  },
});
