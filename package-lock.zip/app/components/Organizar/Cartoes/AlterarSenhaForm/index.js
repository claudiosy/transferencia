import React from 'react';
import { reduxForm, Field } from 'redux-form/immutable';

import { TextField } from 'redux-form-material-ui';
import FlatButton from 'material-ui/FlatButton';
import validateAlterarSenhaForm from './validation';
import { injectIntl, intlShape } from 'react-intl';
import messages from './messages';

import List from 'components/List';
import ListItem from 'components/ListItem';
import { normalizeSenhaCard } from 'normalizers';

class AlterarSenhaForm extends React.Component { // eslint-disable-line react/prefer-stateless-function
  render() {
    const { handleSubmit, pristine, submitting } = this.props;
    const { formatMessage } = this.props.intl;
    return (
      <form onSubmit={handleSubmit}>
        <List>
          <ListItem key={1}>
            <Field autoFocus name="NovaSenha" component={TextField} type="password" className="redInput wFloatingLabel" floatingLabelText={formatMessage(messages.hintNovaSenha)} normalize={normalizeSenhaCard} tabIndex="1" />
          </ListItem>
          <ListItem key={2}>
            <Field name="ConfirmSenhaNova" component={TextField} type="password" className="redInput wFloatingLabel" floatingLabelText={formatMessage(messages.hintConfirmNovaSenha)} normalize={normalizeSenhaCard} tabIndex="2" />
          </ListItem>
        </List>
        <FlatButton name="btnContinuar" type="submit" className="redButton big centered" label={formatMessage(messages.buttonContinuar)} disabled={pristine || submitting} tabIndex={3} />
      </form>
    );
  }
}

AlterarSenhaForm.propTypes = {
  handleSubmit: React.PropTypes.func,
  pristine: React.PropTypes.bool,
  submitting: React.PropTypes.bool,
  intl: intlShape.isRequired,
};

export default injectIntl(reduxForm({
  form: 'alterarSenhaForm',
  validate: validateAlterarSenhaForm,
  enableReinitialize: true,
})(AlterarSenhaForm));
