import messages from 'containers/App/messages';

const validateAlterarSenhaForm = (valuesFromState, props) => {
  const { formatMessage } = props.intl;
  const errors = {};
  const values = valuesFromState.toJS();

  if (!values.NovaSenha || values.NovaSenha.length < 4) {
    errors.NovaSenha = formatMessage(messages.mandatoryField);
  }
  if (!values.ConfirmSenhaNova || values.ConfirmSenhaNova.length < 4) {
    errors.ConfirmSenhaNova = formatMessage(messages.mandatoryField);
  }
  if (values.NovaSenha && values.ConfirmSenhaNova && values.NovaSenha !== values.ConfirmSenhaNova) {
    errors.NovaSenha = formatMessage(messages.notMatchingSenha);
  }

  return errors;
};

export default validateAlterarSenhaForm;
