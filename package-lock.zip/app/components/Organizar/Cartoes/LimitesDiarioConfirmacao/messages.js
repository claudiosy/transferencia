import { defineMessages } from 'react-intl';

export default defineMessages({
  header: {
    id: 'app.components.Organizar.Cartoes.LimitesDiarioConfirmacao.header',
    defaultMessage: 'Confirme os dados',
  },
  labelLimiteCompra: {
    id: 'app.components.Organizar.Cartoes.LimitesDiarioConfirmacao.labelLimiteCompra',
    defaultMessage: 'PARA COMPRAS',
  },
  labelLimiteSaque: {
    id: 'app.components.Organizar.Cartoes.LimitesDiarioConfirmacao.labelLimiteSaque',
    defaultMessage: 'PARA SAQUE',
  },
  labelLimiteAdicionar: {
    id: 'app.components.Organizar.Cartoes.LimitesDiarioConfirmacao.labelLimiteAdicionar',
    defaultMessage: 'PARA ADICIONAR',
  },
  infoConfirmLimits1: {
    id: 'app.components.Organizar.Cartoes.LimitesDiarioConfirmacao.infoConfirmLimits1',
    defaultMessage: 'Mesmo aumentando o limite,',
  },
  infoConfirmLimits2: {
    id: 'app.components.Organizar.Cartoes.LimitesDiarioConfirmacao.infoConfirmLimits2',
    defaultMessage: 'Você precisa ter saldo para usá-lo.',
  },
  buttonConfirmar: {
    id: 'app.components.Organizar.Cartoes.LimitesDiarioConfirmacao.buttonConfirmar',
    defaultMessage: 'Confirmar',
  },
});
