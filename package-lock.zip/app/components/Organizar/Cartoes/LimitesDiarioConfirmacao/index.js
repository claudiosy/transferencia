import React from 'react';

import FlatButton from 'material-ui/FlatButton';
import { FormattedMessage, injectIntl, intlShape, FormattedNumber } from 'react-intl';
import messages from './messages';
import List from 'components/List';
import ListItem from 'components/ListItem';
import styles from './styles.css';

const LimitesDiarioConfirmacao = props => {
  const { onConfirm, confirmData } = props;
  const { LimiteCompra, LimiteSaque } = confirmData.toJS();
  const { formatMessage } = props.intl;

  const content = (
    <form>
      <h4 className="list-title">{formatMessage(messages.header)} </h4>
      <List>
        <ListItem key={1} notButton >
          <FormattedMessage {...messages.labelLimiteCompra} />
          <span className="align-right"><FormattedNumber minimumFractionDigits={2} style="currency" currency="BRL" value={LimiteCompra} /></span>
        </ListItem>
        <ListItem key={2} notButton>
          <FormattedMessage {...messages.labelLimiteSaque} />
          <span className="align-right"><FormattedNumber minimumFractionDigits={2} style="currency" currency="BRL" value={LimiteSaque} /></span>
        </ListItem>
      </List>
      <div className={styles.infoConfirm}>
        {formatMessage(messages.infoConfirmLimits1)}
        <br />
        {formatMessage(messages.infoConfirmLimits2)}
      </div>
      <FlatButton name="btnConfirmar" onMouseUp={onConfirm} className="redButton big centered" label={formatMessage(messages.buttonConfirmar)} tabIndex="1" />
    </form>
  );

  return (
    <div>
      {content}
    </div>
  );
};

LimitesDiarioConfirmacao.propTypes = {
  onConfirm: React.PropTypes.func,
  confirmData: React.PropTypes.object,
  intl: intlShape.isRequired,
};

export default injectIntl(LimitesDiarioConfirmacao);
