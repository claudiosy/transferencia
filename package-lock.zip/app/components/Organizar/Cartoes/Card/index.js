import React from 'react';
import stylesheet from './styles.css';

/* eslint-disable */

class Card extends React.Component {
	constructor(props) {
		super(props);
		this.state = {
			hover: false,
		};
	}

	handleClick () {
		const { cartaoId, apelidoCard, handleStepChange, isHover } = this.props;
		const ModalidadeId = this.props.children.props.dadosCartao.ModalidadeId;
		if (isHover)
			handleStepChange(1, cartaoId, cartaoId, apelidoCard, ModalidadeId);
	}

	render () {
		const { cardId, cardType, cardIsBlocked, cardSelected, topOffset, hoverOffset, isHover, cardSpace } = this.props;
		const offset = (cardId !== 0) && this.state.hover && !cardSelected ? hoverOffset : 0;
		const transform = `translate3d(0,${cardSpace - offset}px,0)`;
		const cardStyles = {
			...styles,
			background: this.props.background,
			transform,
			WebkitTransform: transform,
			height: this.props.height,
		};

		let cardClass = "";

		if (cardIsBlocked) {
			cardClass = stylesheet.blocked;
		}

		if (cardType === 3) {
			cardClass = `${cardClass} ${stylesheet.virtual}`;
		}

		return (
			<li
				name={`Cartao_${cardId}`}
				style={cardStyles}
				className={cardClass}
				onClick={this.handleClick.bind(this)}
				onMouseEnter={() => this.setState({ hover: isHover })}
				onMouseLeave={() => this.setState({ hover: false })}>
					{this.props.children}
			</li>
		);
	}
}

const styles = {
	position: 'absolute',
	top: 0,
	width: '100%',
	cursor: 'pointer',
	transition: '0.5s transform ease',
	WebkitTransition: '-webkit-transform 0.5s ease',
};

Card.propTypes = {
  cardId: React.PropTypes.number,
	cardType: React.PropTypes.number,
  cardSelected: React.PropTypes.bool,
	cardIsBlocked: React.PropTypes.bool,
  topOffset: React.PropTypes.number,
  hoverOffset: React.PropTypes.number,
  background: React.PropTypes.string,
  height: React.PropTypes.number,
	cartaoId: React.PropTypes.number,
	apelidoCard: React.PropTypes.string,
	children: React.PropTypes.object,
	isHover: React.PropTypes.bool,
	cardSpace: React.PropTypes.number,
};

export default Card;
