import React from 'react';
import { connect } from 'react-redux';
import { reduxForm, Field, formValueSelector } from 'redux-form/immutable';
import FlatButton from 'material-ui/FlatButton';
import { SelectField, DatePicker } from 'redux-form-material-ui';
import areIntlLocalesSupported from 'intl-locales-supported';
import List from 'components/List';
import ListItem from 'components/ListItem';
import styles from './styles.css';
import calendarioIcon from './calendario-icon.png';
import CircularProgress from 'material-ui/CircularProgress';
import SelectItem from 'components/SelectItem';

import { FormattedMessage, injectIntl, intlShape } from 'react-intl';
import messages from './messages';
import validateAvisoViagem from './validation';

let DateTimeFormat;
/**
 * Use the native Intl.DateTimeFormat if available, or a polyfill if not.
 */
if (areIntlLocalesSupported('pt-BR')) {
  DateTimeFormat = global.Intl.DateTimeFormat;
} else {
  const IntlPolyfill = require('intl'); // eslint-disable-line global-require
  DateTimeFormat = IntlPolyfill.DateTimeFormat;
  require('intl/locale-data/jsonp/pt-BR'); // eslint-disable-line global-require
}

class AvisoViagem extends React.Component { // eslint-disable-line react/prefer-stateless-function
  render() {
    const { handleSubmit, pristine, submitting, destinos, periodoStartValue, loading } = this.props;
    const { formatMessage } = this.props.intl;

    let content;

    const minDate = new Date();
    const maxDate = new Date();
    maxDate.setMinutes(minDate.getMinutes() + 7200);

    if (loading) {
      content = (
        <List showProceedIcon>
          <ListItem key={-3} showProceedIcon={false}>
            <span className={styles.loaderWrapper}>
              <CircularProgress size={0.3} />
            </span>
            <FormattedMessage {...messages.loadingDestinos} />
          </ListItem>
        </List>
      );
    } else {
      content = (
        <form onSubmit={handleSubmit}>
          <List>
            <ListItem key={1}>
              <SelectItem
                selectData={destinos}
                name="Pais"
                component={SelectField}
                className="redInput"
                hintText={formatMessage(messages.labelDestino)}
                tabIndex="1"
                autoWidth
              />
            </ListItem>

            <ListItem key={2} icon={calendarioIcon}>
              <Field
                name="InicioViagem"
                component={DatePicker}
                hintText={formatMessage(messages.labelPeriodoStart)}
                locale="pt-BR"
                cancelLabel="Cancelar"
                okLabel="OK"
                autoOk
                minDate={minDate}
                DateTimeFormat={DateTimeFormat}
                className={`${styles.inputDate} redInput commonInput`}
                tabIndex="2"
              />
            </ListItem>
            <ListItem key={3} icon={calendarioIcon}>
              <Field
                name="FimViagem"
                component={DatePicker}
                hintText={formatMessage(messages.labelPeriodoEnd)}
                locale="pt-BR"
                cancelLabel="Cancelar"
                okLabel="OK"
                autoOk
                minDate={new Date(periodoStartValue)}
                DateTimeFormat={DateTimeFormat}
                className={`${styles.inputDate} redInput commonInput`}
                tabIndex="3"
              />
            </ListItem>
          </List>
          <FlatButton name="btnFinalizar" className="redButton big centered" type="submit" label={formatMessage(messages.submitButton)} disabled={pristine || submitting} tabIndex="4" />
        </form>
      );
    }
    return (
      <div>
        {content}
      </div>);
  }
}

AvisoViagem.propTypes = {
  loading: React.PropTypes.bool,
  handleSubmit: React.PropTypes.func,
  pristine: React.PropTypes.bool,
  submitting: React.PropTypes.bool,
  destinos: React.PropTypes.object,
  Pais: React.PropTypes.number,
  InicioViagem: React.PropTypes.string,
  FimViagem: React.PropTypes.string,
  periodoStartValue: React.PropTypes.string,
  intl: intlShape.isRequired,
};

const selector = formValueSelector('avisoViagemForm');
AvisoViagem = connect( // eslint-disable-line
  state => {
    // can select values individually
    const periodoStartValue = selector(state, 'InicioViagem');

    return {
      periodoStartValue,
    };
  }
)(AvisoViagem);

export default injectIntl(reduxForm({
  form: 'avisoViagemForm',
  validate: validateAvisoViagem,
})(AvisoViagem));
