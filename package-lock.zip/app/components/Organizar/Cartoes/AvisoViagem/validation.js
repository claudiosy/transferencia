import messages from 'containers/App/messages';
// import moment from 'moment';

const validateAvisoViagem = (valuesFromState, props) => {
  const { formatMessage } = props.intl;
  const errors = {};
  const values = valuesFromState.toJS();

  if (!values.Pais) {
    errors.Pais = formatMessage(messages.mandatoryField);
  }
  if (!values.InicioViagem) {
    errors.InicioViagem = formatMessage(messages.mandatoryField);
  }
  if (!values.FimViagem) {
    errors.FimViagem = formatMessage(messages.mandatoryField);
  }
  /*
  if (!moment(values.periodo, 'YYYY-MM-DD').isValid()) {
    errors.vencimento = formatMessage(messages.invalidData);
  }
  */
  return errors;
};

export default validateAvisoViagem;
