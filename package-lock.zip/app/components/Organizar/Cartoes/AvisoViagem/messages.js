import { defineMessages } from 'react-intl';

export default defineMessages({
  labelDestino: {
    id: 'app.components.Organizar.Cartoes.AvisoViagem.labelDestino',
    defaultMessage: 'Escolha seu destino',
  },
  loadingDestinos: {
    id: 'app.components.Organizar.Cartoes.AvisoViagem.loadingDestinos',
    defaultMessage: 'Carregando os destinos...',
  },
  labelPeriodoStart: {
    id: 'app.components.Organizar.Cartoes.AvisoViagem.labelPeriodoStart',
    defaultMessage: 'Selecione a ida',
  },
  labelPeriodoEnd: {
    id: 'app.components.Organizar.Cartoes.AvisoViagem.labelPeriodoEnd',
    defaultMessage: 'Selecione a volta',
  },
  submitButton: {
    id: 'app.components.Organizar.Cartoes.AvisoViagem.submitButton',
    defaultMessage: 'Finalizar',
  },
});
