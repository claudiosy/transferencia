import { defineMessages } from 'react-intl';

export default defineMessages({
  header: {
    id: 'app.components.Organizar.Cartoes.SegundaViaCartaoConfirmacao.header',
    defaultMessage: 'SEGUNDA VIA CARTÃO',
  },
  buttonConfirmar: {
    id: 'app.components.Organizar.Cartoes.SegundaViaCartaoConfirmacao.buttonConfirmar',
    defaultMessage: 'Continuar',
  },
});
