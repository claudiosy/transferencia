import React from 'react';

import FlatButton from 'material-ui/FlatButton';
import { injectIntl, intlShape } from 'react-intl';
import messages from './messages';
import List from 'components/List';
import ListItem from 'components/ListItem';
import styles from './styles.css';
import infoIcon from './info-icon.png';
import CartoesIcon from './cartoes-icon.png';

const SegundaViaCartaoConfirmacao = props => {
  const { onConfirm, resposta } = props;
  const { formatMessage } = props.intl;
  const dadosResposta = resposta && resposta.toJS();
  const content = (
    <form className={styles.ListLong}>
      <h4 className="list-title"><img src={CartoesIcon} alt="" className={styles.leftIcon} /> {formatMessage(messages.header)} </h4>
      <List>
        <ListItem key={1} notButton icon={infoIcon} >
          <span>{dadosResposta.Condicao}</span>
        </ListItem>
      </List>
      <FlatButton name="btnConfirmar" onClick={() => onConfirm(dadosResposta.CobrarTarifa)} className="redButton big centered" label={formatMessage(messages.buttonConfirmar)} tabIndex="1" />
    </form>
  );

  return (
    <div>
      {content}
    </div>
  );
};

SegundaViaCartaoConfirmacao.propTypes = {
  onConfirm: React.PropTypes.func,
  resposta: React.PropTypes.object,
  intl: intlShape.isRequired,
};

export default injectIntl(SegundaViaCartaoConfirmacao);
