/* eslint-disable */

import React from 'react';
import { connect } from 'react-redux';
import { reduxForm, Field, change, formValueSelector } from 'redux-form/immutable';
import { TextField, SelectField } from 'redux-form-material-ui';
import FlatButton from 'material-ui/FlatButton';
import MenuItem from 'material-ui/MenuItem';
import validateAdicionarCartaoForm from './validation';
import { injectIntl, intlShape } from 'react-intl';
import messages from './messages';
import List from 'components/List';
import ListItem from 'components/ListItem';
import auth from 'utils/auth';
import { normalizeNomeCartao } from 'normalizers/index';
import cartaoIcon from 'containers/Organizar/CartoesPage/cartoes-icon.png';

class AdicionarCartaoForm extends React.Component {
  constructor(props) {
    super(props);
    this.state = { senhaFocus: false };
  }
  render() {
    const { handleSubmit, pristine, submitting, tipoCartaoValue, handleTipoCartao, possuiCardPrincipal, pedirAdicional } = this.props;
    const { formatMessage } = this.props.intl;
    const content = (
      <form onSubmit={handleSubmit}>
        <List>
          <ListItem key={0} icon={cartaoIcon}>
            <span>{formatMessage(messages.lblPedirCartao)}</span>
          </ListItem>
          <ListItem key={1}>
            <Field name="TipoCartao" component={SelectField} className="redInput" hintText={formatMessage(messages.hintTipoCartao)} tabIndex="1" /* onChange={(event) => handleTipoCartao(event)} */>
              <MenuItem value={0} primaryText="Principal" style={!possuiCardPrincipal ? { display: 'block' } : { display: 'none' }} disabled={pedirAdicional} />
              <MenuItem value={1} primaryText="Adicional" />
              <MenuItem value={3} primaryText="Virtual" disabled={pedirAdicional} />
            </Field>
          </ListItem>
          <ListItem key={4} notButton invisibled={!tipoCartaoValue && tipoCartaoValue < 0}>
            <Field name="NomeCartao" component={TextField} className="redInput wFloatingLabel" normalize={normalizeNomeCartao} floatingLabelText={formatMessage(messages.hintNomeCartao)} tabIndex="2" /* disabled={tipoCartaoValue !== 1 ? true : false} */ />
          </ListItem>
          <ListItem key={5} invisibled={!tipoCartaoValue && tipoCartaoValue < 0}>
            <Field name="Apelido" component={TextField} className="redInput wFloatingLabel" floatingLabelText={formatMessage(messages.hintApelido)} tabIndex="3" />
          </ListItem>
        </List>
        <FlatButton name="btnContinuar" type="submit" className="redButton big centered" label={formatMessage(messages.buttonCadastrar)} disabled={pristine || submitting} tabIndex={4} />
      </form>
      );
    return (
      content
    );
  }
}

AdicionarCartaoForm.propTypes = {
  pristine: React.PropTypes.bool,
  submitting: React.PropTypes.bool,
  tipoCartaoValue: React.PropTypes.number,
  nomeCartaoValue: React.PropTypes.string,
  handleSubmit: React.PropTypes.func,
  TipoCartao: React.PropTypes.number,
  NomeCartao: React.PropTypes.string,
  Apelido: React.PropTypes.string,
  columnOrder: React.PropTypes.number,
  handleTipoCartao: React.PropTypes.func,
  possuiCardPrincipal: React.PropTypes.bool,
  intl: intlShape.isRequired,
  pedirAdicional: React.PropTypes.bool,
};


function mapDispatchToProps(dispatch) {
  return {
    handleTipoCartao: (valor) => {
      const nomeUsuario = auth.getUserName();
      if (valor === 1) {
        dispatch(change('adicionarCartaoForm', 'NomeCartao', ''));
      } else {
        dispatch(change('adicionarCartaoForm', 'NomeCartao', nomeUsuario));
      }
    },
    dispatch,
  };
}

const selector = formValueSelector('adicionarCartaoForm');
export default connect(
  state => {
    // can select values individually
    const tipoCartaoValue = selector(state, 'TipoCartao');
    const nomeCartaoValue = selector(state, 'TipoCartao') === 1 ? '' : selector(state, 'NomeCartao');
    return {
      tipoCartaoValue,
      nomeCartaoValue,
    };
  }, mapDispatchToProps)(injectIntl(reduxForm({
    form: 'adicionarCartaoForm',
    validate: validateAdicionarCartaoForm,
    enableReinitialize: true,
  })(AdicionarCartaoForm)));
