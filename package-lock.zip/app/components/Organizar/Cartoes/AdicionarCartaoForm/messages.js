import { defineMessages } from 'react-intl';

export default defineMessages({
  hintTipoCartao: {
    id: 'app.components.Organizar.Cartoes.AdicionarCartaoForm.hintTipoCartao',
    defaultMessage: 'Tipo do Cartão',
  },
  lblPedirCartao: {
    id: 'app.components.Organizar.Cartoes.AdicionarCartaoForm.lblPedirCartao',
    defaultMessage: 'PEDIR CARTÃO',
  },
  hintAdicionalDif: {
    id: 'app.components.Organizar.Cartoes.AdicionarCartaoForm.hintAdicionalDif',
    defaultMessage: 'Será usado por outra pessoa?',
  },
  hintNomeCartao: {
    id: 'app.components.MOrganizar.Cartoes.AdicionarCartaoForm.hintNomeCartao',
    defaultMessage: 'Nome do Usuário do Cartão',
  },
  hintCPFAdicional: {
    id: 'app.components.Organizar.Cartoes.AdicionarCartaoForm.hintCPFAdicional',
    defaultMessage: 'CPF do Adicional',
  },
  hintNascimentoAdicional: {
    id: 'app.components.Organizar.Cartoes.AdicionarCartaoForm.hintNascimentoAdicional',
    defaultMessage: 'Data Nasc. do Adicional',
  },
  hintCelAdicional: {
    id: 'app.components.Organizar.Cartoes.AdicionarCartaoForm.hintCelAdicional',
    defaultMessage: 'Celular do Adicional',
  },
  hintApelido: {
    id: 'app.components.Organizar.Cartoes.AdicionarCartaoForm.hintApelido',
    defaultMessage: 'Apelido do Cartão',
  },
  hintSenha: {
    id: 'app.components.Organizar.Cartoes.AdicionarCartaoForm.hintSenha',
    defaultMessage: 'Senha do Cartão',
  },
  hintConfirmacaoSenha: {
    id: 'app.components.Organizar.Cartoes.AdicionarCartaoForm..hintConfirmacaoSenha',
    defaultMessage: 'Confirmar Senha',
  },
  hintMsgSenha: {
    id: 'app.components.Organizar.Cartoes.AdicionarCartaoForm.hintMsgSenha',
    defaultMessage: '6 dígitos numéricos',
  },
  buttonCadastrar: {
    id: 'app.components.Organizar.Cartoes.AdicionarCartaoForm.buttonCadastrar',
    defaultMessage: 'Continuar',
  },
  validationNomeCartao: {
    id: 'app.components.Organizar.Cartoes.AdicionarCartaoForm.validationNomeCartao',
    defaultMessage: 'O nome deve conter ao menos duas palavras',
  },
});
