import messages from 'containers/App/messages';
import { default as compMessages } from './messages';

const validateAdicionarCartaoForm = (valuesFromState, props) => {
  const { formatMessage } = props.intl;
  const errors = {};
  const values = valuesFromState.toJS();

  if (!values.NomeCartao) {
    errors.NomeCartao = formatMessage(messages.mandatoryField);
  } else if (values.NomeCartao.split(' ').length < 2) {
    errors.NomeCartao = formatMessage(compMessages.validationNomeCartao);
  }
  if (!values.Apelido) {
    errors.Apelido = formatMessage(messages.mandatoryField);
  }
  return errors;
};

export default validateAdicionarCartaoForm;
