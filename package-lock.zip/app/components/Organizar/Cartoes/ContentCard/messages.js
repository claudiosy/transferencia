import { defineMessages } from 'react-intl';

export default defineMessages({
  validade: {
    id: 'app.components.Organizar.Cartoes.ContentCard.validade',
    defaultMessage: 'VALIDADE',
  },
  cardAtivo: {
    id: 'app.components.Organizar.Cartoes.ContentCard.cardAtivo',
    defaultMessage: 'ATIVO',
  },
  cardBloqueado: {
    id: 'app.components.Organizar.Cartoes.ContentCard.cardBloqueado',
    defaultMessage: 'BLOQUEADO',
  },
});
