import { defineMessages } from 'react-intl';

export default defineMessages({
  header: {
    id: 'app.components.Organizar.Cartoes.ExtratoCartao.header',
    defaultMessage: 'EXTRATO',
  },
  loadingExtrato: {
    id: 'app.components.Organizar.Cartoes.ExtratoCartao.loadingExtrato',
    defaultMessage: 'Carregando o extrato...',
  },
  noItens: {
    id: 'app.components.Organizar.Cartoes.ExtratoCartao.noItens',
    defaultMessage: 'Não há lançamentos neste período',
  },
});
