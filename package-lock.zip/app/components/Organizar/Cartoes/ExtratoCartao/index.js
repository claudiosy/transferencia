import React from 'react';
import styles from './styles.css';
import messages from './messages';
// import { FormattedMessage } from 'react-intl';
import HeaderExtrato from 'components/Organizar/Cartoes/HeaderExtrato';
import ContentExtrato from 'components/Organizar/Cartoes/ContentExtrato';
import List from 'components/List';
import ListItem from 'components/ListItem';
import CircularProgress from 'material-ui/CircularProgress';
import { FormattedMessage } from 'react-intl';
import iconInfo from 'containers/App/icon-info.png';

function ExtratoCartao(props) {
  const { extrato, handleFiltroDatasSubmit, handleResetMonth, handleSetMonth, filtroExtrato, filtroDatas, datesFiltered, loading } = props;
  let count = 0;
  let content;
  const extratoList = extrato.toJS();
  const extratoItem = extratoList && extratoList.map((item) => { // eslint-disable-line arrow-body-style
    count++;
    return (
      <div>
        <ContentExtrato dadosExtrato={item} />
        <div className={`${count < extratoList.length ? styles.separator : ''}`}></div>
      </div>
    );
  });

  if (loading) {
    content = (
      <List showProceedIcon>
        <ListItem key={-3} showProceedIcon={false}>
          <span className={styles.loaderWrapper}>
            <CircularProgress size={0.3} />
          </span>
          <FormattedMessage {...messages.loadingExtrato} />
        </ListItem>
      </List>
    );
  } else if (extratoList.length > 0) {
    content = (
      <div className={`${styles.extratoWrapper}`}>
        {extratoItem}
      </div>
    );
  } else {
    content = (
      <List>
        <ListItem key={-4} showProceedIcon={false} informative icon={iconInfo} autoHeight>
          <FormattedMessage {...messages.noItens} />
        </ListItem>
      </List>
    );
  }

  return (
    // eslint-disable-next-line react/jsx-boolean-value
    <div>
      <HeaderExtrato datesFiltered={datesFiltered} filtroDatas={filtroDatas} filtroExtrato={filtroExtrato} handleResetMonth={handleResetMonth} handleSetMonth={handleSetMonth} onSubmit={handleFiltroDatasSubmit} />
      {content}
    </div>
  );
}

ExtratoCartao.propTypes = {
  loading: React.PropTypes.bool,
  extrato: React.PropTypes.object,
  idCardSelected: React.PropTypes.number,
  filtroExtrato: React.PropTypes.object,
  filtroDatas: React.PropTypes.bool,
  datesFiltered: React.PropTypes.bool,
  handleSetMonth: React.PropTypes.func,
  handleResetMonth: React.PropTypes.func,
  handleFiltroDatasSubmit: React.PropTypes.func,
};

export default ExtratoCartao;
