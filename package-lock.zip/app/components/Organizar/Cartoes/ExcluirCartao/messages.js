import { defineMessages } from 'react-intl';

export default defineMessages({
  header: {
    id: 'app.components.Organizar.Cartoes.ExcluirCartao.header',
    defaultMessage: 'MOTIVO',
  },
  hintPerda: {
    id: 'app.components.Organizar.Cartoes.ExcluirCartao.hintPerda',
    defaultMessage: 'PERDA',
  },
  hintRoubo: {
    id: 'app.components.Organizar.Cartoes.ExcluirCartao.hintRoubo',
    defaultMessage: 'FURTO/ROUBO',
  },
  hintNaoQuero: {
    id: 'app.components.Organizar.Cartoes.ExcluirCartao.hintNaoQuero',
    defaultMessage: 'NÃO QUERO MAIS',
  },
  hintJaTenho: {
    id: 'app.components.Organizar.Cartoes.ExcluirCartao.hintJaTenho',
    defaultMessage: 'JÁ TENHO OUTRO CARTÃO VIRTUAL',
  },
});
