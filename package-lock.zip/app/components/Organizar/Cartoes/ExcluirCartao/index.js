import React from 'react';

import { FormattedMessage, injectIntl, intlShape } from 'react-intl';
import messages from './messages';
import List from 'components/List';
import ListItem from 'components/ListItem';
// import styles from './styles.css';

const ExcluirCartao = props => {
  const { handleSetMotivoRoubo, idCardSelected, tipoIndividualizacaoId } = props;
  const { formatMessage } = props.intl;

  const content = (
    <form>
      <h4 className="list-title">{formatMessage(messages.header)} </h4>
      <List showProceedIcon showHoverEffect>
        <ListItem key={1} invisibled={tipoIndividualizacaoId === 3} onClick={() => handleSetMotivoRoubo(1, idCardSelected)}>
          <FormattedMessage {...messages.hintPerda} />
        </ListItem>
        <ListItem key={2} invisibled={tipoIndividualizacaoId === 3} onClick={() => handleSetMotivoRoubo(2, idCardSelected)}>
          <FormattedMessage {...messages.hintRoubo} />
        </ListItem>
        <ListItem key={4} invisibled={tipoIndividualizacaoId !== 3} onClick={() => handleSetMotivoRoubo(4, idCardSelected)}>
          <FormattedMessage {...messages.hintNaoQuero} />
        </ListItem>
        <ListItem key={5} invisibled={tipoIndividualizacaoId !== 3} onClick={() => handleSetMotivoRoubo(5, idCardSelected)}>
          <FormattedMessage {...messages.hintJaTenho} />
        </ListItem>
      </List>
    </form>
  );

  return (
    <div>
      {content}
    </div>
  );
};

ExcluirCartao.propTypes = {
  handleSetMotivoRoubo: React.PropTypes.func,
  idCardSelected: React.PropTypes.number,
  intl: intlShape.isRequired,
  tipoIndividualizacaoId: React.PropTypes.number,
};

export default injectIntl(ExcluirCartao);
