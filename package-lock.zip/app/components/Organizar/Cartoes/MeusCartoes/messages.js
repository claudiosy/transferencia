import { defineMessages } from 'react-intl';

export default defineMessages({
  addCartao: {
    id: 'app.components.Organizar.Cartoes.MeusCartoes.addCartao',
    defaultMessage: 'PEDIR NOVO CARTÃO',
  },
  loadingCards: {
    id: 'app.components.Organizar.Cartoes.MeusCartoes.loadingCards',
    defaultMessage: 'Carregando os seus cartões...',
  },
  notCards: {
    id: 'app.components.Organizar.Cartoes.MeusCartoes.notCards',
    defaultMessage: 'Você não possui nenhum cartão.',
  },
  tipoCartao: {
    id: 'app.components.Organizar.Cartoes.MeusCartoes.tipoCartao',
    defaultMessage: 'TODOS',
  },
  principal: {
    id: 'app.components.Organizar.Cartoes.MeusCartoes.principal',
    defaultMessage: 'CARTÃO PRINCIPAL',
  },
  adicional: {
    id: 'app.components.Organizar.Cartoes.MeusCartoes.adicional',
    defaultMessage: 'CARTÃO ADICIONAL',
  },
  virtual: {
    id: 'app.components.Organizar.Cartoes.MeusCartoes.virtual',
    defaultMessage: 'CARTÃO VIRTUAL',
  },
  associarCartao: {
    id: 'app.components.Organizar.Cartoes.MeusCartoes.associarCartao',
    defaultMessage: 'ASSOCIAR CARTÃO SUPERDIGITAL',
  },
});
