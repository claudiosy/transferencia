import React from 'react';
import { CardStack } from 'react-cardstack';
import List from 'components/List';
import ListItem from 'components/ListItem';
import { reduxForm, Field } from 'redux-form/immutable';
import styles from './styles.css';
import messages from './messages';
import { FormattedMessage, injectIntl, intlShape } from 'react-intl';
import CircularProgress from 'material-ui/CircularProgress';
import Card from 'components/Organizar/Cartoes/Card';
import ContentCard from 'components/Organizar/Cartoes/ContentCard';
import FlatButton from 'material-ui/FlatButton';
import { SelectField } from 'redux-form-material-ui';
import MenuItem from 'material-ui/MenuItem';
import { Row, Col } from 'react-flexbox-grid/lib/index';
import isMobile from 'utils/isMobile';

export class MeusCartoes extends React.Component {
  componentDidMount() {
    this.props.handleSelecaoFiltro(this.props.filtro);
  }
  componentDidUpdate() {
    const filter = this.props.filtro > -1 ? this.props.filtro : this.props.tipoCard;
    this.props.handleSelecaoFiltro(filter);
  }
  render() {
    const { handleToggle, handleStepChange, handleRedirect, handleSelecaoFiltro, columnSelection, columnOrder, cartoes, isHover, loading, tipoCard } = this.props;
    const { formatMessage } = this.props.intl;
    let counter = 1;
    let background;
    let contendCards = '';
    let cardSpace = -80;
    const cartoesList = cartoes && cartoes.toJS().length && cartoes.toJS().filter((card) => { // eslint-disable-line arrow-body-style
      return tipoCard === -1 ? card : card.TipoIndividualizacaoId === tipoCard;
    }).map((cartao) => {
      counter++;
      cardSpace += 80;
      if (cartao.StatusCartao === '20') {
        background = 'rgba(183,183,183,1)';
      } else if (cartao.TipoIndividualizacaoId === 3) {
        background = '#5400a3';
      } else {
        background = 'linear-gradient(45deg,  rgba(0,171,187,1) 0%,rgba(84,0,163,1) 100%)';
      }
      return (
        <Card
          key={counter}
          background={background}
          handleStepChange={handleStepChange}
          columnOrder={columnOrder}
          cartaoId={cartao.CartaoId}
          apelidoCard={cartao.Apelido}
          isHover={isHover}
          cardType={cartao.TipoIndividualizacaoId}
          cardIsBlocked={cartao.StatusCartao === '20'}
          cardSpace={cardSpace}
        >
          <ContentCard dadosCartao={cartao} handleToggle={handleToggle} />
        </Card>
      );
    });

    const dropdownFilter = (
      <ListItem key={0} showProceedIcon={false}>
        <Field name="TipoCartao" component={SelectField} className="redInput" hintText={formatMessage(messages.tipoCartao)} onChange={(event, key) => handleSelecaoFiltro(key)} tabIndex="1" >
          <MenuItem value={-1} primaryText={formatMessage(messages.tipoCartao)} />
          <MenuItem value={0} primaryText={formatMessage(messages.principal)} />
          <MenuItem value={1} primaryText={formatMessage(messages.adicional)} />
          <MenuItem value={3} primaryText={formatMessage(messages.virtual)} />
        </Field>
      </ListItem>
    );

    counter++;
    // const altura = 127;
    const espacamento = 122;
    if (loading) {
      contendCards = (
        <List showProceedIcon showHoverEffect behind={columnSelection !== 0} activeItem={columnSelection}>
          <ListItem key={-3} showProceedIcon={false}>
            <span className={styles.loaderWrapper}>
              <CircularProgress size={0.3} />
            </span>
            <FormattedMessage {...messages.loadingCards} />
          </ListItem>
        </List>
      );
    } else if (cartoesList && cartoesList.length > 1) {
      contendCards = (
        <div>
          <List>
            {dropdownFilter}
          </List>
          <div name="divCartoes" className={`${styles.cardsWrapper} ${columnSelection === -1 ? styles.testeBehind : ''}`} style={{ height: `${(cartoesList.length * 80) + 140}px` }}>
            <CardStack
              height={202}
              width={400}
              hoverOffset={espacamento}
            >
              {cartoesList}
            </CardStack>
          </div>
        </div>
      );
    } else if (cartoesList && cartoesList.length === 1) {
      contendCards = (
        <div>
          <List>
            {dropdownFilter}
          </List>
          <div className={`${styles.cardsWrapper} ${columnSelection === -1 ? styles.testeBehind : ''}`} style={{ height: `${(cartoesList.length * 80) + 140}px` }}>
            <ul className={styles.cardsUnique}>
              {cartoesList}
            </ul>
          </div>
        </div>
      );
    } else if (!cartoesList || !cartoesList.length) {
      contendCards = (
        <List>
          {dropdownFilter}
          <ListItem key={1} showProceedIcon={false}>
            <FormattedMessage {...messages.notCards} />
          </ListItem>
        </List>
      );
    }

    return (
      // eslint-disable-next-line react/jsx-boolean-value
      <div>
        <div className={styles.pageBg}>
          {contendCards}
        </div>
        <Row center="xs">
          <Col sm={6} xs={12} className="fieldWrapper">
            <FlatButton name="btnAddCartao" className={`${'redButton big'} ${!isMobile() ? 'centered' : 'minCentered'}`} label={formatMessage(messages.addCartao)} tabIndex={4} onClick={() => handleRedirect('/organizar/cartoes/pedir')} />
          </Col>
          <Col sm={6} xs={12} className="fieldWrapper">
            <FlatButton name="btnAssociarCartao" className={`${'redButton big'} ${!isMobile() ? 'centered' : 'minCentered'}`} label={formatMessage(messages.associarCartao)} tabIndex={5} onClick={() => handleStepChange(columnOrder, -2, -1, null)} />
          </Col>
        </Row>
      </div>
    );
  }
}

MeusCartoes.propTypes = {
  loading: React.PropTypes.bool,
  cartoes: React.PropTypes.object,
  columnSelection: React.PropTypes.number,
  columnOrder: React.PropTypes.number,
  handleStepChange: React.PropTypes.func,
  handleRedirect: React.PropTypes.func,
  handleSelecaoFiltro: React.PropTypes.func,
  handleToggle: React.PropTypes.func,
  isHover: React.PropTypes.bool,
  intl: intlShape.isRequired,
  tipoCard: React.PropTypes.number,
  filtro: React.PropTypes.number,
  messageInline: React.PropTypes.string,
};

export default injectIntl(reduxForm({
  form: 'meusCartoesForm',
  enableReinitialize: true,
})(MeusCartoes));
