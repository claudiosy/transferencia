import { defineMessages } from 'react-intl';

export default defineMessages({
  hintValor: {
    id: 'app.components.Organizar.Cartoes.ValorForm.hintValor',
    defaultMessage: 'Informe o valor',
  },
  labelMoeda: {
    id: 'app.components.Organizar.Cartoes.ValorForm.labelMoeda',
    defaultMessage: 'Moeda',
  },
  buttonContinuar: {
    id: 'app.components.Organizar.Cartoes.ValorForm.buttonContinuar',
    defaultMessage: 'Continuar',
  },
});
