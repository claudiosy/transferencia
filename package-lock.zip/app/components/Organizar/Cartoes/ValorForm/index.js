import React from 'react';
import { reduxForm, Field } from 'redux-form/immutable';

import { TextField, SelectField } from 'redux-form-material-ui';
import FlatButton from 'material-ui/FlatButton';
import MenuItem from 'material-ui/MenuItem';
import validateValorForm from './validation';
import { injectIntl, intlShape } from 'react-intl';
import messages from './messages';

import List from 'components/List';
import ListItem from 'components/ListItem';
import { normalizeDecimal } from 'normalizers';

import styles from './styles.css';
import valueIcon from 'containers/App/value-icon.png';

class ValorForm extends React.Component { // eslint-disable-line react/prefer-stateless-function
  render() {
    const { handleSubmit, showCurrencySelector, currencies } = this.props;
    const { formatMessage } = this.props.intl;

    let moedasList;
    if (currencies && currencies.length) {
      moedasList = currencies.map((moeda) => { // eslint-disable-line arrow-body-style
        return (
          <MenuItem value={moeda.ID} primaryText={`${moeda.Sigla} - ${moeda.Descricao}`} />
        );
      });
    }

    return (
      <form onSubmit={handleSubmit} className={styles.formValor}>
        <List>
          <ListItem icon={valueIcon} key={3}>
            {showCurrencySelector && <Field
              name="MoedaId"
              component={SelectField}
              className={`redInput ${styles.moeda}`}
              hintText={formatMessage(messages.labelMoeda)}
              tabIndex="1"
              autoWidth
            >
              {moedasList}
            </Field>}
            <Field
              name="Valor"
              component={TextField}
              hintText={formatMessage(messages.hintValor)}
              normalize={normalizeDecimal}
              type="tel"
              tabIndex="2"
              format={normalizeDecimal}
            />
          </ListItem>
        </List>
        <FlatButton name="btnContinuar" type="submit" className="redButton big centered" label={formatMessage(messages.buttonContinuar)} tabIndex="2" />
      </form>
    );
  }
}

ValorForm.propTypes = {
  handleSubmit: React.PropTypes.func,
  Valor: React.PropTypes.number,
  showCurrencySelector: React.PropTypes.bool,
  currencies: React.PropTypes.array,
  intl: intlShape.isRequired,
};

export default injectIntl(reduxForm({
  form: 'valorForm',
  validate: validateValorForm,
  enableReinitialize: true,
})(ValorForm));
