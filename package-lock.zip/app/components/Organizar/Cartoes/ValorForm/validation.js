import messages from 'containers/App/messages';

const validateValorForm = (valuesFromState, props) => {
  const { formatMessage } = props.intl;
  const { showCurrencySelector } = props;
  const errors = {};
  const values = valuesFromState.toJS();
  if (!values.Valor) {
    errors.Valor = formatMessage(messages.mandatoryField);
  }
  if (showCurrencySelector && !values.MoedaId) {
    errors.MoedaId = formatMessage(messages.mandatoryField);
  }

  return errors;
};

export default validateValorForm;
