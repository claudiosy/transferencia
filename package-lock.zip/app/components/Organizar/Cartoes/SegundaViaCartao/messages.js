import { defineMessages } from 'react-intl';

export default defineMessages({
  header: {
    id: 'app.components.Organizar.Cartoes.SegundaViaCartao.header',
    defaultMessage: 'SEGUNDA VIA CARTÃO',
  },
  header2: {
    id: 'app.components.Organizar.Cartoes.SegundaViaCartao.header2',
    defaultMessage: 'MOTIVO',
  },
  hintPerda: {
    id: 'app.components.Organizar.Cartoes.SegundaViaCartao.hintPerda',
    defaultMessage: 'PERDA',
  },
  hintRoubo: {
    id: 'app.components.Organizar.Cartoes.SegundaViaCartao.hintRoubo',
    defaultMessage: 'FURTO/ROUBO',
  },
  hintExtravio: {
    id: 'app.components.Organizar.Cartoes.SegundaViaCartao.hintExtravio',
    defaultMessage: 'EXTRAVIO',
  },
});
