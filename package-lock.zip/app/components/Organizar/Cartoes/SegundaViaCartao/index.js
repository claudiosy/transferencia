import React from 'react';

import { FormattedMessage, injectIntl, intlShape } from 'react-intl';
import messages from './messages';
import List from 'components/List';
import ListItem from 'components/ListItem';
import styles from './styles.css';
import CartoesIcon from './cartoes-icon.png';

const SegundaViaCartao = props => {
  const { handleSetMotivo, idCardSelected } = props;
  const { formatMessage } = props.intl;

  const content = (
    <form>
      <h4 className="list-title"><img src={CartoesIcon} alt="" className={styles.leftIcon} /> {formatMessage(messages.header)} </h4>
      <h4 className="list-title">{formatMessage(messages.header2)} </h4>
      <List showProceedIcon showHoverEffect>
        <ListItem key={1} onClick={() => handleSetMotivo(1, idCardSelected)}>
          <FormattedMessage {...messages.hintPerda} />
        </ListItem>
        <ListItem key={2} onClick={() => handleSetMotivo(2, idCardSelected)}>
          <FormattedMessage {...messages.hintRoubo} />
        </ListItem>
        <ListItem key={3} onClick={() => handleSetMotivo(3, idCardSelected)}>
          <FormattedMessage {...messages.hintExtravio} />
        </ListItem>
      </List>
    </form>
  );

  return (
    <div>
      {content}
    </div>
  );
};

SegundaViaCartao.propTypes = {
  handleSetMotivo: React.PropTypes.func,
  idCardSelected: React.PropTypes.number,
  intl: intlShape.isRequired,
};

export default injectIntl(SegundaViaCartao);
