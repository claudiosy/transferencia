/**
*
* ConfirmMosaicValue
*
*/

import React from 'react';
import { injectIntl, intlShape } from 'react-intl';

import transComplete from './complete-icon.png';


class ConfirmMosaicValue extends React.Component { // eslint-disable-line react/prefer-stateless-function
  constructor(props) {
    super(props);

    this.initialize(props);
  }
  componentDidMount() {
    if (this.props.animateFrom !== undefined) {
      this.start();
    }
  }
  componentWillReceiveProps(nextProps) {
    const { animateFrom, value } = this.props;

    if (nextProps.value !== value || nextProps.animateFrom !== animateFrom) {
      this.initialize(nextProps);
      this.start();
    }
  }
  componentWillUnmount() {
    this.clear();
  }
  start() {
    this.clear();

    const { delay, tick, effectDuration, value, animateFrom } = this.state;
    this.loopsCounter = 0;
    this.operation = value > animateFrom ? 'plus' : 'minus';
    this.loops = effectDuration / delay;
    this.increment = tick * delay;

    this.interval = setInterval(() => this.next(), delay);
  }
  initialize(props) {
    const { value, animateFrom, effectDuration } = props;
    const delay = 100;
    let newState = {};

    if (animateFrom !== undefined) {
      newState = {
        counter: animateFrom,
        delay,
        effectDuration,
        value,
        animateFrom,
        tick: (animateFrom > value ? animateFrom : value) / effectDuration,
        done: false,
      };
    } else {
      newState = {
        counter: 0,
      };
    }

    this.state = newState;
  }
  next() {
    if (this.loopsCounter < this.loops) {
      this.loopsCounter++;
      this.setState(({ counter }) => ({
        counter: this.operation === 'plus' ? counter + this.increment : counter - this.increment,
      }));
    } else {
      this.clear();
      this.setState({ done: true });
    }
  }
  clear() {
    clearInterval(this.interval);
  }

  render() {
    const { formatNumber } = this.props.intl;
    const { value, animateFrom, currency, displayWhenDone, ...others } = this.props;
    const { counter, done } = this.state;
    let content = '';
    if (done && displayWhenDone) {
      content = (
        <div {...others}>
          <img src={transComplete} role="presentation" />
        </div>
      );
    } else if (animateFrom === undefined && value) {
      content = (
        <div {...others}>
          {!isNaN(value) && currency ? <span>{currency}</span> : ''}
          {isNaN(value) ? value : formatNumber(value, { style: 'decimal', minimumFractionDigits: 2, maximumFractionDigits: 2 })}
        </div>
      );
    } else if (animateFrom !== undefined) {
      content = (
        <div {...others}>
          {currency ? <span>{currency}</span> : ''}
          {formatNumber(counter < 0 ? 0 : counter, { style: 'decimal', minimumFractionDigits: 2, maximumFractionDigits: 2 })}
        </div>
      );
    }

    return (content);
  }
}

ConfirmMosaicValue.propTypes = {
  value: React.PropTypes.oneOfType([
    React.PropTypes.string,
    React.PropTypes.number,
  ]),
  animateFrom: React.PropTypes.number,
  effectDuration: React.PropTypes.number,
  currency: React.PropTypes.string,
  displayWhenDone: React.PropTypes.bool,
  intl: intlShape.isRequired,
};

export default injectIntl(ConfirmMosaicValue);
