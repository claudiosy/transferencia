/* import React from 'react';

import styles from './styles.css';

class ContactItem extends React.Component { // eslint-disable-line react/prefer-stateless-function
  render() {
    const { onClick, indice } = this.props;

    return (
      <li className={`${styles.contactItem} `}>
        {indice !== '' ? <h6>{indice}</h6> : ''}
        <a href="javascript:;" onClick={onClick}>
          {React.Children.toArray(this.props.children)}
        </a>
      </li>
    );
  }
}

ContactItem.propTypes = {
  children: React.PropTypes.node,
  onClick: React.PropTypes.func,
  indice: React.PropTypes.string,
};

export default ContactItem;
*/
