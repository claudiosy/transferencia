import React from 'react';
import { Row, Col } from 'react-flexbox-grid/lib/index';
import CircularProgress from 'material-ui/CircularProgress';

import styles from './styles.css';

import avatarIcon from './avatar.png';
import favoriteIcon from 'containers/App/favorite-icon.png';
import superIcon from 'containers/App/super-icon.png';
import selectOnIcon from 'containers/App/ellipseOn.png';
import selectOffIcon from 'containers/App/ellipseOff.png';

function renderChildren(names, props) {
  let indice;
  let ultimaLetra = '';

  return names.map((contatos, key) => {
    const miniFoto = contatos.urlFoto !== '' ? (<img src={contatos.urlFoto} className={styles.leftIcon} alt="" />) : (<img src={avatarIcon} className={styles.leftIcon} alt="" />);
    const iconFavorite = contatos.favorito === 1 && props.showFavorite ? (<img src={favoriteIcon} className={styles.iconFavorite} alt="" />) : '';
    const iconSuper = contatos.super === 1 && props.showSuper ? (<img src={superIcon} className={styles.iconFavorite} alt="" />) : '';
    let iconSelect = '';
    if (props.showSelect) {
      iconSelect = contatos.select === 1 ? (<img src={selectOnIcon} className={styles.iconFavorite} alt="" />) : (<img src={selectOffIcon} className={styles.iconFavorite} alt="" />);
    }

    if (ultimaLetra !== contatos.nome.substring(0, 1).toUpperCase()) {
      indice = contatos.nome.substring(0, 1).toUpperCase();
      ultimaLetra = contatos.nome.substring(0, 1).toUpperCase();
    } else {
      indice = '';
    }

    // if (contatos.nome.toLowerCase().startsWith(props.buscaNome ? props.buscaNome.toLowerCase() : '')) {
    if (contatos.nome.toLowerCase().indexOf(props.buscaNome ? props.buscaNome.toLowerCase() : '') !== -1) {
      return (
        <Col sm={!props.colunas ? 6 : props.colunas} id={contatos.id} onClick={() => props.handleContactClick(key, contatos.id, contatos.nome, contatos.urlFoto, contatos.favorito)} className={styles.listaContatos}>
          <Row>
            <h6>{indice}</h6>
          </Row>
          {miniFoto}
          {contatos.nome}
          {iconSelect}
          {iconSuper}
          {iconFavorite}
        </Col>
      );
    }

    return null;
  });
}

const ListaContatos = props => { // eslint-disable-line react/prefer-stateless-function
  const { loading, message, contatos /* colunas, showFavorite, showSuper, showSelect, buscaNome*/ } = props;

  let content;

  if (message) {
    content = (<h2>{message}</h2>);
  } else if (loading) {
    content = (<div><CircularProgress /></div>);
  } else {
    content = (
      <Row>
        {renderChildren(contatos, props)}
      </Row>
    );
  }
  return (content);
};

ListaContatos.propTypes = {
  loading: React.PropTypes.bool,
  message: React.PropTypes.string,
  handleContactClick: React.PropTypes.func,
  contatos: React.PropTypes.object,
  colunas: React.PropTypes.number,
  showFavorite: React.PropTypes.bool,
  showSuper: React.PropTypes.bool,
  showSelect: React.PropTypes.bool,
  buscaNome: React.PropTypes.string,
};

export default ListaContatos;
