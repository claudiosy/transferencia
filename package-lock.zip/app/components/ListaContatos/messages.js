import { defineMessages } from 'react-intl';

export default defineMessages({
  header: {
    id: 'superdigital.ListaContatos.header',
    defaultMessage: 'Lista de Contatos',
  },
});
