/**
*
* SupportChathead
*
*/

import React from 'react';
import FlatButton from 'material-ui/FlatButton';

import { injectIntl, intlShape } from 'react-intl';
import Resizable from 'react-resizable-box';
import isMobile from 'utils/isMobile';
import auth from 'utils/auth';
import styles from './styles.css';
import sendIcon from 'containers/App/proceed-icon.png';

class ChatbotWindow extends React.Component { // eslint-disable-line react/prefer-stateless-function
  constructor() {
    super();
    this.handleAppendMessage = this.handleAppendMessage.bind(this);
    this.handlePossibleIntentClick = this.handlePossibleIntentClick.bind(this);
  }
  componentDidUpdate(prevProps) {
    if (prevProps.chatMessages.toJS().length !== this.props.chatMessages.toJS().length) {
      const msgArea = document.getElementById('chat-history');
      msgArea.scrollTop = msgArea.scrollHeight;
    }
  }
  handleAppendMessage() {
    if (document.getElementById('chat-msg').value.trim()) {
      this.props.onAppendMessage('user', document.getElementById('chat-msg').value, new Date());
      document.getElementById('chat-msg').value = '';
    }
  }
  handlePossibleIntentClick(evt) {
    this.props.onAppendMessage('user', evt.target.innerHTML, new Date(), evt.target.dataset.intent);
  }
  render() {
    const { visible } = this.props;
    const { chatMessages } = this.props;
    const { chatOpen } = this.props;

    const messagesList = chatMessages && chatMessages.toJS().map((item) => { // eslint-disable-line arrow-body-style
      let msgArray = [];
      if (typeof item.message === 'string') {
        msgArray.push(item.message);
      } else {
        msgArray = item.message;
      }

      const result = [];
      for (let i = 0; i < msgArray.length; i++) {
        result.push(<li className={item.from === 'user' ? styles.sent : styles.received}>{msgArray[i]}</li>);
      }

      if (item.options) {
        const subitems = [];
        for (let j = 0; j < item.options.length; j++) {
          subitems.push(<li><button type="button" data-intent={item.options[j].intent} onClick={this.handlePossibleIntentClick}>{item.options[j].label}</button></li>);
        }
        result.push(<li className={styles.options}><ul>{subitems}</ul></li>);
      }

      return result;
    });

    if (auth.getValidToken()) {
      messagesList.unshift(<li className={styles.received}>{`Olá ${auth.getUserName().split(' ')[0]}!`}</li>);
    }

    let content = (
      <Resizable
        width={280}
        minWidth={280}
        maxWidth={600}
        height={340}
        minHeight={340}
        maxHeight={450}
        enable={{ top: false, right: true, bottom: true, left: true, topRight: false, bottomRight: true, bottomLeft: true, topLeft: false }}
        className={`${styles.chatWindow} ${visible && styles.visible}`}
        extendsProps={{ onClick: (evt) => evt.stopPropagation() }}
      >
        <ul id="chat-history" className={styles.chatHistory}>
          {messagesList}
        </ul>

        <textarea id="chat-msg" name="chat-msg" onKeyUp={(evt) => evt.keyCode === 13 && this.handleAppendMessage()} maxLength={500} ></textarea>
        <FlatButton className={styles.send} onMouseUp={this.handleAppendMessage}>
          <img src={sendIcon} role="presentation" alt="" />
        </FlatButton>
      </Resizable>
    );

    if (isMobile()) {
      content = (
        <div className={`${styles.chatWindow} ${visible && styles.visible}`}>
          <ul id="chat-history" className={`${styles.chatHistory} ${chatOpen && styles.chatOpen}`}>
            {messagesList}
          </ul>

          <textarea id="chat-msg" name="chat-msg" onKeyUp={(evt) => evt.keyCode === 13 && this.handleAppendMessage()} maxLength={500} ></textarea>
          <FlatButton className={styles.send} onMouseUp={this.handleAppendMessage}>
            <img src={sendIcon} role="presentation" alt="" />
          </FlatButton>
        </div>
      );
    }

    return (content);
  }
}

ChatbotWindow.propTypes = {
  visible: React.PropTypes.bool,
  chatMessages: React.PropTypes.object,
  onAppendMessage: React.PropTypes.func,
  intl: intlShape.isRequired,
  chatOpen: React.PropTypes.bool,
};

export default injectIntl(ChatbotWindow);
