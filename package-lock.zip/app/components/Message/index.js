import React from 'react';

import styles from './styles.css';

class Message extends React.Component { // eslint-disable-line react/prefer-stateless-function
  constructor() {
    super();
    this.state = { visible: true };
    this.handleCloseClick = this.handleCloseClick.bind(this);
  }
  componentWillMount() {
    this.setState({ text: this.props.text });
  }
  componentDidMount() {
    this.setupTimer();
  }
  componentWillReceiveProps(nextProps) {
    if (this.props.text !== nextProps.text) {
      this.setState({ visible: true });
    }
  }
  componentDidUpdate() {
    this.setupTimer();
  }
  setupTimer() {
    if (this.state.visible && this.props.text) {
      this.setHideTimer();
    }
  }
  setHideTimer() {
    this.hideTimeout = setTimeout(() => {
      this.setState({ visible: false });
    }, 7000);
  }
  handleCloseClick() {
    this.setState({ visible: false });
    clearTimeout(this.hideTimeout);
  }
  render() {
    const { text } = this.props;
    const { visible } = this.state;

    return (
      <div className={`${styles.messageContainer} ${visible && text && styles.visible}`}>
        <p>{text}</p>
        <button type="button" onClick={this.handleCloseClick} className={styles.messageClose}>&times;</button>
      </div>
    );
  }
}

Message.propTypes = {
  text: React.PropTypes.string,
  visible: React.PropTypes.bool,
};

export default Message;
