/*
 * AddToFavorites Messages
 *
 * This contains all the text for the AddToFavorites component.
 */
import { defineMessages } from 'react-intl';

export default defineMessages({
  title: {
    id: 'superdigital.components.AddToFavorites.title',
    defaultMessage: 'Adicionar aos favoritos',
  },
});
