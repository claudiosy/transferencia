/**
*
* AddToFavorites
*
*/

import React from 'react';

import { FormattedMessage } from 'react-intl';
import messages from './messages';

import FlatButton from 'material-ui/FlatButton';

import styles from './styles.css';
import favoriteStarHollowIcon from 'containers/App/favorite-hollow-icon.png';
import favoriteStarWholeIcon from 'containers/App/favorite-whole-icon.png';

function AddToFavorites(props) {
  const { state, onToggle } = props;

  return (
    <FlatButton name="btnAddToFavorites" className={styles.addToFavorites} onMouseUp={onToggle}>
      <img src={state ? favoriteStarWholeIcon : favoriteStarHollowIcon} role="presentation" />
      <FormattedMessage {...messages.title} />
    </FlatButton>
  );
}

AddToFavorites.propTypes = {
  state: React.PropTypes.bool,
  onToggle: React.PropTypes.func,
};

export default AddToFavorites;
