import React from 'react';


class Holos extends React.Component {
  constructor(props) {
    super(props);
    this.state = { tagHolos: null };
  }

  componentDidMount() {
    const scriptText =
      `dataLayer.push({
      'event':'Etapa Cadastro',
      'etapa': '${this.props.tagHolos}'
    }); `;
    const script = document.createElement('script');
    script.type = 'text/javascript';
    script.text = scriptText;
    script.async = false;
    document.body.appendChild(script);
  }
  render() {
    return (
      <div>
      </div>
    );
  }
}

Holos.propTypes = {
  tagHolos: React.PropTypes.string,
};
export default Holos;
