import React from 'react';

import styles from './styles.css';
import proceedIcon from 'containers/App/proceed-icon.png';
import openarrowIcon from 'containers/App/openarrow-icon.png';
import closearrowIcon from 'containers/App/closearrow-icon.png';

/* eslint-disable */
class ListItem extends React.Component { // eslint-disable-line react/prefer-stateless-function
  render() {
    const { onClick, icon, showProceedIcon, otherProceedIcon, active, notButton, informative, invisibled, autoHeight, name, /* , sticky*/ showOpenarrowIcon, showClosearrowIcon, className } = this.props;
    const iconImg = icon ? (<p className={styles.leftIcon}><img src={icon} alt="" /></p>) : '';
    const iconProceed = !otherProceedIcon ? proceedIcon : otherProceedIcon;
    const proceed = showProceedIcon ? (<img src={iconProceed} className={styles.proceedIcon} alt="" />) : '';
    const openarrow = showOpenarrowIcon ? (<img src={openarrowIcon} className={styles.proceedIcon} alt="" />) : '';
    const closearrow = showClosearrowIcon ? (<img src={closearrowIcon} className={styles.proceedIcon} alt="" />) : '';

    return (
      <li className={`${styles.listItem} ${showProceedIcon ? styles.listItemProceedIcon : ''} ${active ? styles.active : ''} ${invisibled ? styles.invisible : ''} ${informative ? styles.informative : ''} ${autoHeight && styles.autoHeight} ${className}`}>
        <button name={name} type="button" onClick={onClick} className={notButton && styles.noPointer}>
          {iconImg}
          {React.Children.toArray(this.props.children)}
          {proceed}
          {openarrow}
          {closearrow}
        </button>
      </li>
    );
  }
}

ListItem.propTypes = {
  children: React.PropTypes.node,
  active: React.PropTypes.bool,
  autoHeight: React.PropTypes.bool,
  loading: React.PropTypes.bool,
  icon: React.PropTypes.string,
  notButton: React.PropTypes.bool,
  invisibled: React.PropTypes.bool,
  informative: React.PropTypes.bool,
  showProceedIcon: React.PropTypes.bool,
  sticky: React.PropTypes.bool,
  otherProceedIcon: React.PropTypes.string,
  onClick: React.PropTypes.func,
  showOpenarrowIcon: React.PropTypes.bool,
  showClosearrowIcon: React.PropTypes.bool,
};

export default ListItem;
