import messages from 'containers/App/messages';

const validateEmailForm = (valuesFromState, props) => {
  const { formatMessage } = props.intl;
  const errors = {};
  const values = valuesFromState.toJS();

  if (!values.Para) {
    errors.Para = formatMessage(messages.mandatoryField);
  }
  if (values.Para && !/^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,4}$/i.test(values.Para)) {
    errors.Para = formatMessage(messages.invalidEmail);
  }
  if (!values.Assunto) {
    errors.Assunto = formatMessage(messages.mandatoryField);
  }
  if (!values.msg) {
    errors.msg = formatMessage(messages.mandatoryField);
  }
  return errors;
};

export default validateEmailForm;
