import { defineMessages } from 'react-intl';

export default defineMessages({
  hintPara: {
    id: 'app.components.ConvidarAmigos.EmailForm.hintApelido',
    defaultMessage: 'Para',
  },
  hintAssunto: {
    id: 'app.components.ConvidarAmigos.EmailForm.hintAssunto',
    defaultMessage: 'Assunto',
  },
  hintMensagem: {
    id: 'app.components.ConvidarAmigos.EmailForm.hintMensagem',
    defaultMessage: 'Mensagem',
  },
  buttonEnviar: {
    id: 'app.components.ConvidarAmigos.EmailForm.buttonEnviar',
    defaultMessage: 'Enviar',
  },
  loadingForm: {
    id: 'app.components.ConvidarAmigos.EmailForm.loadingForm',
    defaultMessage: 'Carregando...',
  },
});
