import React from 'react';

import { reduxForm, Field, change, formValueSelector } from 'redux-form/immutable';
import { connect } from 'react-redux';

import { TextField } from 'redux-form-material-ui';
import FlatButton from 'material-ui/FlatButton';
import validateEmailForm from './validation';
import { injectIntl, intlShape, FormattedMessage } from 'react-intl';
import messages from './messages';

import List from 'components/List';
import ListItem from 'components/ListItem';
import CircularProgress from 'material-ui/CircularProgress';
import iconInfo from 'containers/App/icon-info.png';

import styles from './styles.css';

class EmailForm extends React.Component {
  componentWillMount() {
    this.props.handleInitAssunto();
  }
  render() {
    const { handleSubmit, loading, message, pristine, submitting, mensagem } = this.props;
    const { formatMessage } = this.props.intl;

    if (loading) {
      return (
        <List>
          <ListItem key={-3} showProceedIcon={false}>
            <span className={styles.loaderWrapper}>
              <CircularProgress size={0.3} />
            </span>
            <FormattedMessage {...messages.loadingForm} />
          </ListItem>
        </List>
      );
    } else if (message[0]) {
      return (
        <List>
          <ListItem key={-2} icon={iconInfo} notButton showProceedIcon={false}>
            <spam>{message}</spam>
          </ListItem>
        </List>
      );
    }

    return (
      <form onSubmit={handleSubmit}>
        <List>
          <ListItem key={1}>
            <Field autoFocus name="Para" component={TextField} className="redInput wFloatingLabel" floatingLabelText={formatMessage(messages.hintPara)} tabIndex="1" />
          </ListItem>
          <ListItem key={2}>
            <Field name="Assunto" component={TextField} className="redInput wFloatingLabel" floatingLabelText={formatMessage(messages.hintAssunto)} tabIndex="2" />
          </ListItem>
          <ListItem key={3} autoHeight>
            <textarea id="msg" name="msg" className={styles.mensagem} floatingLabelText={formatMessage(messages.hintMensagem)} tabIndex="3" value={mensagem}></textarea>
          </ListItem>
        </List>
        <FlatButton name="btnEnviar" type="submit" className="redButton big centered" label={formatMessage(messages.buttonEnviar)} disabled={pristine || submitting} tabIndex={4} />
      </form>
    );
  }
}

EmailForm.propTypes = {
  pristine: React.PropTypes.bool,
  submitting: React.PropTypes.bool,
  loading: React.PropTypes.bool,
  message: React.PropTypes.array,
  handleSubmit: React.PropTypes.func,
  columnOrder: React.PropTypes.number,
  intl: intlShape.isRequired,
  handleInitAssunto: React.PropTypes.func,
  mensagem: React.PropTypes.string,
};

function mapDispatchToProps(dispatch) {
  return {
    handleInitAssunto: () => {
      dispatch(change('emailForm', 'Assunto', 'Super Digital'));
    },
    dispatch,
  };
}

const selector = formValueSelector('emailForm');

export default connect(
  state => {
    const Assunto = selector(state, 'Assunto');
    return {
      Assunto,
    };
  }, mapDispatchToProps)(injectIntl(reduxForm({
    form: 'emailForm',
    validate: validateEmailForm,
  })(EmailForm)));
