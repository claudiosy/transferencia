import React from 'react';
import { reduxForm } from 'redux-form/immutable';
import List from 'components/List';
import ListItem from 'components/ListItem';
import CircularProgress from 'material-ui/CircularProgress';
import { FormattedMessage } from 'react-intl';
import messages from './messages';

import iconInfo from 'containers/App/icon-info.png';

const Menu = props => { // eslint-disable-line react/prefer-stateless-function
  const { handleStepChange, loading, message, columnSelection, columnOrder } = props;

  let content;

  if (message) {
    content = (<h2>{message}</h2>);
  } else if (loading) {
    content = (<div><CircularProgress /></div>);
  } else {
    content = (
      <List showProceedIcon showHoverEffect behind={columnSelection !== 0} activeItem={columnSelection}>
        <ListItem key={-1} informative icon={iconInfo} showProceedIcon={false} notButton autoHeight>
          <FormattedMessage {...messages.informative} />
        </ListItem>
        <ListItem name="convidarEmail" key={1} onClick={() => handleStepChange(columnOrder, 1, 4)}>
          <FormattedMessage {...messages.email} />
        </ListItem>
      </List>
    );
  }

  return (
    <div>
      {content}
    </div>);
};

Menu.propTypes = {
  handleStepChange: React.PropTypes.func,
  pristine: React.PropTypes.bool,
  loading: React.PropTypes.bool,
  message: React.PropTypes.string,
  submitting: React.PropTypes.bool,
  columnSelection: React.PropTypes.number,
  columnOrder: React.PropTypes.number,
};

export default reduxForm({
  form: 'menu',
})(Menu);
