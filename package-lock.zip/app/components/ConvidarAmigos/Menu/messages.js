import { defineMessages } from 'react-intl';

export default defineMessages({
  email: {
    id: 'app.components.ConvidarAmigos.Menu.email',
    defaultMessage: 'E-MAIL',
  },
  informative: {
    id: 'app.components.ConvidarAmigos.Menu.informative',
    defaultMessage: 'Convide seus amigos para experimentar a Superdigital.',
  },
});
