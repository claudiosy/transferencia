import React, { PropTypes } from 'react';

import { Field } from 'redux-form/immutable';
import CircularProgress from 'material-ui/CircularProgress';

import proceedIcon from 'containers/App/proceed-icon.png';

const IconTextField = props => {
  const { fieldStatus, wrapperClassName, icon, ...other } = props;
  let complement;

  if (fieldStatus === -1) { // loading
    complement = (<span className="fieldLoader"><CircularProgress size={0.3} /></span>);
  } else if (fieldStatus >= 1) { // proceed
    complement = (<img src={proceedIcon} className="field-icon" alt="" />);
  } else { // idle
    complement = (<img src={icon} className="field-icon" alt="" />);
  }

  return (
    <div className={wrapperClassName}>
      <Field
        {...other}
      />
      {complement}
    </div>
  );
};

IconTextField.propTypes = {
  icon: PropTypes.string,
  fieldStatus: PropTypes.number,
  wrapperClassName: PropTypes.string,
};

export default IconTextField;
