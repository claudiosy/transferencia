import React from 'react';

import styles from './styles.css';

class Growl extends React.Component { // eslint-disable-line react/prefer-stateless-function
  constructor() {
    super();
    this.state = { visible: true, text: null };
  }
  componentWillMount() {
    this.setState({ text: this.props.text });
  }
  componentDidMount() {
    this.setupTimer();
  }
  componentWillReceiveProps(nextProps) {
    if (this.props.text !== nextProps.text) {
      this.setState({ visible: true });
      clearTimeout(this.hideTimeout);
    }
  }
  componentDidUpdate() {
    this.setupTimer();
  }
  setupTimer() {
    if (this.state.visible && this.props.text) {
      this.setHideTimer();
    }
  }
  setHideTimer() {
    this.hideTimeout = setTimeout(() => {
      this.setState({ visible: false });
      this.props.onHide();
    }, 5000);
  }
  render() {
    const { text } = this.props;
    const { visible } = this.state;

    return (
      <div className={`${styles.growlContainer} ${visible && text && styles.visible}`}>
        <p>{text}</p>
      </div>
    );
  }
}

Growl.propTypes = {
  text: React.PropTypes.string,
  visible: React.PropTypes.bool,
  onHide: React.PropTypes.func,
};

export default Growl;
