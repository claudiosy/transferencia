import React from 'react';
import { connect } from 'react-redux';
import { reduxForm } from 'redux-form/immutable';
import FlatButton from 'material-ui/FlatButton';
import update from 'react-addons-update';
import styles from './styles.css';
import { createStructuredSelector } from 'reselect';
import { injectIntl } from 'react-intl';
import addIcon from './adicionar-icon.png';

import { loadHistorico, setTags } from 'containers/Organizar/HistoricoPage/actions';

const Chips = React.createClass({ // eslint-disable-line
  propTypes: {
    chips: React.PropTypes.array,
    max: React.PropTypes.oneOfType([
      React.PropTypes.number,
      React.PropTypes.string,
    ]),
    maxlength: React.PropTypes.oneOfType([
      React.PropTypes.number,
      React.PropTypes.string,
    ]),
    placeholder: React.PropTypes.string,
    handleTags: React.PropTypes.func,
  },

  getDefaultProps() {
    return {
      placeholder: 'Busca...',
      maxlength: 20,
    };
  },

  getInitialState() {
    return {
      chips: [],
      KEY: {
        backspace: 8,
        tab: 9,
        enter: 13,
      },
      // only allow letters, numbers and spaces inbetween words
      INVALID_CHARS: /[^a-zA-Z0-9 ]/g,
    };
  },

  componentDidMount() {
    this.setChips(this.props.chips);
  },

  componentWillReceiveProps(nextProps) {
    this.setChips(nextProps.chips);
  },

  onKeyDown(event) {
    const keyPressed = event.which;

    if (keyPressed === this.state.KEY.enter || (keyPressed === this.state.KEY.tab && event.target.value)) {
      event.preventDefault();
      this.updateChips(event);
    } else if (keyPressed === this.state.KEY.backspace) {
      const chips = this.state.chips;
      if (!event.target.value && chips.length) {
        this.deleteChip(chips[chips.length - 1]);
      }
    }
  },

  setChips(chips) {
    if (chips && chips.length) this.setState({ chips });
  },

  handleTagPlusClick() {
    const eventObj = document.createEventObject ? document.createEventObject() : document.createEvent('Events');

    if (eventObj.initEvent) {
      eventObj.initEvent('keydown', true, true);
    }

    eventObj.keyCode = 13;
    eventObj.which = 13;

    const el = document.getElementsByName('PalavrasBusca')[0];
    const valor = el.value.trim();

    if (valor !== '') {
      el.dispatchEvent ? el.dispatchEvent(eventObj) : el.fireEvent('onkeydown', eventObj); // eslint-disable-line no-unused-expressions

      const addChips = this.state.chips;
      addChips.push(valor);
      this.props.handleTags(addChips);
    }
  },

  clearInvalidChars(event) {
    const value = event.target.value;
    const keyPressed = event.which;

    if (this.state.INVALID_CHARS.test(value)) {
      event.target.value = value.replace(this.state.INVALID_CHARS, ''); // eslint-disable-line
    } else if (value.length > this.props.maxlength) {
      event.target.value = value.substr(0, this.props.maxlength); // eslint-disable-line
    }

    if (keyPressed === this.state.KEY.enter || (keyPressed === this.state.KEY.tab && event.target.value)) {
      this.props.handleTags(this.state.chips);
    }
  },

  updateChips(event) {
    if (!this.props.max || this.state.chips.length < this.props.max) {
      const value = event.target.value;

      if (!value) return;

      const chip = value.trim();

      if (chip && this.state.chips.indexOf(chip) < 0) {
        this.setState({
          chips: update(
            this.state.chips,
            {
              $push: [chip],
            }
          ),
        });
      }
    }

    event.target.value = ''; // eslint-disable-line
  },

  deleteChip(chip) {
    const index = this.state.chips.indexOf(chip);

    if (index >= 0) {
      this.setState({
        chips: update(
          this.state.chips,
          {
            $splice: [[index, 1]],
          }
        ),
      });

      const delChips = this.state.chips;
      delChips.splice(index, 1);
      this.props.handleTags(delChips);
    }
  },

  focusInput(event) {
    const children = event.target.children;

    if (children.length) children[children.length - 1].focus();
  },

  render() {
    const chips = this.state.chips.map((chip, index) => { // eslint-disable-line
      return (
        <div>
          <span className={styles.chip} key={index}>
            <span className={styles.chip_value}>{chip}</span>
            <button type="button" className={styles.chip_delete_button} onClick={() => this.deleteChip(chip)}><span className={styles.chip_btn_x}>x</span></button>
          </span>
        </div>
      );
    });

    const placeholder = !this.props.max || chips.length < this.props.max ? this.props.placeholder : '';

    return (
      <div className={styles.chips} onClick={this.focusInput}>
        {chips}
        <input name="PalavrasBusca" type="text" className={styles.chips_input} placeholder={placeholder} onKeyDown={this.onKeyDown} onKeyUp={this.clearInvalidChars} />
        <FlatButton name="btnAdd" className={styles.btnAdd} type="button" onMouseUp={() => this.handleTagPlusClick()}>
          <img src={addIcon} alt="" />
        </FlatButton>
      </div>
    );
  },
});

/* ReactDOM.render(
  <Chips chips={['react', 'javascript', 'scss']} placeholder="Add a tag..." max="10" />,
  document.body
); */

const mapStateToProps = createStructuredSelector({

});

function mapDispatchToProps(dispatch) {
  return {
    handleTags: (tags) => {
      dispatch(setTags(tags));
      dispatch(loadHistorico());
    },
    dispatch,
  };
}

export default connect(mapStateToProps, mapDispatchToProps)(injectIntl(reduxForm({
  form: 'chipsForm',
})(Chips)));
