import { defineMessages } from 'react-intl';

export default defineMessages({
  superDigital: {
    id: 'app.components.Chips.superDigital',
    defaultMessage: 'SUPERDIGITAL',
  },
});
