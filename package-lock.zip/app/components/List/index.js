import React from 'react';

import styles from './styles.css';

function renderChildren(props) {
  return React.Children.map(props.children, child => { // eslint-disable-line arrow-body-style
    if (child) {
      return React.cloneElement(child, {
        showProceedIcon: child.props.showProceedIcon === undefined ? props.showProceedIcon : child.props.showProceedIcon,
        active: child.key == props.activeItem, // eslint-disable-line eqeqeq
      });
    }
    return null;
  });
}

function List(props) {
  const { showHoverEffect, behind } = props;

  return (
    <ul className={`${styles.list} ${(showHoverEffect ? styles.hoverEffect : '')} ${behind ? styles.behind : ''}`}>
      {renderChildren(props)}
    </ul>
  );
}

List.propTypes = {
  children: React.PropTypes.node,
  activeItem: React.PropTypes.number,
  showProceedIcon: React.PropTypes.bool,
  showHoverEffect: React.PropTypes.bool,
  behind: React.PropTypes.bool,
};

export default List;
