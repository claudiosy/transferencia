import { defineMessages } from 'react-intl';

export default defineMessages({
  labelDestino: {
    id: 'app.components.Comprovantes.ComprovanteEnviar.labelDestino',
    defaultMessage: 'DESTINO',
  },
});
