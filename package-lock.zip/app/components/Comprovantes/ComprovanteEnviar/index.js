import React from 'react';

import { injectIntl, intlShape, FormattedMessage } from 'react-intl';
import messages from './messages';
import ListItem from 'components/ListItem';

import enviarIcon from './enviar-icon.png';

const ComprovanteEnviar = props => { // eslint-disable-line react/prefer-stateless-function
  const { dadosLancamentoModel } = props;
  let { Destinatario } = dadosLancamentoModel.toJS();
  Destinatario = Destinatario.replace(/(\r\n|\n|\r)/gm, '|');
  const destSeparado = Destinatario.split('|').map((item) => { // eslint-disable-line arrow-body-style
    return item && (<span>{item}<br /></span>);
  });

  return (
    <ListItem key={3} icon={enviarIcon} notButton showProceedIcon={false} autoHeight>
      <div className="comprovanteLabelLineBreak" style={{ marginTop: 15, marginBottom: 80 }}><FormattedMessage {...messages.labelDestino} /></div>
      <span className="comprovanteValorLineBreak" style={{ top: 45 }}>{destSeparado}</span>
    </ListItem>
  );
};

ComprovanteEnviar.propTypes = {
  dadosLancamentoModel: React.PropTypes.object,
  intl: intlShape.isRequired,
};

export default injectIntl(ComprovanteEnviar);
