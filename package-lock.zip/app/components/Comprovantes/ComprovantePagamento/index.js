import React from 'react';

import { injectIntl, intlShape, FormattedMessage, FormattedNumber } from 'react-intl';
import messages from './messages';
import styles from './styles.css';
import ListItem from 'components/ListItem';

import cartoesIcon from './cartoes-icon.png';

const ComprovantePagamento = props => { // eslint-disable-line react/prefer-stateless-function
  const { dadosLancamentoModel } = props;
  const { CodigoBarras, Desconto, Valor, Protocolo } = dadosLancamentoModel.toJS();

  return (
    <div>
      <ListItem key={3} notButton showProceedIcon={false}>
        <div className={styles.marginLabel}><FormattedMessage {...messages.labelCodBarras} /></div>
        <div className={styles.codBarrasValor}>{CodigoBarras}</div>
      </ListItem>
      <ListItem key={4} notButton showProceedIcon={false}>
        <div><FormattedMessage {...messages.labelDesconto} /></div>
        <div><FormattedNumber style="decimal" minimumFractionDigits={2} value={Desconto} /></div>
      </ListItem>
      <ListItem key={5} notButton showProceedIcon={false}>
        <div><FormattedMessage {...messages.labelValor} /></div>
        <div><FormattedNumber style="decimal" minimumFractionDigits={2} value={Valor} /></div>
      </ListItem>
      <ListItem key={6} icon={cartoesIcon} notButton autoHeight showProceedIcon={false}>
        <div className={styles.marginLabel}><FormattedMessage {...messages.labelProtocolo} /></div>
        <div className={styles.informativeLabel}><FormattedMessage {...messages.informative} /></div>
        <div>{Protocolo}</div>
      </ListItem>
    </div>
  );
};

ComprovantePagamento.propTypes = {
  dadosLancamentoModel: React.PropTypes.object,
  intl: intlShape.isRequired,
};

export default injectIntl(ComprovantePagamento);
