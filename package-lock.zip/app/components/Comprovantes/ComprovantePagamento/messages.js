import { defineMessages } from 'react-intl';

export default defineMessages({
  labelCodBarras: {
    id: 'app.components.Comprovantes.ComprovantePagamento.labelCodBarras',
    defaultMessage: 'CÓDIGO DE BARRAS',
  },
  labelDesconto: {
    id: 'app.components.Comprovantes.ComprovantePagamento.labelDesconto',
    defaultMessage: 'DESCONTO',
  },
  labelValor: {
    id: 'app.components.Comprovantes.ComprovantePagamento.labelValor',
    defaultMessage: 'VALOR DO DOCUMENTO',
  },
  labelProtocolo: {
    id: 'app.components.Comprovantes.ComprovanteDocTed.labelProtocolo',
    defaultMessage: 'PROTOCOLO',
  },
  informative: {
    id: 'app.components.Comprovantes.ComprovanteDocTed.informative',
    defaultMessage: 'Comprovante de pagamento de títulos.',
  },
});
