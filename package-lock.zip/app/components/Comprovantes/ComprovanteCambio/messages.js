import { defineMessages } from 'react-intl';

export default defineMessages({
  labelCambio: {
    id: 'app.components.Comprovantes.ComprovanteCambio.labelCambio',
    defaultMessage: 'TAXA CÂMBIO',
  },
  labelIOF: {
    id: 'app.components.Comprovantes.ComprovanteCambio.labelIOF',
    defaultMessage: 'IOF',
  },
  labelTaxaVET: {
    id: 'app.components.Comprovantes.ComprovanteCambio.labelTaxaVET',
    defaultMessage: 'TAXA VET',
  },
  labelValor: {
    id: 'app.components.Comprovantes.ComprovanteCambio.labelValor',
    defaultMessage: 'VALOR EFETIVO TOTAL',
  },
});
