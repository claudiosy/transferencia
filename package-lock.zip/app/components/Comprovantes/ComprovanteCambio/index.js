import React from 'react';

import { injectIntl, intlShape, FormattedMessage, FormattedNumber } from 'react-intl';
import messages from './messages';
import dolarIcon from './dolar-icon.png';
import ListItem from 'components/ListItem';

const ComprovanteCambio = props => { // eslint-disable-line react/prefer-stateless-function
  const { dadosLancamentoModel } = props;
  const { TaxaCambio, Iof, TaxaVET, ValorTotalMoedaOrigem, SiglaMoedaOrigem } = dadosLancamentoModel.toJS();

  return (
    <div>
      <ListItem key={3} icon={dolarIcon} notButton showProceedIcon={false}>
        <div><FormattedMessage {...messages.labelCambio} /></div>
        <div><FormattedNumber style="decimal" minimumFractionDigits={2} value={TaxaCambio} /></div>
      </ListItem>
      <ListItem key={4} notButton showProceedIcon={false}>
        <div><FormattedMessage {...messages.labelIOF} /></div>
        <div><FormattedNumber style="currency" currency={SiglaMoedaOrigem} minimumFractionDigits={2} value={Iof} /></div>
      </ListItem>
      <ListItem key={5} icon={dolarIcon} notButton showProceedIcon={false}>
        <div><FormattedMessage {...messages.labelTaxaVET} /></div>
        <div><FormattedNumber style="decimal" minimumFractionDigits={2} value={TaxaVET} /></div>
      </ListItem>
      <ListItem key={6} notButton showProceedIcon={false}>
        <div><FormattedMessage {...messages.labelValor} /></div>
        <div><FormattedNumber style="currency" currency={SiglaMoedaOrigem} minimumFractionDigits={2} value={ValorTotalMoedaOrigem} /></div>
      </ListItem>
    </div>
  );
};

ComprovanteCambio.propTypes = {
  dadosLancamentoModel: React.PropTypes.object,
  intl: intlShape.isRequired,
};

export default injectIntl(ComprovanteCambio);
