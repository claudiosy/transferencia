import React from 'react';

import { injectIntl, intlShape, FormattedMessage } from 'react-intl';
import messages from './messages';
import styles from './styles.css';
import ListItem from 'components/ListItem';
import cartoesIcon from './cartoes-icon.png';

const ComprovanteCompra = props => { // eslint-disable-line react/prefer-stateless-function
  const { dadosLancamentoModel } = props;
  const { FinalCartao, NomeCartao } = dadosLancamentoModel.toJS();

  return (
    <div>
      <ListItem key={3} icon={cartoesIcon} notButton showProceedIcon={false}>
        <div className={styles.marginLabel}><FormattedMessage {...messages.labelCartao} /></div>
        <div className={styles.finalLabel}><FormattedMessage {...messages.labelFinal} /> {FinalCartao}</div>
        <div className={styles.cartaoLabel}><FormattedMessage {...messages.labelCartaoSuper} /></div>
        <div className={styles.nomeLabel}>{NomeCartao}</div>
      </ListItem>
    </div>
  );
};

ComprovanteCompra.propTypes = {
  dadosLancamentoModel: React.PropTypes.object,
  intl: intlShape.isRequired,
};

export default injectIntl(ComprovanteCompra);
