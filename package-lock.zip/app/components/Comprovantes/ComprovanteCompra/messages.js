import { defineMessages } from 'react-intl';

export default defineMessages({
  labelCartao: {
    id: 'app.components.Comprovantes.ComprovanteCompra.labelCartao',
    defaultMessage: 'CARTÃO',
  },
  labelFinal: {
    id: 'app.components.Comprovantes.ComprovanteCompra.labelFinal',
    defaultMessage: 'final ',
  },
  labelCartaoSuper: {
    id: 'app.components.Comprovantes.ComprovanteCompra.labelCartaoSuper',
    defaultMessage: 'MasterCard Superdigital',
  },
});
