import React from 'react';

import { injectIntl, intlShape, FormattedMessage } from 'react-intl';
import messages from './messages';
import ListItem from 'components/ListItem';

import simIcon from './sim-icon.png';

const ComprovanteRecargaCelular = props => { // eslint-disable-line react/prefer-stateless-function
  const { dadosLancamentoModel } = props;
  const { Operadora } = dadosLancamentoModel.toJS();

  return (
    <ListItem key={3} icon={simIcon} notButton showProceedIcon={false}>
      <div><FormattedMessage {...messages.labelOperadora} /></div>
      <div>{Operadora}</div>
    </ListItem>
  );
};

ComprovanteRecargaCelular.propTypes = {
  dadosLancamentoModel: React.PropTypes.object,
  intl: intlShape.isRequired,
};

export default injectIntl(ComprovanteRecargaCelular);
