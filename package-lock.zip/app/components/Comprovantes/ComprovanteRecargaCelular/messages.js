import { defineMessages } from 'react-intl';

export default defineMessages({
  labelOperadora: {
    id: 'app.components.Comprovantes.ComprovanteRecargaCelular.labelOperadora',
    defaultMessage: 'OPERADORA',
  },
});
