import { defineMessages } from 'react-intl';

export default defineMessages({
  labelBanco: {
    id: 'app.components.Comprovantes.ComprovanteAdicionar.labelBanco',
    defaultMessage: 'BANCO',
  },
});
