import React from 'react';
import ListItem from 'components/ListItem';

import { injectIntl, intlShape, FormattedMessage } from 'react-intl';
import messages from './messages';

import dolarIcon from './dolar-icon.png';

const ComprovanteAdicionar = props => { // eslint-disable-line react/prefer-stateless-function
  const { dadosLancamentoModel } = props;
  const { Banco } = dadosLancamentoModel.toJS();

  return (
    <ListItem key={3} icon={dolarIcon} notButton showProceedIcon={false}>
      <div><FormattedMessage {...messages.labelBanco} /></div>
      <div>{Banco}</div>
    </ListItem>
  );
};

ComprovanteAdicionar.propTypes = {
  dadosLancamentoModel: React.PropTypes.object,
  intl: intlShape.isRequired,
};

export default injectIntl(ComprovanteAdicionar);
