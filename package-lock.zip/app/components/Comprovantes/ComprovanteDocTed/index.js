import React from 'react';

import { injectIntl, intlShape, FormattedMessage } from 'react-intl';
import messages from './messages';
import ListItem from 'components/ListItem';

import calendarioIcon from './calendario-icon.png';
import dolarIcon from './dolar-icon.png';

const ComprovanteDocTed = props => { // eslint-disable-line react/prefer-stateless-function
  const { dadosLancamentoModel } = props;
  const { NomeDestinatario, DocumentoDestinatario, Banco, Agencia, Conta, TipoConta } = dadosLancamentoModel.toJS();

  return (
    <div>
      <ListItem key={3} icon={calendarioIcon} notButton showProceedIcon={false}>
        <div><FormattedMessage {...messages.labelDestinatario} /></div>
        <div>{NomeDestinatario}</div>
      </ListItem>
      <ListItem key={4} notButton showProceedIcon={false}>
        <div><FormattedMessage {...messages.labelDocumento} /></div>
        <div>{DocumentoDestinatario}</div>
      </ListItem>
      <ListItem key={5} icon={dolarIcon} notButton showProceedIcon={false}>
        <div><FormattedMessage {...messages.labelBanco} /></div>
        <div>{Banco}</div>
      </ListItem>
      <ListItem key={6} notButton showProceedIcon={false}>
        <div><FormattedMessage {...messages.labelAgencia} /></div>
        <div>{Agencia}</div>
      </ListItem>
      <ListItem key={7} notButton showProceedIcon={false}>
        <div><FormattedMessage {...messages.labelConta} /></div>
        <div>{Conta}</div>
      </ListItem>
      <ListItem key={8} notButton showProceedIcon={false}>
        <div><FormattedMessage {...messages.labelTipoConta} /></div>
        <div>{TipoConta}</div>
      </ListItem>
    </div>
  );
};

ComprovanteDocTed.propTypes = {
  dadosLancamentoModel: React.PropTypes.object,
  intl: intlShape.isRequired,
};

export default injectIntl(ComprovanteDocTed);
