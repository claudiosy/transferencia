import { defineMessages } from 'react-intl';

export default defineMessages({
  labelDestinatario: {
    id: 'app.components.Comprovantes.ComprovanteDocTed.labelDestinatario',
    defaultMessage: 'DESTINATÁRIO',
  },
  labelDocumento: {
    id: 'app.components.Comprovantes.ComprovanteDocTed.labelDocumento',
    defaultMessage: 'DOCUMENTO',
  },
  labelBanco: {
    id: 'app.components.Comprovantes.ComprovanteDocTed.labelBanco',
    defaultMessage: 'BANCO',
  },
  labelAgencia: {
    id: 'app.components.Comprovantes.ComprovanteDocTed.labelAgencia',
    defaultMessage: 'AGÊNCIA',
  },
  labelConta: {
    id: 'app.components.Comprovantes.ComprovanteDocTed.labelConta',
    defaultMessage: 'CONTA',
  },
  labelTipoConta: {
    id: 'app.components.Comprovantes.ComprovanteDocTed.labelTipoConta',
    defaultMessage: 'TIPO CONTA',
  },
});
