import { defineMessages } from 'react-intl';

export default defineMessages({
  loadingDetalhes: {
    id: 'app.components.Comprovantes.ComprovanteBase.loadingDetalhes',
    defaultMessage: 'Carregando comprovante...',
  },
  labelData: {
    id: 'app.components.Comprovantes.ComprovanteBase.labelData',
    defaultMessage: 'DATA',
  },
  labelPortador: {
    id: 'app.components.Comprovantes.ComprovanteBase.labelPortador',
    defaultMessage: 'PORTADOR',
  },
  labelAutenticacao: {
    id: 'app.components.Comprovantes.ComprovanteBase.labelAutenticacao',
    defaultMessage: 'AUTENTICAÇÃO',
  },
  labelCategoria: {
    id: 'app.components.Comprovantes.ComprovanteBase.labelCategoria',
    defaultMessage: 'CATEGORIA',
  },
});
