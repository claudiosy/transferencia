import React from 'react';
import CircularProgress from 'material-ui/CircularProgress';
import moment from 'moment';
import List from 'components/List';
import ListItem from 'components/ListItem';

import moedaLookup from 'utils/moedaLookup';

import { injectIntl, intlShape, FormattedMessage, FormattedNumber } from 'react-intl';
import messages from './messages';
import styles from './styles.css';

import calendarioIcon from './calendario-icon.png';
import personIcon from 'containers/App/person-icon.png';
import dolarIcon from './dolar-icon.png';
import categoriaIcon from './categoria-icon.png';
import iconInfo from 'containers/App/icon-info.png';

import ComprovanteAdicionar from 'components/Comprovantes/ComprovanteAdicionar';
import ComprovanteCambio from 'components/Comprovantes/ComprovanteCambio';
import ComprovanteCompra from 'components/Comprovantes/ComprovanteCompra';
import ComprovanteDocTed from 'components/Comprovantes/ComprovanteDocTed';
import ComprovantePagamento from 'components/Comprovantes/ComprovantePagamento';
import ComprovanteRecargaCelular from 'components/Comprovantes/ComprovanteRecargaCelular';
import ComprovanteRecargaTransporte from 'components/Comprovantes/ComprovanteRecargaTransporte';
import ComprovanteEnviar from 'components/Comprovantes/ComprovanteEnviar';

const ComprovanteBase = props => { // eslint-disable-line react/prefer-stateless-function
  const { loading, message, dadosLancamentoModel } = props;
  const { SimboloMoeda, SiglaMoedaOrigem, Valor, DataCriacao, Autenticacao, Categoria, TipoComprovanteId, Portador } = dadosLancamentoModel.toJS();
  let content;
  let contentTipo;
  const DataComprovante = moment(new Date(DataCriacao)).format('DD/MM/YYYY');

  if (message) {
    content = (
      <List>
        <ListItem key={1} icon={iconInfo} notButton showProceedIcon={false}>
          {message}
        </ListItem>
      </List>
    );
  } else if (loading) {
    content = (
      <div className={styles.loadingHistorico}>
        <CircularProgress size={0.3} />
        <FormattedMessage {...messages.loadingDetalhes} />
      </div>
    );
  } else {
    switch (TipoComprovanteId) {
      /* Pagamento = 1,
      TransferenciaDocTed =2,
      Transferencia = 3,
      CargaRecorrente = 4,
      RecargaCelular = 5,
      CargaPrePago =6,
      CargaDocTed=7,
      CargaBilheteTransporte =8,
      CambioMoeda = 9,
      Autorizacao=10,
      VaquinhaRachar=11 */
      case 1:
        contentTipo = (<ComprovantePagamento dadosLancamentoModel={dadosLancamentoModel} />);
        break;
      case 2:
        contentTipo = (<ComprovanteDocTed dadosLancamentoModel={dadosLancamentoModel} />);
        break;
      case 3:
        contentTipo = (<ComprovanteEnviar dadosLancamentoModel={dadosLancamentoModel} />);
        break;
      case 4:
        contentTipo = (<ComprovanteAdicionar dadosLancamentoModel={dadosLancamentoModel} />);
        break;
      case 5:
        contentTipo = (<ComprovanteRecargaCelular dadosLancamentoModel={dadosLancamentoModel} />);
        break;
      case 6:
        contentTipo = (<ComprovanteAdicionar dadosLancamentoModel={dadosLancamentoModel} />);
        break;
      case 7:
        contentTipo = (<ComprovanteAdicionar dadosLancamentoModel={dadosLancamentoModel} />);
        break;
      case 8:
        contentTipo = (<ComprovanteRecargaTransporte dadosLancamentoModel={dadosLancamentoModel} />);
        break;
      case 9:
        contentTipo = (<ComprovanteCambio dadosLancamentoModel={dadosLancamentoModel} />);
        break;
      case 10:
        contentTipo = (<ComprovanteCompra dadosLancamentoModel={dadosLancamentoModel} />);
        break;
      case 11:
        contentTipo = (<ComprovanteEnviar dadosLancamentoModel={dadosLancamentoModel} />);
        break;
      default:
        contentTipo = '';
        break;
    }

    content = (
      <div>
        <div className={styles.topo}>
          <span>{SimboloMoeda || moedaLookup(SiglaMoedaOrigem)}</span>
          <span><FormattedNumber style="decimal" minimumFractionDigits={2} value={Valor.toString().replace('-', '')} /></span>
        </div>

        <List>
          <ListItem key={1} icon={calendarioIcon} notButton showProceedIcon={false}>
            <div><FormattedMessage {...messages.labelData} /></div>
            <div>{DataComprovante}</div>
          </ListItem>
          <ListItem key={2} icon={personIcon} notButton showProceedIcon={false}>
            <div><FormattedMessage {...messages.labelPortador} /></div>
            <div>{Portador}</div>
          </ListItem>
          {contentTipo}
          <ListItem key={10} icon={dolarIcon} notButton showProceedIcon={false}>
            <div className="comprovanteLabelLineBreak"><FormattedMessage {...messages.labelAutenticacao} /></div>
            <span className="comprovanteValorLineBreak">{Autenticacao}</span>
          </ListItem>
          <ListItem key={11} icon={categoriaIcon} notButton showProceedIcon={false}>
            <div><FormattedMessage {...messages.labelCategoria} /></div>
            <div>{Categoria}</div>
          </ListItem>
        </List>
      </div>
    );
  }
  return (
    <div className={styles.formWrapper}>
      {content}
    </div>);
};

ComprovanteBase.propTypes = {
  pristine: React.PropTypes.bool,
  loading: React.PropTypes.bool,
  message: React.PropTypes.string,
  dadosLancamentoModel: React.PropTypes.object,
  intl: intlShape.isRequired,
};

export default injectIntl(ComprovanteBase);
