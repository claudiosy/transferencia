import { defineMessages } from 'react-intl';

export default defineMessages({
  labelBilhete: {
    id: 'app.components.Comprovantes.ComprovanteRecargaTransporte.labelBilhete',
    defaultMessage: 'NÚMERO DO BILHETE',
  },
  labelPedido: {
    id: 'app.components.Comprovantes.ComprovanteRecargaTransporte.labelPedido',
    defaultMessage: 'NÚMERO DO PEDIDO',
  },
});
