import React from 'react';

import { injectIntl, intlShape, FormattedMessage } from 'react-intl';
import messages from './messages';
import ListItem from 'components/ListItem';

import cartoesIcon from './cartoes-icon.png';

const ComprovanteRecargaTransporte = props => { // eslint-disable-line react/prefer-stateless-function
  const { dadosLancamentoModel } = props;
  const { NumeroBilhete, Doc } = dadosLancamentoModel.toJS();

  return (
    <div>
      <ListItem key={3} icon={cartoesIcon} notButton showProceedIcon={false}>
        <div><FormattedMessage {...messages.labelBilhete} /></div>
        <div>{NumeroBilhete}</div>
      </ListItem>
      <ListItem key={4} icon={cartoesIcon} notButton showProceedIcon={false}>
        <div><FormattedMessage {...messages.labelPedido} /></div>
        <div>{Doc}</div>
      </ListItem>
    </div>
  );
};

ComprovanteRecargaTransporte.propTypes = {
  dadosLancamentoModel: React.PropTypes.object,
  intl: intlShape.isRequired,
};

export default injectIntl(ComprovanteRecargaTransporte);
