import { defineMessages } from 'react-intl';

export default defineMessages({
  header: {
    id: 'superdigital.ComprovanteRacharConta.header',
    defaultMessage: 'Comprovante',
  },
  ButtonDetalhes: {
    id: 'superdigital.ComprovanteRacharConta.ButtonDetalhes',
    defaultMessage: 'Detalhes',
  },
  ButtonAnexar: {
    id: 'superdigital.ComprovanteRacharConta.ButtonAnexar',
    defaultMessage: 'Anexar',
  },
});
