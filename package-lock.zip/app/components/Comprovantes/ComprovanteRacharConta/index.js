import React from 'react';
import { Grid } from 'react-flexbox-grid/lib/index';

import SelectField from 'material-ui/SelectField';
import MenuItem from 'material-ui/MenuItem';
import FlatButton from 'material-ui/FlatButton';
import Loader from 'components/Loader';

import { FormattedNumber, injectIntl, intlShape } from 'react-intl';
import messages from './messages';
import styles from './styles.css';

import addIcon from 'containers/App/close.png';
import comprovanteIcon from 'containers/App/comprovante-icon.png';

const ComprovanteRacharConta = props => { // eslint-disable-line react/prefer-stateless-function
  const { loading, message, handleClick, dadosComprovante, selecionados } = props;
  const { formatMessage } = props.intl;
  let content;

  if (message) {
    content = (<h2>{message}</h2>);
  } else if (loading) {
    content = (<div className={styles.centered}><Loader top={'45%'} /></div>);
  } else {
    content = (
      <Grid fluid>
        <div className={styles.topo}>
          <span className={styles.data}>14 Out</span>
        </div>
        <div className={styles.comprovante}>
          <span className={styles.titulo}>TOTAL <span className={styles.hora}>4:16 PM</span></span>
          <br /><br />
          <span className={styles.moeda}>R$</span><span className={styles.valor}><FormattedNumber style="decimal" minimumFractionDigits={2} value={dadosComprovante.valor} /></span>
          <hr size={'1'} />
          <span className={styles.subtituloNegrito}>POR PESSOA</span>
          <br />
          <span className={styles.subtitulo}><FormattedNumber style="currency" minimumFractionDigits={2} currency="BRL" value={dadosComprovante.valor / (selecionados.length + 1)} /></span>
          <hr size={'1'} />
          <span className={styles.subtituloClaro}>CTRL</span>
          <br />
          <span className={styles.subtitulo}>{dadosComprovante.ctrl}</span>
          <br /><br />
          <span className={styles.subtituloClaro}>AUTENTICAÇÃO</span>
          <br />
          <span className={styles.subtitulo}>{dadosComprovante.autenticacao}</span>
          <hr size={'1'} />
          <SelectField hintText="COMPARTILHAR" className={`redInput ${styles.compartilhar}`} >
            <MenuItem value={1} primaryText="ÍTEM 1" />
            <MenuItem value={2} primaryText="ÍTEM 2" />
            <MenuItem value={3} primaryText="ÍTEM 3" />
            <MenuItem value={4} primaryText="ÍTEM 4" />
            <MenuItem value={5} primaryText="ÍTEM 5" />
          </SelectField>
          <FlatButton className={styles.subtitulo} type="button" label={formatMessage(messages.ButtonDetalhes)} onClick={() => handleClick()} >
            <img src={addIcon} alt="" />
          </FlatButton>
          <FlatButton className={styles.subtitulo} type="button" label={formatMessage(messages.ButtonAnexar)} onClick={() => handleClick()} >
            <img src={addIcon} alt="" />
          </FlatButton>
        </div>
        <div className={styles.footer}>
          <img src={comprovanteIcon} className={styles.centerIcon} alt="" />
        </div>
      </Grid>
    );
  }
  return (
    <div className={styles.formWrapper}>
      {content}
    </div>);
};

ComprovanteRacharConta.propTypes = {
  loading: React.PropTypes.bool,
  message: React.PropTypes.string,
  handleClick: React.PropTypes.func,
  dadosComprovante: React.PropTypes.object,
  intl: intlShape.isRequired,
  selecionados: React.PropTypes.object,
};

export default injectIntl(ComprovanteRacharConta);
