import { defineMessages } from 'react-intl';

export default defineMessages({
  header: {
    id: 'superdigital.SuperDigitalForm.header',
    defaultMessage: 'CONTA SUPERDIGITAL',
  },
  labelCPF: {
    id: 'superdigital.SuperDigitalForm.labelCPF',
    defaultMessage: 'Digite o CPF do destinatário',
  },
  labelEmail: {
    id: 'superdigital.SuperDigitalForm.labelEmail',
    defaultMessage: 'Digite o email do destinatário',
  },
  labelCelular: {
    id: 'superdigital.SuperDigitalForm.labelCelular',
    defaultMessage: 'Digite o Celular do destinatário',
  },
  favoriteCheckbox: {
    id: 'superdigital.SuperDigitalForm.favoriteCheckbox',
    defaultMessage: 'Adicionar aos favoritos',
  },
  submitButton: {
    id: 'superdigital.SuperDigitalForm.submitButton',
    defaultMessage: 'Continuar',
  },
});
