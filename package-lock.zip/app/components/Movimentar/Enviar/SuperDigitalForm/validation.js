import messages from 'containers/App/messages';
import { validadeCPF } from 'containers/App/validation';

const validateSuperDigitalForm = (valuesFromState, props) => {
  const { formatMessage } = props.intl;
  const errors = {};
  const values = valuesFromState.toJS();

  if (values.CPF && !validadeCPF(values.CPF)) {
    errors.CPF = formatMessage(messages.invalidCPF);
  }
  if (values.Email && !/^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,4}$/i.test(values.Email)) {
    errors.Email = formatMessage(messages.invalidEmail);
  }
  return errors;
};

export default validateSuperDigitalForm;
