import { validaEnvio } from 'containers/Movimentar/EnviarPage/actions';

const asyncValidateSuperDigitalForm = (values, dispatch) => { // eslint-disable-line arrow-body-style
  const data = values.toJS();
  return new Promise((resolve, reject) => {
    let field = '';
    let valor = '';
    let acao = 0;

    if (data.CPF) {
      field = 'CPF';
      valor = data.CPF;
      acao = 2;
    } else if (data.Email) {
      field = 'Email';
      valor = data.Email;
      acao = 1;
    } else if (data.Celular) {
      field = 'Celular';
      valor = data.Celular;
      acao = 3;
    }

    dispatch(validaEnvio(valor, acao, resolve, reject, field, (value) => { // eslint-disable-line arrow-body-style
      return value.Sucesso && value.Dados.Nome && value.Dados.Acao === 3;
    }));
  }).then(() => {});
};

export default asyncValidateSuperDigitalForm;
