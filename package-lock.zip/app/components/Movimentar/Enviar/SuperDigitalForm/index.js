import React from 'react';
import { reduxForm, Field, formValueSelector } from 'redux-form/immutable';
import { connect } from 'react-redux';
import { TextField } from 'redux-form-material-ui';
import { injectIntl, intlShape } from 'react-intl';
import FlatButton from 'material-ui/FlatButton';
import List from 'components/List';
import ListItem from 'components/ListItem';
import { normalizeCPF, normalizeCelular } from 'normalizers';
import validateSuperDigitalForm from './validation';
import asyncValidateSuperDigitalForm from './asyncValidation';
import AddToFavorites from 'components/AddToFavorites';
import { setFavoritoState } from 'containers/Movimentar/EnviarPage/actions';

import messages from './messages';

import styles from './styles.css';
import enviarIcon from 'containers/Movimentar/EnviarPage/enviar-icon.png';

const SuperDigitalForm = props => { // eslint-disable-line react/prefer-stateless-function
  const { handleSubmit, pristine, submitting, superDigitalModel, favoritoState, handleSetFavoritoState } = props;
  const { formatMessage } = props.intl;
  const TipoForm = superDigitalModel.toJS().TipoForm;

  return (
    <div className={styles.formWrapper}>
      <form onSubmit={handleSubmit}>
        <List>
          <ListItem key={3} icon={enviarIcon} invisibled={TipoForm !== 3}>
            <Field autoFocus name="CPF" className="redInput" component={TextField} hintText={formatMessage(messages.labelCPF)} label={formatMessage(messages.labelCPF)} type="tel" normalize={normalizeCPF} tabIndex="1" />
          </ListItem>
        </List>
        <List>
          <ListItem key={4} icon={enviarIcon} invisibled={TipoForm !== 4}>
            <Field autoFocus name="Email" className="redInput" component={TextField} hintText={formatMessage(messages.labelEmail)} label={formatMessage(messages.labelEmail)} tabIndex="1" />
          </ListItem>
        </List>
        <List>
          <ListItem key={5} icon={enviarIcon} invisibled={TipoForm !== 5}>
            <Field autoFocus name="Celular" className="redInput" component={TextField} hintText={formatMessage(messages.labelCelular)} label={formatMessage(messages.labelCelular)} type="tel" normalize={normalizeCelular} tabIndex="1" />
          </ListItem>
        </List>
        <AddToFavorites state={favoritoState} onToggle={handleSetFavoritoState} />
        <FlatButton name="btnContinuar" className="redButton big centered" type="submit" label={formatMessage(messages.submitButton)} disabled={pristine || submitting} tabIndex="3" />
      </form>
    </div>);
};

SuperDigitalForm.propTypes = {
  handleSubmit: React.PropTypes.func,
  pristine: React.PropTypes.bool,
  submitting: React.PropTypes.bool,
  TipoForm: React.PropTypes.number,
  superDigitalModel: React.PropTypes.object,
  CPF: React.PropTypes.string,
  Email: React.PropTypes.string,
  Celular: React.PropTypes.string,
  intl: intlShape.isRequired,
  column2Selection: React.PropTypes.number,
  favoritoState: React.PropTypes.bool,
  handleSetFavoritoState: React.PropTypes.func,
};

function mapDispatchToProps(dispatch) {
  return {
    handleSetFavoritoState: () => {
      dispatch(setFavoritoState());
    },
    dispatch,
  };
}

const selector = formValueSelector('superDigitalFormForm');
export default connect(
  state => {
    const TipoForm = selector(state, 'TipoForm');
    return {
      TipoForm,
    };
  }, mapDispatchToProps)(injectIntl(reduxForm({
    form: 'superDigitalFormForm',
    validate: validateSuperDigitalForm,
    asyncValidate: asyncValidateSuperDigitalForm,
    // asyncBlurFields: ['CPF', 'Email', 'Celular'],
    // enableReinitialize: true,
  })(SuperDigitalForm)));
