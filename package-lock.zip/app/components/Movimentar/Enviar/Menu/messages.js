import { defineMessages } from 'react-intl';

export default defineMessages({
  superDigital: {
    id: 'app.components.Movimentar.Enviar.Menu.superDigital',
    defaultMessage: 'SUPERDIGITAL',
  },
  outrosBancos: {
    id: 'app.components.Movimentar.Enviar.Menu.outrosBancos',
    defaultMessage: 'OUTROS BANCOS',
  },
});
