import React from 'react';
import { reduxForm } from 'redux-form/immutable';
import List from 'components/List';
import ListItem from 'components/ListItem';
import styles from './styles.css';
import { FormattedMessage } from 'react-intl';
import messages from './messages';

const Menu = props => { // eslint-disable-line react/prefer-stateless-function
  const { handleStepChange, columnSelection, columnOrder } = props;

  return (
    <div className={styles.formWrapper}>
      <List showProceedIcon showHoverEffect behind={columnSelection !== 0} activeItem={columnSelection}>
        <ListItem name="enviarSuperdigital" key={1} onClick={() => handleStepChange(columnOrder, 1)}>
          <FormattedMessage {...messages.superDigital} />
        </ListItem>
        <ListItem name="enviarOutrosBancos" key={2} onClick={() => handleStepChange(columnOrder, 2)}>
          <FormattedMessage {...messages.outrosBancos} />
        </ListItem>
      </List>
    </div>);
};

Menu.propTypes = {
  handleStepChange: React.PropTypes.func,
  columnSelection: React.PropTypes.number,
  columnOrder: React.PropTypes.number,
};

export default reduxForm({
  form: 'menuEnviarForm',
})(Menu);
