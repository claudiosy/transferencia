import messages from 'containers/App/messages';

const validateContaSantanderForm = (valuesFromState, props) => {
  const { formatMessage } = props.intl;
  const errors = {};
  const values = valuesFromState.toJS();

  if (!values.agencia) {
    errors.agencia = formatMessage(messages.mandatoryField);
  }
  if (!values.conta) {
    errors.conta = formatMessage(messages.mandatoryField);
  }
  if (!values.valor) {
    errors.valor = formatMessage(messages.mandatoryField);
  }
  return errors;
};

export default validateContaSantanderForm;
