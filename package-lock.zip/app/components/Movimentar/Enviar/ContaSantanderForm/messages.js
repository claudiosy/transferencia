import { defineMessages } from 'react-intl';

export default defineMessages({
  header: {
    id: 'superdigital.ContaSantanderForm.header',
    defaultMessage: 'Enviar Conta Santander',
  },
  labelAgencia: {
    id: 'superdigital.ContaSantanderForm.labelAgencia',
    defaultMessage: 'Agência',
  },
  labelConta: {
    id: 'superdigital.ContaSantanderForm.labelConta',
    defaultMessage: 'Conta',
  },
  labelValor: {
    id: 'superdigital.ContaSantanderForm.labelCPF',
    defaultMessage: 'Digite o valor',
  },
  submitButton: {
    id: 'superdigital.ContaSantanderForm.submitButton',
    defaultMessage: 'Continuar',
  },
});
