import React from 'react';
import { reduxForm, Field } from 'redux-form/immutable';
import { TextField } from 'redux-form-material-ui';
import FlatButton from 'material-ui/FlatButton';
import CircularProgress from 'material-ui/CircularProgress';
import { normalizeDecimal } from 'normalizers';
import validateContaSantanderForm from './validation';

import { injectIntl, intlShape } from 'react-intl';

import messages from './messages';
import styles from './styles.css';

import List from 'components/List';
import ListItem from 'components/ListItem';

import enviarIcon from 'containers/Movimentar/EnviarPage/enviar-icon.png';
import dolarIcon from './dolar-icon.png';

const ContaSantanderForm = props => { // eslint-disable-line react/prefer-stateless-function
  const { handleSubmit, pristine, submitting, loading, message } = props;
  const { formatMessage } = props.intl;
  let content;

  if (message) {
    content = (<h2>{message}</h2>);
  } else if (loading) {
    content = (<div><CircularProgress /></div>);
  } else {
    content = (
      <form onSubmit={handleSubmit}>
        <List>
          <ListItem key={1} icon={enviarIcon}>
            <Field name="agencia" className="redInput" component={TextField} hintText={formatMessage(messages.labelAgencia)} label={formatMessage(messages.labelAgencia)} tabIndex="1" />
            <Field name="conta" className="redInput" component={TextField} hintText={formatMessage(messages.labelConta)} label={formatMessage(messages.labelConta)} tabIndex="2" />
          </ListItem>
          <ListItem key={2} icon={dolarIcon}>
            <Field name="valor" className="redInput" component={TextField} hintText={formatMessage(messages.labelValor)} label={formatMessage(messages.labelValor)} type="tel" normalize={normalizeDecimal} tabIndex="3" />
          </ListItem>
        </List>
        <FlatButton className="redButton big centered" type="submit" label={formatMessage(messages.submitButton)} disabled={pristine || submitting} tabIndex="4" />
      </form>
    );
  }
  return (
    <div className={styles.formWrapper}>
      {content}
    </div>);
};

ContaSantanderForm.propTypes = {
  handleSubmit: React.PropTypes.func,
  pristine: React.PropTypes.bool,
  loading: React.PropTypes.bool,
  message: React.PropTypes.string,
  submitting: React.PropTypes.bool,
  valor: React.PropTypes.string,
  intl: intlShape.isRequired,
};

export default injectIntl(reduxForm({
  form: 'contaSantanderForm',
  validate: validateContaSantanderForm,
})(ContaSantanderForm));
