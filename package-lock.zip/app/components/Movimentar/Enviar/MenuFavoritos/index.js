import React from 'react';
import { reduxForm } from 'redux-form/immutable';
import List from 'components/List';
import ListItem from 'components/ListItem';
import Loader from 'components/Loader';
import styles from './styles.css';
import superIcon from 'containers/App/super-icon.png';
import { FormattedMessage } from 'react-intl';
import messages from './messages';

const colors =
  ['#1FCB4A',
    '#01FCEF',
    '#892EE4',
    '#06DCFB',
    '#B6BA18',
    '#03EBA6',
    '#3923D6',
    '#48FB0D',
    '#2DC800',
    '#9A03FE',
    '#23819C',
    '#2966B8',
    '#5757FF',
    '#9D9D00',
    '#FF68DD',
    '#59955C',
    '#FF4848',
    '#872187',
    '#59DF00',
    '#62A9FF',
    '#FE67EB',
    '#9669FE',
    '#800080',
    '#FF62B0',
    '#E469FE',
    '#D568FD',
    '#62D0FF'];

function renderChildren(names, props) {
  return names.toJS().map((favoritos, key) => { // eslint-disable-line
    const iniciais = favoritos.Identificacao.split(' ').length === 1 ? favoritos.Identificacao.split(' ')[0].substring(0, 1) : favoritos.Identificacao.split(' ')[0].substring(0, 1) + favoritos.Identificacao.split(' ')[1].substring(0, 1);
    const iconSuper = favoritos.Superdigital ? (<img src={superIcon} className={styles.iconSuper} alt="" />) : '';
    let avatar = null;

    if (favoritos.Avatar) {
      avatar = (<span className={styles.iconName}><img src={favoritos.Avatar} role="presentation" /></span>);
    } else {
      avatar = (<span className={styles.iconName} style={{ 'background-color': colors[key] }}><div className={styles.divIniciais}>{iniciais}</div></span>);
    }

    return (
      <ListItem name={key + 1} key={key + 1} id={key + 1} onClick={() => props.handleItemClick(key + 1, favoritos)}>
        {avatar}
        <span className={styles.identificacao}>{favoritos.Identificacao}</span>
        <span className={styles.contato}>{favoritos.Contato}</span>
        {iconSuper}
      </ListItem>
    );
  });
}

const MenuFavoritos = props => { // eslint-disable-line react/prefer-stateless-function
  const { loading, columnSelection, favoritos, handleItemClick, transfAutomatica } = props;

  if (loading) {
    return (<Loader top={0} />);
  }

  return (
    <div className={styles.formWrapper}>
      <List showProceedIcon showHoverEffect behind={columnSelection !== 0} activeItem={columnSelection}>
        <ListItem name="enviarOutrasFormas" key={-1} onClick={() => handleItemClick(-1, null)} >
          <FormattedMessage {...messages.outrasFormasEnviar} />
        </ListItem>
        <ListItem name="enviarTransferenciaAutomatica" key={-2} onClick={() => handleItemClick(-2, null)} invisibled={transfAutomatica.toJS().EmpresaPagadora === null && transfAutomatica.toJS().CNPJPagador === null} >
          <FormattedMessage {...messages.transferenciaAutomatica} />
        </ListItem>
        {renderChildren(favoritos, props)}
      </List>
    </div>);
};

MenuFavoritos.propTypes = {
  loading: React.PropTypes.bool,
  handleItemClick: React.PropTypes.func,
  columnSelection: React.PropTypes.number,
  columnOrder: React.PropTypes.number,
  favoritos: React.PropTypes.object,
  transfAutomatica: React.PropTypes.object,
};

export default reduxForm({
  form: 'menuFavoritosForm',
})(MenuFavoritos);
