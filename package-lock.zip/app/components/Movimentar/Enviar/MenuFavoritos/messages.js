import { defineMessages } from 'react-intl';

export default defineMessages({
  outrasFormasEnviar: {
    id: 'app.components.Movimentar.Enviar.MenuFavoritos.outrasFormasEnviar',
    defaultMessage: 'ENVIAR $',
  },
  transferenciaAutomatica: {
    id: 'app.components.Movimentar.Enviar.MenuFavoritos.transferenciaAutomatica',
    defaultMessage: 'TRANSFERÊNCIA AUTOMÁTICA',
  },
});
