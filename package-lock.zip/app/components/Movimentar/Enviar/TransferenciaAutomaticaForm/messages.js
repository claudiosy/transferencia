import { defineMessages } from 'react-intl';

export default defineMessages({
  header: {
    id: 'app.components.Movimentar.Enviar.TransferenciaAutomaticaForm.header',
    defaultMessage: 'Transferência Automática',
  },
  labelToggleInativa: {
    id: 'app.components.Movimentar.Enviar.TransferenciaAutomaticaForm.labelToggleInativa',
    defaultMessage: 'Transferência Automática [Inativa]',
  },
  labelToggleAtiva: {
    id: 'app.components.Movimentar.Enviar.TransferenciaAutomaticaForm.labelToggleAtiva',
    defaultMessage: 'Transferência Automática [Ativa]',
  },
  labelEmpresaPagadora: {
    id: 'app.components.Movimentar.Enviar.TransferenciaAutomaticaForm.labelEmpresaPagadora',
    defaultMessage: 'Empresa',
  },
  labelCNPJPagador: {
    id: 'app.components.Movimentar.Enviar.TransferenciaAutomaticaForm.labelCNPJPagador',
    defaultMessage: 'CNPJ',
  },
  labelDestinatario: {
    id: 'app.components.Movimentar.Enviar.TransferenciaAutomaticaForm.labelDestinatario',
    defaultMessage: 'Destinatário',
  },
  labelCPF: {
    id: 'app.components.Movimentar.Enviar.TransferenciaAutomaticaForm.labelCPF',
    defaultMessage: 'CPF do destinatário',
  },
  labelCNPJ: {
    id: 'app.components.Movimentar.Enviar.TransferenciaAutomaticaForm.labelCNPJ',
    defaultMessage: 'CNPJ do destinatário',
  },
  labelBanco: {
    id: 'app.components.Movimentar.Enviar.TransferenciaAutomaticaForm.labelBanco',
    defaultMessage: 'Banco',
  },
  labelAgencia: {
    id: 'app.components.Movimentar.Enviar.TransferenciaAutomaticaForm.labelAgencia',
    defaultMessage: 'Agência',
  },
  labelConta: {
    id: 'app.components.Movimentar.Enviar.TransferenciaAutomaticaForm.labelConta',
    defaultMessage: 'Conta',
  },
  labelDigito: {
    id: 'app.components.Movimentar.Enviar.TransferenciaAutomaticaForm.labelDigito',
    defaultMessage: 'Dígito',
  },
  labelTipoConta: {
    id: 'app.components.Movimentar.Enviar.TransferenciaAutomaticaForm.labelTipoConta',
    defaultMessage: 'Tipo de Conta',
  },
  labelContaCorrente: {
    id: 'app.components.Movimentar.Enviar.TransferenciaAutomaticaForm.labelContaCorrente',
    defaultMessage: 'Corrente',
  },
  labelContaPoupanca: {
    id: 'app.components.Movimentar.Enviar.TransferenciaAutomaticaForm.labelContaPoupanca',
    defaultMessage: 'Poupança',
  },
  submitButton: {
    id: 'app.components.Movimentar.Enviar.TransferenciaAutomaticaForm.submitButton',
    defaultMessage: 'Continuar',
  },
});
