import messages from 'containers/App/messages';
import { validadeCPF, validadeCNPJ } from 'containers/App/validation';

const validateTransferenciaAutomatica = (valuesFromState, props) => {
  const { formatMessage } = props.intl;
  const errors = {};
  const values = valuesFromState.toJS();

  if (!props.initialized) {
    return errors;
  }
  if (!values.Destinatario) {
    errors.Destinatario = formatMessage(messages.mandatoryField);
  }
  if (!values.CPF && !values.CNPJ) {
    errors.CPF = formatMessage(messages.mandatoryField);
    errors.CNPJ = formatMessage(messages.mandatoryField);
  }
  if (values.CPF) {
    if (!validadeCPF(values.CPF)) {
      errors.CPF = formatMessage(messages.invalidCPF);
    }
  }
  if (values.CNPJ) {
    if (!validadeCNPJ(values.CNPJ)) {
      errors.CNPJ = formatMessage(messages.invalidCNPJ);
    }
  }
  if (!values.Banco || values.Banco.length < 3) {
    errors.Banco = formatMessage(messages.mandatoryField);
  }
  if (!values.Banco || values.Banco.toString().indexOf('(') === -1) {
    errors.Banco = formatMessage(messages.mandatorySelectBanco);
  }
  if (!values.Agencia) {
    errors.Agencia = formatMessage(messages.mandatoryField);
  }
  if (!values.Conta) {
    errors.Conta = formatMessage(messages.mandatoryField);
  }
  if (!values.TipoConta) {
    errors.TipoConta = formatMessage(messages.mandatoryField);
  }
  return errors;
};

export default validateTransferenciaAutomatica;
