import React from 'react';
import { reduxForm, Field, change, formValueSelector } from 'redux-form/immutable';
import { connect } from 'react-redux';
import { TextField, AutoComplete, SelectField, Toggle } from 'redux-form-material-ui';
import { AutoComplete as MUIAutoComplete } from 'material-ui';
import MenuItem from 'material-ui/MenuItem';
// import Checkbox from 'material-ui/Checkbox';
import FlatButton from 'material-ui/FlatButton';
import List from 'components/List';
import ListItem from 'components/ListItem';
import Alert from 'components/Alert';
import { normalizeAgencia, normalizeConta, normalizeDigito } from 'normalizers';
import validateTransferenciaAutomatica from './validation';
import CircularProgress from 'material-ui/CircularProgress';
import { injectIntl, intlShape } from 'react-intl';

import messages from './messages';
import styles from './styles.css';

export class TransferenciaAutomaticaForm extends React.Component { // eslint-disable-line react/prefer-stateless-function
  render() {
    const { handleSubmit, submitting, loading, bancos, handleToggleHabilitar, habilitaState, message, initialValues } = this.props;
    const { formatMessage } = this.props.intl;
    const bancosList = bancos && bancos.toJS().length && bancos.toJS().map((banco) => `${banco.Nome} (${banco.Codigo})`);
    const dsBancos = bancosList !== 0 ? bancosList : [];
    const tiposConta = [];
    tiposConta.push(<MenuItem key={1} value={1} primaryText={formatMessage(messages.labelContaCorrente)} />);
    tiposConta.push(<MenuItem key={2} value={2} primaryText={formatMessage(messages.labelContaPoupanca)} />);

    const stylesToggle = {
      thumbOff: {
        backgroundColor: '#fff',
      },
      trackOff: {
        backgroundColor: '#9f9f9f',
      },
    };

    const toggleHabilita = habilitaState;
    const newUser = initialValues.toJS().Banco === null || initialValues.toJS().Agencia === null || initialValues.toJS().Conta === null;

    return (
      <div className={styles.formWrapper}>
        <form onSubmit={handleSubmit}>
          <Field component={TextField} className="iptHidden" name="HabilitaTransferenciaAutomatica" type="hidden" underlineShow={false} />
          <Field component={TextField} className="iptHidden" name="Message" type="hidden" underlineShow={false} />
          <List>
            <ListItem key={1}>
              <Field
                name="ToggleHabilita"
                component={Toggle}
                className={styles.lblToggle}
                label={formatMessage(toggleHabilita ? messages.labelToggleAtiva : messages.labelToggleInativa)}
                tabIndex="1"
                thumbStyle={stylesToggle.thumbOff}
                trackStyle={stylesToggle.trackOff}
                onClick={(event) => {
                  event.stopPropagation();
                  handleToggleHabilitar(habilitaState, newUser);
                }}
                onLoad={this.props.handleSetToggleHabilita(habilitaState, initialValues.toJS().HabilitaTransferenciaAutomatica)}
              />
            </ListItem>
            <ListItem key={2}>
              <Field name="EmpresaPagadora" className="redInput wFloatingLabel" component={TextField} floatingLabelText={formatMessage(messages.labelEmpresaPagadora)} label={formatMessage(messages.labelEmpresaPagadora)} readOnly tabIndex="2" />
            </ListItem>
            <ListItem key={3}>
              <Field name="CNPJPagador" className="redInput wFloatingLabel" component={TextField} floatingLabelText={formatMessage(messages.labelCNPJPagador)} label={formatMessage(messages.labelCNPJPagador)} readOnly tabIndex="3" />
            </ListItem>
            <ListItem key={4}>
              <Field
                name="Banco"
                className="redInput wFloatingLabel"
                component={AutoComplete}
                floatingLabelText={formatMessage(messages.labelBanco)}
                // openOnFocus
                filter={MUIAutoComplete.caseInsensitiveFilter}
                dataSource={dsBancos}
                disabled={!habilitaState}
                tabIndex="4"
              />
              <span className={`${loading ? styles.block : ''} ${styles.hide} ${styles.loaderWrapper}`}>
                <CircularProgress size={0.3} />
              </span>
            </ListItem>
            <ListItem key={5}>
              <Field name="Agencia" className="redInput wFloatingLabel" component={TextField} floatingLabelText={formatMessage(messages.labelAgencia)} label={formatMessage(messages.labelAgencia)} normalize={normalizeAgencia} readOnly={!habilitaState} tabIndex="5" />
            </ListItem>
            <ListItem key={6}>
              <Field name="Conta" className="redInput wFloatingLabel" component={TextField} floatingLabelText={formatMessage(messages.labelConta)} label={formatMessage(messages.labelConta)} normalize={normalizeConta} readOnly={!habilitaState} tabIndex="6" />
              <Field name="Digito" className="redInput wFloatingLabel" component={TextField} floatingLabelText={formatMessage(messages.labelDigito)} label={formatMessage(messages.labelDigito)} normalize={normalizeDigito} readOnly={!habilitaState} tabIndex="7" />
            </ListItem>
            <ListItem key={7}>
              <Field name="TipoConta" component={SelectField} className="redInput wFloatingLabel" floatingLabelText={formatMessage(messages.labelTipoConta)} disabled={!habilitaState} tabIndex="8">
                {tiposConta}
              </Field>
            </ListItem>
          </List>
          <FlatButton name="btnContinuar" className="redButton big centered" type="submit" label={formatMessage(messages.submitButton)} disabled={submitting} disabled={newUser && !habilitaState} tabIndex={9} />
        </form>
        <Alert type="alert" message={message} needWrapper />
      </div>);
  }
}

TransferenciaAutomaticaForm.propTypes = {
  handleSubmit: React.PropTypes.func,
  submitting: React.PropTypes.bool,
  Banco: React.PropTypes.string,
  Agencia: React.PropTypes.number,
  Conta: React.PropTypes.number,
  Digito: React.PropTypes.string,
  loading: React.PropTypes.bool,
  bancos: React.PropTypes.object,
  intl: intlShape.isRequired,
  dadosForm: React.PropTypes.object,
  handleToggleHabilitar: React.PropTypes.func,
  habilitaState: React.PropTypes.bool,
  message: React.PropTypes.string,
  handleSetToggleHabilita: React.PropTypes.func,
  initialValues: React.PropTypes.object,
};

function mapDispatchToProps(dispatch) {
  return {
    handleToggleHabilitar: (valor, newUser) => {
      dispatch(change('transferenciaAutomaticaForm', 'HabilitaTransferenciaAutomatica', !valor));
      if (!newUser && valor) {
        dispatch(change('transferenciaAutomaticaForm', 'Message', 'Ao continuar, você desativará sua transferência automática e os dados abaixo não serão salvos.'));
      } else {
        dispatch(change('transferenciaAutomaticaForm', 'Message', null));
      }
    },
    handleSetToggleHabilita: (valor, valorInicial) => {
      if (typeof (valor) === "undefined") { // eslint-disable-line
        dispatch(change('transferenciaAutomaticaForm', 'ToggleHabilita', valorInicial));
      }
    },
    dispatch,
  };
}

const selector = formValueSelector('transferenciaAutomaticaForm');

export default connect(
  state => {
    const habilitaState = selector(state, 'HabilitaTransferenciaAutomatica');
    const message = selector(state, 'Message');
    return {
      habilitaState,
      message,
    };
  }, mapDispatchToProps)(injectIntl(reduxForm({
    form: 'transferenciaAutomaticaForm',
    validate: validateTransferenciaAutomatica,
    enableReinitialize: true,
  })(TransferenciaAutomaticaForm)));
