import { defineMessages } from 'react-intl';

export default defineMessages({
  hintValor: {
    id: 'app.components.Movimentar.Enviar.ValorForm.hintValor',
    defaultMessage: 'Quanto você quer enviar?',
  },
  buttonContinuar: {
    id: 'app.components.Movimentar.Enviar.ValorForm.buttonContinuar',
    defaultMessage: 'Continuar',
  },
});
