import React from 'react';
import { reduxForm, Field } from 'redux-form/immutable';

import { TextField } from 'redux-form-material-ui';
import FlatButton from 'material-ui/FlatButton';
import validateValorForm from './validation';
import { injectIntl, intlShape } from 'react-intl';
import messages from './messages';

import List from 'components/List';
import ListItem from 'components/ListItem';
import { normalizeDecimal } from 'normalizers';

import valueIcon from 'containers/App/value-icon.png';

class ValorForm extends React.Component { // eslint-disable-line react/prefer-stateless-function
  render() {
    const { handleSubmit } = this.props;
    const { formatMessage } = this.props.intl;
    return (
      <form onSubmit={handleSubmit}>
        <List>
          <ListItem icon={valueIcon} key={3}>
            <Field
              autoFocus
              name="Valor"
              component={TextField}
              hintText={formatMessage(messages.hintValor)}
              normalize={normalizeDecimal}
              type="tel"
              tabIndex="1"
              format={normalizeDecimal}
            />
          </ListItem>
        </List>
        <FlatButton name="btnContinuar" type="submit" className="redButton big centered" label={formatMessage(messages.buttonContinuar)} tabIndex="2" />
      </form>
    );
  }
}

ValorForm.propTypes = {
  handleSubmit: React.PropTypes.func,
  Valor: React.PropTypes.number,
  intl: intlShape.isRequired,
};

export default injectIntl(reduxForm({
  form: 'valorForm',
  validate: validateValorForm,
  enableReinitialize: true,
})(ValorForm));
