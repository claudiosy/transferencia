import messages from 'containers/App/messages';

const validateValorForm = (valuesFromState, props) => {
  const { formatMessage } = props.intl;
  const errors = {};
  const values = valuesFromState.toJS();

  if (values.Valor && parseInt(values.Valor.toString().replace(/[^\d]/g, ''), 0) === 0) {
    errors.Valor = formatMessage(messages.invalidValor);
  }

  if (!values.Valor) {
    errors.Valor = formatMessage(messages.mandatoryField);
  }

  return errors;
};

export default validateValorForm;
