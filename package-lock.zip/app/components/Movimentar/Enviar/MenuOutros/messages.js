import { defineMessages } from 'react-intl';

export default defineMessages({
  cpf: {
    id: 'app.components.Movimentar.Enviar.MenuOutros.cpf',
    defaultMessage: 'POR CPF',
  },
  email: {
    id: 'app.components.Movimentar.Enviar.MenuOutros.email',
    defaultMessage: 'POR E-MAIL',
  },
  telefone: {
    id: 'app.components.Movimentar.Enviar.MenuOutros.telefone',
    defaultMessage: 'TELEFONE',
  },
  outrosBancos: {
    id: 'app.components.Movimentar.Enviar.MenuOutros.outrosBancos',
    defaultMessage: 'OUTROS BANCOS',
  },
});
