import React from 'react';
import { reduxForm } from 'redux-form/immutable';
import List from 'components/List';
import ListItem from 'components/ListItem';

import styles from './styles.css';
import { FormattedMessage } from 'react-intl';
import messages from './messages';

const MenuOutros = props => { // eslint-disable-line react/prefer-stateless-function
  const { handleStepMenuChange, columnSelection, columnOrder } = props;

  return (
    <div className={styles.formWrapper}>
      <List showProceedIcon showHoverEffect behind={columnSelection !== 0} activeItem={columnSelection}>
        <ListItem name="enviarCPF" key={3} onClick={() => handleStepMenuChange(columnOrder, 3)}>
          <FormattedMessage {...messages.cpf} />
        </ListItem>
        <ListItem name="enviarEmail" key={4} onClick={() => handleStepMenuChange(columnOrder, 4)}>
          <FormattedMessage {...messages.email} />
        </ListItem>
        <ListItem name="enviarTelefone" key={5} onClick={() => handleStepMenuChange(columnOrder, 5)}>
          <FormattedMessage {...messages.telefone} />
        </ListItem>
        <ListItem name="enviarOutrosBancos" key={6} onClick={() => handleStepMenuChange(columnOrder, 6)}>
          <FormattedMessage {...messages.outrosBancos} />
        </ListItem>
      </List>
    </div>);
};

MenuOutros.propTypes = {
  handleStepMenuChange: React.PropTypes.func,
  columnSelection: React.PropTypes.number,
  columnOrder: React.PropTypes.number,
};

export default reduxForm({
  form: 'menuOutrosForm',
})(MenuOutros);
