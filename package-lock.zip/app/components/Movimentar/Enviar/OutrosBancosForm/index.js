import React from 'react';
import { reduxForm, Field, change, formValueSelector } from 'redux-form/immutable';
import { connect } from 'react-redux';
import { TextField, AutoComplete, SelectField } from 'redux-form-material-ui';
import { AutoComplete as MUIAutoComplete } from 'material-ui';
import MenuItem from 'material-ui/MenuItem';
// import Checkbox from 'material-ui/Checkbox';
import FlatButton from 'material-ui/FlatButton';
import List from 'components/List';
import ListItem from 'components/ListItem';
import AddToFavorites from 'components/AddToFavorites';
import { normalizeCPF, normalizeCNPJ, normalizeAgencia, normalizeConta, normalizeDigito, normalizeNome } from 'normalizers';
import validateOutrosBancos from './validation';
import CircularProgress from 'material-ui/CircularProgress';
import { injectIntl, intlShape } from 'react-intl';

import messages from './messages';
import styles from './styles.css';

export class OutrosBancosForm extends React.Component { // eslint-disable-line react/prefer-stateless-function
  /* componentWillReceiveProps() {
    if ((this.props.dadosForm && this.props.dadosForm.toJS().Banco)
      && this.props.dadosForm.toJS().Banco.indexOf('(341)') >= 0
      && this.props.dadosForm.toJS().TipoConta === 2) {
      this.props.handleCleanTipoConta();
    }
  } */
  render() {
    const { handleSubmit, handleKeyUp, submitting, valorCPF, valorCNPJ, /* dadosForm ,*/ loading, bancos, favoritoState, handleSetFavoritoState } = this.props;
    const { formatMessage } = this.props.intl;
    // const hidePoupanca = (dadosForm && dadosForm.toJS().Banco) && dadosForm.toJS().Banco.indexOf('(341)') >= 0;
    const bancosList = bancos && bancos.toJS().length && bancos.toJS().map((banco) => `${banco.Nome} (${banco.Codigo})`);
    const dsBancos = bancosList !== 0 ? bancosList : [];
    const tiposConta = [];
    tiposConta.push(<MenuItem key={1} value={1} primaryText={formatMessage(messages.labelContaCorrente)} />);
    tiposConta.push(<MenuItem key={2} value={2} primaryText={formatMessage(messages.labelContaPoupanca)} />);
    // if (!hidePoupanca) tiposConta.push(<MenuItem key={2} value={2} primaryText={formatMessage(messages.labelContaPoupanca)} />);

    return (
      <div className={styles.formWrapper}>
        <form onSubmit={handleSubmit}>
          <Field component={TextField} className="iptHidden" name="Favorito" type="hidden" underlineShow={false} />
          <List>
            <ListItem key={1}>
              <Field autoFocus name="Destinatario" className={`${styles.capitalize} redInput wFloatingLabel`} component={TextField} floatingLabelText={formatMessage(messages.labelDestinatario)} label={formatMessage(messages.labelDestinatario)} normalize={normalizeNome} tabIndex="1" />
            </ListItem>
            <ListItem key={2}>
              <Field name="CPF" className="redInput wFloatingLabel" component={TextField} floatingLabelText={formatMessage(messages.labelCPF)} label={formatMessage(messages.labelCPF)} type="tel" onKeyUp={(event) => handleKeyUp('CPF', event.target.value)} normalize={normalizeCPF} tabIndex="2" disabled={valorCNPJ} />
            </ListItem>
            <ListItem key={3}>
              <Field name="CNPJ" className="redInput wFloatingLabel" component={TextField} floatingLabelText={formatMessage(messages.labelCNPJ)} label={formatMessage(messages.labelCNPJ)} type="tel" onKeyUp={(event) => handleKeyUp('CNPJ', event.target.value)} normalize={normalizeCNPJ} tabIndex="3" disabled={valorCPF} />
            </ListItem>
            <ListItem key={4}>
              <Field
                name="Banco"
                className="redInput wFloatingLabel"
                component={AutoComplete}
                floatingLabelText={formatMessage(messages.labelBanco)}
                // openOnFocus
                filter={MUIAutoComplete.caseInsensitiveFilter}
                dataSource={dsBancos}
                tabIndex="4"
              />
              <span className={`${loading ? styles.block : ''} ${styles.hide} ${styles.loaderWrapper}`}>
                <CircularProgress size={0.3} />
              </span>
            </ListItem>
            <ListItem key={5}>
              <Field name="Agencia" className="redInput wFloatingLabel" component={TextField} floatingLabelText={formatMessage(messages.labelAgencia)} label={formatMessage(messages.labelAgencia)} normalize={normalizeAgencia} tabIndex="5" />
            </ListItem>
            <ListItem key={6}>
              <Field name="Conta" className="redInput wFloatingLabel" component={TextField} floatingLabelText={formatMessage(messages.labelConta)} label={formatMessage(messages.labelConta)} normalize={normalizeConta} tabIndex="6" />
              <Field name="Digito" className="redInput wFloatingLabel" component={TextField} floatingLabelText={formatMessage(messages.labelDigito)} label={formatMessage(messages.labelDigito)} normalize={normalizeDigito} tabIndex="7" />
            </ListItem>
            <ListItem key={7}>
              <Field name="TipoConta" component={SelectField} className="redInput wFloatingLabel" floatingLabelText={formatMessage(messages.labelTipoConta)} tabIndex="4">
                {tiposConta}
              </Field>
            </ListItem>
          </List>
          <AddToFavorites state={favoritoState} onToggle={() => handleSetFavoritoState(favoritoState)} />
          <FlatButton name="btnContinuar" className="redButton big centered" type="submit" label={formatMessage(messages.submitButton)} disabled={submitting} tabIndex="8" />
        </form>
      </div>);
  }
}

OutrosBancosForm.propTypes = {
  handleSubmit: React.PropTypes.func,
  handleKeyUp: React.PropTypes.func,
  submitting: React.PropTypes.bool,
  Destinatario: React.PropTypes.string,
  CPF: React.PropTypes.string,
  CNPJ: React.PropTypes.string,
  Banco: React.PropTypes.string,
  Agencia: React.PropTypes.number,
  Conta: React.PropTypes.number,
  Digito: React.PropTypes.string,
  valorCPF: React.PropTypes.string,
  valorCNPJ: React.PropTypes.string,
  loading: React.PropTypes.bool,
  bancos: React.PropTypes.object,
  intl: intlShape.isRequired,
  favoritoState: React.PropTypes.bool,
  handleSetFavoritoState: React.PropTypes.func,
  handleCleanTipoConta: React.PropTypes.func,
  dadosForm: React.PropTypes.object,
};

function mapDispatchToProps(dispatch) {
  return {
    handleKeyUp: (tipo, valor) => {
      if (tipo === 'CPF' && valor.length > 0) {
        dispatch(change('outrosBancosForm', 'CPF', valor));
      } else if (tipo === 'CNPJ' && valor.length > 0) {
        dispatch(change('outrosBancosForm', 'CNPJ', valor));
      }
    },
    handleSetFavoritoState: (valor) => {
      dispatch(change('outrosBancosForm', 'Favorito', !valor));
    },
    /* handleCleanTipoConta: () => {
      dispatch(change('outrosBancosForm', 'TipoConta', null));
    }, */
    dispatch,
  };
}

const selector = formValueSelector('outrosBancosForm');
export default connect(
  state => {
    const valorCPF = selector(state, 'CPF');
    const valorCNPJ = selector(state, 'CNPJ');
    const favoritoState = selector(state, 'Favorito');
    return {
      valorCPF,
      valorCNPJ,
      favoritoState,
    };
  }, mapDispatchToProps)(injectIntl(reduxForm({
    form: 'outrosBancosForm',
    validate: validateOutrosBancos,
    enableReinitialize: true,
  })(OutrosBancosForm)));
