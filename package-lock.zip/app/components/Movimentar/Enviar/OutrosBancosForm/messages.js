import { defineMessages } from 'react-intl';

export default defineMessages({
  header: {
    id: 'app.components.Movimentar.Enviar.OutrosBancosForm.header',
    defaultMessage: 'Outros Bancos',
  },
  labelDestinatario: {
    id: 'app.components.Movimentar.Enviar.OutrosBancosForm.labelDestinatario',
    defaultMessage: 'Destinatário',
  },
  labelCPF: {
    id: 'app.components.Movimentar.Enviar.OutrosBancosForm.labelCPF',
    defaultMessage: 'CPF do destinatário',
  },
  labelCNPJ: {
    id: 'app.components.Movimentar.Enviar.OutrosBancosForm.labelCNPJ',
    defaultMessage: 'CNPJ do destinatário',
  },
  labelBanco: {
    id: 'app.components.Movimentar.Enviar.OutrosBancosForm.labelBanco',
    defaultMessage: 'Banco',
  },
  labelAgencia: {
    id: 'app.components.Movimentar.Enviar.OutrosBancosForm.labelAgencia',
    defaultMessage: 'Agência',
  },
  labelConta: {
    id: 'app.components.Movimentar.Enviar.OutrosBancosForm.labelConta',
    defaultMessage: 'Conta',
  },
  labelDigito: {
    id: 'app.components.Movimentar.Enviar.OutrosBancosForm.labelDigito',
    defaultMessage: 'Dígito',
  },
  labelTipoConta: {
    id: 'app.components.Movimentar.Enviar.OutrosBancosForm.labelTipoConta',
    defaultMessage: 'Tipo de Conta',
  },
  labelContaCorrente: {
    id: 'app.components.Movimentar.Enviar.OutrosBancosForm.labelContaCorrente',
    defaultMessage: 'Corrente',
  },
  labelContaPoupanca: {
    id: 'app.components.Movimentar.Enviar.OutrosBancosForm.labelContaPoupanca',
    defaultMessage: 'Poupança',
  },
  submitButton: {
    id: 'app.components.Movimentar.Enviar.OutrosBancosForm.submitButton',
    defaultMessage: 'Continuar',
  },
});
