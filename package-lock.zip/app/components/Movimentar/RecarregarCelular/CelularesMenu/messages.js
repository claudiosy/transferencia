import { defineMessages } from 'react-intl';

export default defineMessages({
  addCel: {
    id: 'app.components.Movimentar.Enviar.RecarregarCelular.CelularesMenu.addCel',
    defaultMessage: 'CADASTRAR NOVO CELULAR',
  },
  informative: {
    id: 'app.components.Movimentar.Enviar.RecarregarCelular.CelularesMenu.informative',
    defaultMessage: 'FUJA DAS FILAS! RECARREGUE SEU CELULAR PRÉ-PAGO EM ALGUNS CLIQUES.',
  },
  loadingCel: {
    id: 'app.components.Movimentar.Enviar.RecarregarCelular.CelularesMenu.loadingCel',
    defaultMessage: 'Carregando os seus favoritos...',
  },
});
