import React from 'react';

import List from 'components/List';
import ListItem from 'components/ListItem';
import CircularProgress from 'material-ui/CircularProgress';
import { FormattedMessage } from 'react-intl';
import messages from './messages';
import styles from './styles.css';
import iconInfo from 'containers/App/icon-info.png';

const colors =
  ['#1FCB4A',
    '#01FCEF',
    '#892EE4',
    '#06DCFB',
    '#B6BA18',
    '#03EBA6',
    '#3923D6',
    '#48FB0D',
    '#2DC800',
    '#9A03FE',
    '#23819C',
    '#2966B8',
    '#5757FF',
    '#9D9D00',
    '#FF68DD',
    '#59955C',
    '#FF4848',
    '#872187',
    '#59DF00',
    '#62A9FF',
    '#FE67EB',
    '#9669FE',
    '#800080',
    '#FF62B0',
    '#E469FE',
    '#D568FD',
    '#62D0FF'];

function CelularesMenu(props) {
  const { columnSelection, columnOrder, handleStepChange, handleItemClick, loading, celulares } = props;
  let counter = 0;

  let celPhonesList = celulares && celulares.toJS().map((cel, key) => {
    counter++;
    const num = cel.Celular.toString().length === 9 ? 5 : 4;
    const iniciais = cel.Nome.split(' ').length === 1 ? cel.Nome.split(' ')[0].substring(0, 1) : cel.Nome.split(' ')[0].substring(0, 1) + cel.Nome.split(' ')[1].substring(0, 1);
    let avatar = null;

    if (cel.Avatar) {
      avatar = (<span className={styles.iconName}><img src={cel.Avatar} role="presentation" /></span>);
    } else {
      avatar = (<span className={styles.iconName} style={{ 'background-color': colors[key] }}><div className={styles.divIniciais}>{iniciais}</div></span>);
    }

    return (
      <ListItem name={cel.ID} key={counter} onClick={() => { handleItemClick(cel); handleStepChange(columnOrder, cel.ID); }}>
        {avatar}
        {cel.Nome}&nbsp;&nbsp;
        <span className={styles.small}>
          {`(${cel.Ddd}) ${cel.Celular.toString().substring(0, num)}-${cel.Celular.toString().substring(num, num + 4)}`}
        </span>
      </ListItem>
    );
  });

  if (loading) {
    celPhonesList = (
      <ListItem key={-3} showProceedIcon={false}>
        <span className={styles.loaderWrapper}>
          <CircularProgress size={0.3} />
        </span>
        <FormattedMessage {...messages.loadingCel} />
      </ListItem>
    );
  }

  return (
    // eslint-disable-next-line react/jsx-boolean-value
    <List showProceedIcon={true} showHoverEffect={true} behind={columnSelection !== 0} activeItem={columnSelection}>
      <ListItem name="addCel" key={-1} onClick={() => handleStepChange(columnOrder, -1)}>
        <FormattedMessage {...messages.addCel} />
      </ListItem>
      {celPhonesList}
      <ListItem key={-2} informative sticky icon={iconInfo} showProceedIcon={false} notButton autoHeight>
        <FormattedMessage {...messages.informative} />
      </ListItem>
    </List>
  );
}

CelularesMenu.propTypes = {
  loading: React.PropTypes.bool,
  celulares: React.PropTypes.object,
  columnSelection: React.PropTypes.number,
  columnOrder: React.PropTypes.number,
  handleStepChange: React.PropTypes.func,
  handleItemClick: React.PropTypes.func,
};

export default CelularesMenu;
