import React from 'react';

import { reduxForm, Field } from 'redux-form/immutable';

import { TextField } from 'redux-form-material-ui';
import FlatButton from 'material-ui/FlatButton';
import { injectIntl, intlShape } from 'react-intl';
// import messages from './messages';

import List from 'components/List';
import ListItem from 'components/ListItem';

const AdicionarCelularForm = props => {
  const { handleSubmit, pristine, submitting } = props;
  // const { formatMessage } = props.intl;

  return (
    <form onSubmit={handleSubmit}>
      <List>
        <ListItem key={1}>
          <Field name="numeroCelular" component={TextField} className="redInput rightAligned" readOnly tabIndex="1" />
        </ListItem>
        <ListItem key={2}>
          <Field name="operadora" component={TextField} className="redInput" readOnly tabIndex="2" />
        </ListItem>
        <ListItem key={3}>
          <Field name="valor" component={TextField} className="redInput" readOnly tabIndex="3" />
        </ListItem>
      </List>
      <FlatButton type="submit" className="redButton big centered" label="Confirmar" disabled={pristine || submitting} tabIndex="4" />
    </form>
  );
};

AdicionarCelularForm.propTypes = {
  pristine: React.PropTypes.bool,
  submitting: React.PropTypes.bool,
  handleSubmit: React.PropTypes.func,
  nome: React.PropTypes.string,
  ddd: React.PropTypes.string,
  numero: React.PropTypes.string,
  operadora: React.PropTypes.number,
  intl: intlShape.isRequired,
};

export default injectIntl(reduxForm({
  form: 'adicionarCelularForm',
  // validate: validateAdicionarCelularForm,
})(AdicionarCelularForm));
