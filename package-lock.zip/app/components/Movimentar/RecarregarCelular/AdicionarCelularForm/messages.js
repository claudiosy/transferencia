import { defineMessages } from 'react-intl';

export default defineMessages({
  hintNome: {
    id: 'app.components.Movimentar.Enviar.RecarregarCelular.AdicionarCelularForm.hintNome',
    defaultMessage: 'Título',
  },
  hintDdd: {
    id: 'app.components.Movimentar.Enviar.RecarregarCelular.AdicionarCelularForm.hintDdd',
    defaultMessage: 'DDD',
  },
  hintNumero: {
    id: 'app.components.Movimentar.Enviar.RecarregarCelular.AdicionarCelularForm.hintNumero',
    defaultMessage: 'Número',
  },
  hintOperadora: {
    id: 'app.components.Movimentar.Enviar.RecarregarCelular.AdicionarCelularForm.hintOperadora',
    defaultMessage: 'Operadora',
  },
  buttonContinuar: {
    id: 'app.components.Movimentar.Enviar.RecarregarCelular.AdicionarCelularForm.buttonContinuar',
    defaultMessage: 'Continuar',
  },
});
