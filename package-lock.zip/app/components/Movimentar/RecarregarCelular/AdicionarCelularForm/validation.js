import messages from 'containers/App/messages';

const validateAdicionarCelularForm = (valuesFromState, props) => {
  const { formatMessage } = props.intl;
  const errors = {};
  const values = valuesFromState.toJS();

  if (!values.nome) {
    errors.nome = formatMessage(messages.mandatoryField);
  }
  if (!values.ddd || values.ddd.length < 2) {
    errors.ddd = formatMessage(messages.mandatoryField);
  }
  if (!values.celular) {
    errors.celular = formatMessage(messages.mandatoryField);
  }
  if (!values.operadoraid) {
    errors.operadoraid = formatMessage(messages.mandatoryField);
  }

  return errors;
};

export default validateAdicionarCelularForm;
