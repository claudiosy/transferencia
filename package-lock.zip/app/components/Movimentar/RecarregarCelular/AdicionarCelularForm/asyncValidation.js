import { loadOperadorasByDDD } from 'containers/Movimentar/RecarregarCelularPage/actions';

const asyncValidateDDD = (values, dispatch) => {
  const data = values.toJS();
  return new Promise((resolve, reject) => {
    dispatch(loadOperadorasByDDD(data, resolve, reject, 'Ddd', (value) => { // eslint-disable-line arrow-body-style
      return value.Sucesso;
    }));
  }).then(() => { // eslint-disable-line arrow-body-style
    return true;
  });
};

export default asyncValidateDDD;
