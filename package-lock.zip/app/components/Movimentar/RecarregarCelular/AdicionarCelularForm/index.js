import React from 'react';

import { reduxForm, Field } from 'redux-form/immutable';

import { TextField, SelectField } from 'redux-form-material-ui';
import FlatButton from 'material-ui/FlatButton';
import MenuItem from 'material-ui/MenuItem';
import validateAdicionarCelularForm from './validation';
import asyncValidateDDD from './asyncValidation';
import { injectIntl, intlShape } from 'react-intl';
import messages from './messages';

import { normalizeCelularSemDDD, normalizeDDD } from 'normalizers';

import List from 'components/List';
import ListItem from 'components/ListItem';

const AdicionarCelularForm = props => {
  const { handleSubmit, pristine, submitting, operadoras } = props;
  const { formatMessage } = props.intl;

  const operadorasList = operadoras && operadoras.toJS().map((operadora, key) => { // eslint-disable-line arrow-body-style
    return (<MenuItem key={key} value={operadora.OperadoraCelularId} primaryText={operadora.NomeOperadora} />);
  });

  return (
    <form onSubmit={handleSubmit}>
      <List>
        <ListItem key={1}>
          <Field autoFocus name="Nome" component={TextField} className="redInput wFloatingLabel" floatingLabelText={formatMessage(messages.hintNome)} tabIndex="1" />
        </ListItem>
        <ListItem key={2}>
          <Field name="Ddd" component={TextField} className="redInput wFloatingLabel" floatingLabelText={formatMessage(messages.hintDdd)} normalize={normalizeDDD} type="tel" tabIndex="2" />
        </ListItem>
        <ListItem key={3}>
          <Field name="Celular" component={TextField} className="redInput wFloatingLabel" floatingLabelText={formatMessage(messages.hintNumero)} normalize={normalizeCelularSemDDD} type="tel" tabIndex="3" />
        </ListItem>
        <ListItem key={4}>
          <Field name="OperadoraId" component={SelectField} className="redInput wFloatingLabel" floatingLabelText={formatMessage(messages.hintOperadora)} tabIndex="4">
            {operadorasList}
          </Field>
        </ListItem>
      </List>
      <FlatButton name="btnContinuar" type="submit" className="redButton big centered" label={formatMessage(messages.buttonContinuar)} disabled={pristine || submitting} tabIndex={5} />
    </form>
  );
};

AdicionarCelularForm.propTypes = {
  pristine: React.PropTypes.bool,
  submitting: React.PropTypes.bool,
  handleSubmit: React.PropTypes.func,
  nome: React.PropTypes.string,
  ddd: React.PropTypes.string,
  celular: React.PropTypes.string,
  operadoraid: React.PropTypes.number,
  operadoras: React.PropTypes.object,
  columnOrder: React.PropTypes.number,
  intl: intlShape.isRequired,
};

export default injectIntl(reduxForm({
  form: 'adicionarCelularForm',
  validate: validateAdicionarCelularForm,
  asyncValidate: asyncValidateDDD,
  asyncBlurFields: ['Ddd'],
})(AdicionarCelularForm));
