import { defineMessages } from 'react-intl';

export default defineMessages({
  numeroCelular: {
    id: 'app.components.Movimentar.Enviar.RecarregarCelular.ValorConfirmacao.numeroCelular',
    defaultMessage: 'Número',
  },
  operadora: {
    id: 'app.components.Movimentar.Enviar.RecarregarCelular.ValorConfirmacao.operadora',
    defaultMessage: 'Operadora',
  },
  titulo: {
    id: 'app.components.Movimentar.Enviar.RecarregarCelular.ValorConfirmacao.titulo',
    defaultMessage: 'Título',
  },
  editar: {
    id: 'app.components.Movimentar.Enviar.RecarregarCelular.ValorConfirmacao.editar',
    defaultMessage: 'Editar',
  },
  excluir: {
    id: 'app.components.Movimentar.Enviar.RecarregarCelular.ValorConfirmacao.excluir',
    defaultMessage: 'Excluir',
  },
  buttonRecarregar: {
    id: 'app.components.Movimentar.Enviar.RecarregarCelular.ValorConfirmacao.buttonRecarregar',
    defaultMessage: 'Recarregar',
  },
});
