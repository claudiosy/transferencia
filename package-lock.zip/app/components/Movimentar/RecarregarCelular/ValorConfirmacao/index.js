import React from 'react';

import FlatButton from 'material-ui/FlatButton';
import { FormattedMessage, injectIntl, intlShape } from 'react-intl';
import messages from './messages';

import List from 'components/List';
import ListItem from 'components/ListItem';

import personIcon from 'containers/App/person-icon.png';
import mobileIcon from 'containers/Movimentar/RecarregarCelularPage/mobile-icon.png';
import simIcon from 'containers/Movimentar/RecarregarCelularPage/sim-icon.png';
import editIcon from 'containers/App/icon-editar.png';
import removeIcon from 'containers/App/icon-excluir.png';

const ValorConfirmacao = props => {
  const { onConfirm, onUpdate, onDelete, confirmData, columnOrder, columnSelection } = props;
  const { Nome, Operadora, Ddd, Celular } = confirmData;
  const num = Celular.toString().length === 9 ? 5 : 4;
  const { formatMessage } = props.intl;

  return (
    <form>
      <List>
        <ListItem key={1} icon={mobileIcon} notButton>
          <FormattedMessage {...messages.numeroCelular} />
          <span className="align-right text-gray">{`(${Ddd}) ${Celular.toString().substring(0, num)}-${Celular.toString().substring(num, num + 4)}`}</span>
        </ListItem>
        <ListItem key={2} icon={personIcon} notButton>
          <FormattedMessage {...messages.titulo} />
          <span className="align-right text-gray">{Nome}</span>
        </ListItem>
        <ListItem key={3} icon={simIcon} notButton>
          <FormattedMessage {...messages.operadora} />
          <span className="align-right text-gray">{Operadora}</span>
        </ListItem>
        <ListItem name="editCel" key={4} onClick={() => onUpdate(Ddd)}>
          <FormattedMessage {...messages.editar} />
          <span className="align-right">
            <img src={editIcon} role="presentation" />
          </span>
        </ListItem>
        <ListItem name="deleteCel" key={5} onClick={onDelete}>
          <FormattedMessage {...messages.excluir} />
          <span className="align-right">
            <img src={removeIcon} role="presentation" />
          </span>
        </ListItem>
      </List>

      <FlatButton name="btnRecarregar" onMouseUp={() => onConfirm(columnOrder, columnSelection, Operadora)} className="redButton big centered" label={formatMessage(messages.buttonRecarregar)} tabIndex="1" />
    </form>
  );
};

ValorConfirmacao.propTypes = {
  onConfirm: React.PropTypes.func,
  onUpdate: React.PropTypes.func,
  onDelete: React.PropTypes.func,
  confirmData: React.PropTypes.object,
  columnOrder: React.PropTypes.number,
  columnSelection: React.PropTypes.number,
  intl: intlShape.isRequired,
};

export default injectIntl(ValorConfirmacao);
