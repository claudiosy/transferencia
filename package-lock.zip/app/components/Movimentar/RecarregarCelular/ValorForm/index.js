import React from 'react';

import { reduxForm, Field } from 'redux-form/immutable';

import { SelectField } from 'redux-form-material-ui';
import MenuItem from 'material-ui/MenuItem';
import FlatButton from 'material-ui/FlatButton';
import validateValorForm from './validation';
import { injectIntl, intlShape } from 'react-intl';
import messages from './messages';

import List from 'components/List';
import ListItem from 'components/ListItem';

import valueIcon from 'containers/App/value-icon.png';

const ValorForm = props => {
  const { handleSubmit, pristine, submitting, produtos } = props;
  const { formatMessage, formatNumber } = props.intl;

  const produtosList = produtos && produtos.toJS().map((produto, key) => { // eslint-disable-line arrow-body-style
    return (<MenuItem key={key} value={produto.OperadoraCelularProdutoId} primaryText={formatNumber(produto.PrecoVenda, { style: 'currency', currency: 'BRL' })} />);
  });

  return (
    <form onSubmit={handleSubmit}>
      <List>
        <ListItem icon={valueIcon} key={1}>
          <Field name="valorId" component={SelectField} className="redInput" hintText={formatMessage(messages.hintValor)} tabIndex="1">
            {produtosList}
          </Field>
        </ListItem>
      </List>
      <FlatButton name="btnContinuar" type="submit" className="redButton big centered" label={formatMessage(messages.buttonContinuar)} disabled={pristine || submitting} tabIndex="2" />
    </form>
  );
};

ValorForm.propTypes = {
  pristine: React.PropTypes.bool,
  submitting: React.PropTypes.bool,
  handleSubmit: React.PropTypes.func,
  produtos: React.PropTypes.object,
  valor: React.PropTypes.number,
  intl: intlShape.isRequired,
};

export default injectIntl(reduxForm({
  form: 'valorForm',
  validate: validateValorForm,
})(ValorForm));
