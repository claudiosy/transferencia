import { defineMessages } from 'react-intl';

export default defineMessages({
  hintValor: {
    id: 'app.components.Movimentar.Enviar.RecarregarCelular.ValorForm.hintValor',
    defaultMessage: 'Escolha o valor',
  },
  buttonContinuar: {
    id: 'app.components.Movimentar.Enviar.RecarregarCelular.ValorForm.buttonContinuar',
    defaultMessage: 'Continuar',
  },
});
