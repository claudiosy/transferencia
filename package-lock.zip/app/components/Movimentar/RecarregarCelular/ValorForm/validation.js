import messages from 'containers/App/messages';

const validateValorForm = (valuesFromState, props) => {
  const { formatMessage } = props.intl;
  const errors = {};
  const values = valuesFromState.toJS();
  if (!values.valor) {
    errors.valor = formatMessage(messages.mandatoryField);
  }

  return errors;
};

export default validateValorForm;
