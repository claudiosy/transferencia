import { defineMessages } from 'react-intl';

export default defineMessages({
  hintTitulo: {
    id: 'app.components.Movimentar.Enviar.RecarregarCelular.EditarCelularForm.hintTitulo',
    defaultMessage: 'Título',
  },
  hintDdd: {
    id: 'app.components.Movimentar.Enviar.RecarregarCelular.EditarCelularForm.hintDdd',
    defaultMessage: 'DDD',
  },
  hintNumero: {
    id: 'app.components.Movimentar.Enviar.RecarregarCelular.EditarCelularForm.hintNumero',
    defaultMessage: 'Número',
  },
  hintOperadora: {
    id: 'app.components.Movimentar.Enviar.RecarregarCelular.EditarCelularForm.hintOperadora',
    defaultMessage: 'Operadora',
  },
  buttonUpdate: {
    id: 'app.components.Movimentar.Enviar.RecarregarCelular.EditarCelularForm.buttonUpdate',
    defaultMessage: 'Atualizar',
  },
});
