import React from 'react';

import { reduxForm, Field } from 'redux-form/immutable';

import FlatButton from 'material-ui/FlatButton';
import MenuItem from 'material-ui/MenuItem';
import { TextField, SelectField } from 'redux-form-material-ui';
import { injectIntl, intlShape } from 'react-intl';
import messages from './messages';

import List from 'components/List';
import ListItem from 'components/ListItem';

import validateAdicionarCelularForm from 'components/Movimentar/RecarregarCelular/AdicionarCelularForm/validation';
import asyncValidateDDD from 'components/Movimentar/RecarregarCelular/AdicionarCelularForm/asyncValidation';

import { normalizeCelularSemDDD, normalizeDDD } from 'normalizers';

import personIcon from 'containers/App/person-icon.png';
import mobileIcon from 'containers/Movimentar/RecarregarCelularPage/mobile-icon.png';
import simIcon from 'containers/Movimentar/RecarregarCelularPage/sim-icon.png';

export class EditarCelularForm extends React.Component { // eslint-disable-line react/prefer-stateless-function
  render() {
    const { handleSubmit, pristine, submitting, operadoras } = this.props;
    const { formatMessage } = this.props.intl;

    const operadorasList = operadoras && operadoras.toJS().map((operadora, key) => { // eslint-disable-line arrow-body-style
      return (<MenuItem key={key} value={operadora.NomeOperadora} primaryText={operadora.NomeOperadora} />);
    });

    return (
      <form onSubmit={handleSubmit}>
        <List>
          <ListItem key={1} icon={personIcon}>
            <Field autoFocus name="Nome" component={TextField} className="redInput wFloatingLabel" floatingLabelText={formatMessage(messages.hintTitulo)} tabIndex="1" />
          </ListItem>
          <ListItem key={2} icon={mobileIcon}>
            <Field name="Ddd" component={TextField} className="redInput wFloatingLabel" floatingLabelText={formatMessage(messages.hintDdd)} normalize={normalizeDDD} type="tel" format={normalizeDDD} tabIndex="2" />
          </ListItem>
          <ListItem key={3}>
            <Field name="Celular" component={TextField} className="redInput wFloatingLabel" floatingLabelText={formatMessage(messages.hintNumero)} normalize={normalizeCelularSemDDD} type="tel" format={normalizeCelularSemDDD} tabIndex="3" />
          </ListItem>
          <ListItem key={4} icon={simIcon}>
            <Field name="Operadora" component={SelectField} className="redInput wFloatingLabel" floatingLabelText={formatMessage(messages.hintOperadora)} tabIndex="4">
              {operadorasList}
            </Field>
          </ListItem>
        </List>

        <FlatButton name="btnAtualizar" type="submit" className="redButton big centered" label={formatMessage(messages.buttonUpdate)} disabled={pristine || submitting} tabIndex="5" />
      </form>
    );
  }
}

EditarCelularForm.propTypes = {
  initialValues: React.PropTypes.object,
  pristine: React.PropTypes.bool,
  submitting: React.PropTypes.bool,
  handleSubmit: React.PropTypes.func,
  nome: React.PropTypes.string,
  ddd: React.PropTypes.string,
  celular: React.PropTypes.string,
  operadoraid: React.PropTypes.number,
  operadoras: React.PropTypes.object,
  columnOrder: React.PropTypes.number,
  intl: intlShape.isRequired,
};

export default injectIntl(reduxForm({
  form: 'editarCelularForm',
  enableReinitialize: true,
  validate: validateAdicionarCelularForm,
  asyncValidate: asyncValidateDDD,
  asyncBlurFields: ['Ddd'],
})(EditarCelularForm));
