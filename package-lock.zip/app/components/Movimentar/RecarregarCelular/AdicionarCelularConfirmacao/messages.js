import { defineMessages } from 'react-intl';

export default defineMessages({
  titulo: {
    id: 'app.components.Movimentar.Enviar.RecarregarCelular.AdicionarCelularConfirmacao.nome',
    defaultMessage: 'Título',
  },
  numero: {
    id: 'app.components.Movimentar.Enviar.RecarregarCelular.AdicionarCelularConfirmacao.numero',
    defaultMessage: 'Número',
  },
  operadora: {
    id: 'app.components.Movimentar.Enviar.RecarregarCelular.AdicionarCelularConfirmacao.operadora',
    defaultMessage: 'Operadora',
  },
  buttonAdicionar: {
    id: 'app.components.Movimentar.Enviar.RecarregarCelular.AdicionarCelularForm.buttonAdicionar',
    defaultMessage: 'Cadastrar',
  },
});
