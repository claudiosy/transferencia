import React from 'react';

import FlatButton from 'material-ui/FlatButton';
import { FormattedMessage, injectIntl, intlShape } from 'react-intl';
import messages from './messages';

import List from 'components/List';
import ListItem from 'components/ListItem';
// import AddToFavorites from 'components/AddToFavorites';

import personIcon from 'containers/App/person-icon.png';
import mobileIcon from 'containers/Movimentar/RecarregarCelularPage/mobile-icon.png';
import simIcon from 'containers/Movimentar/RecarregarCelularPage/sim-icon.png';

const AdicionarCelularConfirmacao = props => {
  const { onConfirm, confirmData, operadoras /* onToggleFavorite*/ } = props;
  const { Nome, Ddd, Celular, OperadoraId /* favorito*/ } = confirmData.toJS();
  const { formatMessage } = props.intl;

  const operadoraName = operadoras.toJS().filter((op) => { // eslint-disable-line arrow-body-style
    return op.OperadoraCelularId === OperadoraId;
  })[0].NomeOperadora;

  return (
    <form>
      <h4 className="list-title">Confirme os dados:</h4>
      <List>
        <ListItem key={1} icon={personIcon}>
          <FormattedMessage {...messages.titulo} />
          <span className="align-right text-gray">{Nome}</span>
        </ListItem>
        <ListItem key={2} icon={mobileIcon}>
          <FormattedMessage {...messages.numero} />
          <span className="align-right text-gray">{`(${Ddd}) ${Celular}`}</span>
        </ListItem>
        <ListItem key={3} icon={simIcon}>
          <FormattedMessage {...messages.operadora} />
          <span className="align-right text-gray">{operadoraName}</span>
        </ListItem>
      </List>

      <FlatButton name="btnCadastrar" onMouseUp={onConfirm} className="redButton big centered" label={formatMessage(messages.buttonAdicionar)} tabIndex="2" />
    </form>
  );
};

AdicionarCelularConfirmacao.propTypes = {
  onConfirm: React.PropTypes.func,
  onToggleFavorite: React.PropTypes.func,
  confirmData: React.PropTypes.object,
  operadoras: React.PropTypes.object,
  intl: intlShape.isRequired,
};

export default injectIntl(AdicionarCelularConfirmacao);
