import { defineMessages } from 'react-intl';

export default defineMessages({
  header: {
    id: 'app.components.Movimentar.Enviar.RecarregarBilhete.ComprovanteBilhete.header',
    defaultMessage: 'Comprovante',
  },
  ButtonSave: {
    id: 'app.components.Movimentar.Enviar.RecarregarBilhete.ComprovanteBilhete.ButtonSave',
    defaultMessage: 'SALVAR IMAGEM',
  },
});
