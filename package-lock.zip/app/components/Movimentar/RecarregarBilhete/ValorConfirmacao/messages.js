import { defineMessages } from 'react-intl';

export default defineMessages({
  loadingDadosBilhete: {
    id: 'app.components.Movimentar.RecarregarBilhete.ValorConfirmacao.loadingDadosBilhete',
    defaultMessage: 'Carregando dados do bilhete...',
  },
  hintNumeroBilhete: {
    id: 'app.components.Movimentar.RecarregarBilhete.ValorConfirmacao.hintNumeroBilhete',
    defaultMessage: 'Número do Bilhete',
  },
  hintTitulo: {
    id: 'app.components.Movimentar.RecarregarBilhete.ValorConfirmacao.hintTitulo',
    defaultMessage: 'Título',
  },
  editar: {
    id: 'app.components.Movimentar.RecarregarBilhete.ValorConfirmacao.editar',
    defaultMessage: 'Editar',
  },
  excluir: {
    id: 'app.components.Movimentar.RecarregarBilhete.ValorConfirmacao.excluir',
    defaultMessage: 'Excluir',
  },
  buttonRecarregar: {
    id: 'app.components.Movimentar.RecarregarBilhete.ValorConfirmacao.buttonRecarregar',
    defaultMessage: 'Recarregar',
  },
});
