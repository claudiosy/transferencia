import React from 'react';

import FlatButton from 'material-ui/FlatButton';
import { injectIntl, intlShape, FormattedMessage } from 'react-intl';
import messages from './messages';
import CircularProgress from 'material-ui/CircularProgress';

import List from 'components/List';
import ListItem from 'components/ListItem';
import styles from './styles.css';

import transporteIcon from './transporte-icon.png';
import personIcon from 'containers/App/person-icon.png';
import editIcon from 'containers/App/icon-editar.png';
import removeIcon from 'containers/App/icon-excluir.png';

class ValorConfirmacao extends React.Component { // eslint-disable-line react/prefer-stateless-function
  render() {
    const { onConfirm, bilheteModel, loading, onUpdate, onDelete, columnOrder, columnSelection } = this.props;
    const { NumeroBilhete, Descricao } = bilheteModel;
    const { formatMessage } = this.props.intl;

    if (loading) {
      return (
        <span className={styles.loadingHistorico}>
          <CircularProgress size={0.3} />
          <FormattedMessage {...messages.loadingDadosBilhete} />
        </span>
      );
    }

    return (
      <form className={styles.contentValorForm}>
        <List>
          <ListItem key={1} icon={transporteIcon} notButton>
            <FormattedMessage {...messages.hintNumeroBilhete} />
            <span className="align-right text-gray">{NumeroBilhete}</span>
          </ListItem>
          <ListItem key={2} icon={personIcon} notButton>
            <FormattedMessage {...messages.hintTitulo} />
            <span className="align-right text-gray">{Descricao}</span>
          </ListItem>
          <ListItem name="editBilhete" key={3} onClick={() => onUpdate(NumeroBilhete)}>
            <FormattedMessage {...messages.editar} />
            <span className="align-right">
              <img src={editIcon} role="presentation" />
            </span>
          </ListItem>
          <ListItem name="deleteBilhete" key={4} onClick={onDelete}>
            <FormattedMessage {...messages.excluir} />
            <span className="align-right">
              <img src={removeIcon} role="presentation" />
            </span>
          </ListItem>
        </List>
        <FlatButton name="btnRecarregar" onMouseUp={() => onConfirm(columnOrder, columnSelection)} className="redButton big centered" label={formatMessage(messages.buttonRecarregar)} tabIndex="1" />
      </form>
    );
  }
}

ValorConfirmacao.propTypes = {
  bilheteModel: React.PropTypes.object,
  onConfirm: React.PropTypes.func,
  intl: intlShape.isRequired,
  loading: React.PropTypes.bool,
  onUpdate: React.PropTypes.func,
  onDelete: React.PropTypes.func,
  columnOrder: React.PropTypes.number,
  columnSelection: React.PropTypes.number,
};

export default injectIntl(ValorConfirmacao);
