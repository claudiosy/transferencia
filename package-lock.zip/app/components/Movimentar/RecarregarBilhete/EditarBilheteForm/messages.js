import { defineMessages } from 'react-intl';

export default defineMessages({
  hintApelido: {
    id: 'app.components.Movimentar.RecarregarBilhete.EditarBilheteForm.hintApelido',
    defaultMessage: 'Descrição',
  },
  hintDigito: {
    id: 'app.components.Movimentar.RecarregarBilhete.EditarBilheteForm.hintDigito',
    defaultMessage: 'Dígitos',
  },
  hintNumero: {
    id: 'app.components.Movimentar.RecarregarBilhete.EditarBilheteForm.hintNumero',
    defaultMessage: 'Número do bilhete',
  },
  buttonAtualizar: {
    id: 'app.components.Movimentar.RecarregarBilhete.EditarBilheteForm.buttonAtualizar',
    defaultMessage: 'Atualizar',
  },
});
