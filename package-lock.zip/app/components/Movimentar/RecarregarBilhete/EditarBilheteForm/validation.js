import messages from 'containers/App/messages';

const validateEditarBilheteForm = (valuesFromState, props) => {
  const { formatMessage } = props.intl;
  const errors = {};
  const values = valuesFromState.toJS();

  if (!values.NumeroBilhete) {
    errors.NumeroBilhete = formatMessage(messages.mandatoryField);
  }
  if (!values.Descricao) {
    errors.Descricao = formatMessage(messages.mandatoryField);
  }
  return errors;
};

export default validateEditarBilheteForm;
