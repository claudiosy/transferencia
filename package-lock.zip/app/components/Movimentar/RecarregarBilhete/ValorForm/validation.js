import messages from 'containers/App/messages';
import localMessages from './messages';
import { fromJS } from 'immutable';

const validateValorForm = (valuesFromState, props) => {
  const { formatMessage, formatNumber } = props.intl;
  const errors = {};
  const values = valuesFromState.toJS();
  const valor = !values.valor ? 0 : parseFloat(values.valor.replace(',', '|').replace('.', '').replace('|', '.'));

  const produtos = values.TipoCredito ? fromJS(props.TiposCredito.toJS().filter((tp) => { // eslint-disable-line arrow-body-style
    return tp.Codigo === values.TipoCredito;
  })[0].Produtos) : fromJS([]);

  const produtoSelected = produtos.toJS().filter((p) => { // eslint-disable-line arrow-body-style
    return p.Codigo === values.CodigoProduto;
  })[0];

  const QtdMaxVenda = !produtoSelected ? 0 : produtoSelected.QtdMaxVenda;
  const QtdMinVenda = !produtoSelected ? 0 : produtoSelected.QtdMinVenda;

  if (!values.TipoCredito) {
    errors.TipoCredito = formatMessage(messages.mandatoryField);
  }

  if (!values.CodigoProduto) {
    errors.CodigoProduto = formatMessage(messages.mandatoryField);
  }

  if (!values.valor) {
    errors.valor = formatMessage(messages.mandatoryField);
  }

  if (valor < QtdMinVenda || valor > QtdMaxVenda) {
    errors.valor = formatMessage(localMessages.erroValor).replace('{valor1}', formatNumber(QtdMinVenda, { style: 'decimal', minimumFractionDigits: 2, maximumFractionDigits: 2 })).replace('{valor2}', formatNumber(QtdMaxVenda, { style: 'decimal', minimumFractionDigits: 2, maximumFractionDigits: 2 }));
  }

  return errors;
};

export default validateValorForm;
