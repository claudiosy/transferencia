import { defineMessages } from 'react-intl';

export default defineMessages({
  loadingDadosBilhete: {
    id: 'app.components.Movimentar.RecarregarBilhete.ValorForm.loadingDadosBilhete',
    defaultMessage: 'Carregando dados do bilhete...',
  },
  hintTipoCredito: {
    id: 'app.components.Movimentar.RecarregarBilhete.ValorForm.hintTipoCredito',
    defaultMessage: 'Tipo Recarga',
  },
  hintTipoCarga: {
    id: 'app.components.Movimentar.RecarregarBilhete.ValorForm.hintTipoCarga',
    defaultMessage: 'Produto',
  },
  hintValor: {
    id: 'app.components.Movimentar.RecarregarBilhete.ValorForm.hintValor',
    defaultMessage: 'Digite o valor da Recarga',
  },
  buttonContinuar: {
    id: 'app.components.Movimentar.RecarregarBilhete.ValorForm.buttonContinuar',
    defaultMessage: 'Continuar',
  },
  erroValor: {
    id: 'app.components.Movimentar.RecarregarBilhete.ValorForm.erroValor',
    defaultMessage: 'Valores válidos entre {valor1} à {valor2}',
  },
});
