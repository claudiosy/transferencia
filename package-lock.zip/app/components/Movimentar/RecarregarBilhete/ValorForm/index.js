import React from 'react';
import { connect } from 'react-redux';
import { reduxForm, Field, formValueSelector } from 'redux-form/immutable';
import { fromJS } from 'immutable';

import { SelectField, TextField } from 'redux-form-material-ui';
import FlatButton from 'material-ui/FlatButton';
import validateValorForm from './validation';
import { injectIntl, intlShape, FormattedMessage } from 'react-intl';
import messages from './messages';
import CircularProgress from 'material-ui/CircularProgress';

import List from 'components/List';
import ListItem from 'components/ListItem';
import { normalizeDecimal } from 'normalizers';
import styles from './styles.css';

import SelectItem from 'components/SelectItem';

import tipoBilheteIcon from './tipoBilhete-icon.png';
import valueIcon from 'containers/App/value-icon.png';

class ValorForm extends React.Component { // eslint-disable-line react/prefer-stateless-function
  render() {
    const { handleSubmit, loading, tipoCreditoValue, tipoCargaValue, TiposCredito, handleSetTipoCredito, handleSetProduto } = this.props;
    const { formatMessage } = this.props.intl;
    const produtos = tipoCreditoValue ? fromJS(TiposCredito.toJS().filter((tp) => { // eslint-disable-line arrow-body-style
      return tp.Codigo === tipoCreditoValue;
    })[0].Produtos) : fromJS([]);

    if (loading) {
      return (
        <span className={styles.loadingHistorico}>
          <CircularProgress size={0.3} />
          <FormattedMessage {...messages.loadingDadosBilhete} />
        </span>
      );
    }

    return (
      <form onSubmit={handleSubmit}>
        <List>
          <ListItem icon={tipoBilheteIcon} key={1}>
            <SelectItem
              name="TipoCredito"
              component={SelectField}
              className="redInput"
              hintText={formatMessage(messages.hintTipoCredito)}
              tabIndex="1"
              selectData={TiposCredito}
              onChange={(event, key) => {
                const TipoCreditoDescricao = TiposCredito.toJS().filter((tp) => { // eslint-disable-line arrow-body-style
                  return tp.Codigo === key;
                })[0].Descricao;
                handleSetTipoCredito(TipoCreditoDescricao);
              }}
            />
          </ListItem>
          <ListItem icon={valueIcon} key={2} invisibled={!tipoCreditoValue}>
            <SelectItem
              name="CodigoProduto"
              component={SelectField}
              className="redInput"
              hintText={formatMessage(messages.hintTipoCarga)}
              tabIndex="2"
              selectData={produtos}
              disabled={!tipoCreditoValue}
              onChange={(event, key) => {
                const ProdutoDescricao = produtos.toJS().filter((p) => { // eslint-disable-line arrow-body-style
                  return p.Codigo === key;
                })[0].Descricao;
                handleSetProduto(ProdutoDescricao);
              }}
            />
          </ListItem>
          <ListItem icon={valueIcon} key={3} invisibled={!tipoCargaValue}>
            <Field
              name="valor"
              component={TextField}
              hintText={formatMessage(messages.hintValor)}
              normalize={normalizeDecimal}
              type="tel"
              disabled={!tipoCargaValue}
              tabIndex="3"
              format={normalizeDecimal}
            />
          </ListItem>
        </List>
        <FlatButton name="btnContinuar" type="submit" className="redButton big centered" label={formatMessage(messages.buttonContinuar)} tabIndex="4" />
      </form>
    );
  }
}

ValorForm.propTypes = {
  TiposCredito: React.PropTypes.object,
  handleSubmit: React.PropTypes.func,
  tipoCreditoValue: React.PropTypes.number,
  tipoCargaValue: React.PropTypes.number,
  tipoCredito: React.PropTypes.number,
  CodigoProduto: React.PropTypes.number,
  valor: React.PropTypes.number,
  intl: intlShape.isRequired,
  loading: React.PropTypes.bool,
  handleSetTipoCredito: React.PropTypes.func,
  handleSetProduto: React.PropTypes.func,
};

// Decorate with connect to read form values
const selector = formValueSelector('valorForm');
ValorForm = connect( // eslint-disable-line
  state => {
    // can select values individually
    const tipoCreditoValue = selector(state, 'TipoCredito');
    const tipoCargaValue = selector(state, 'CodigoProduto');

    return {
      tipoCreditoValue,
      tipoCargaValue,
    };
  }
)(ValorForm);

export default injectIntl(reduxForm({
  form: 'valorForm',
  validate: validateValorForm,
})(ValorForm));
