import { defineMessages } from 'react-intl';

export default defineMessages({
  hintApelido: {
    id: 'app.components.Movimentar.RecarregarBilhete.AdicionarBilheteForm.hintApelido',
    defaultMessage: 'Descrição',
  },
  hintDigito: {
    id: 'app.components.Movimentar.RecarregarBilhete.AdicionarBilheteForm.hintDigito',
    defaultMessage: 'Dígitos',
  },
  hintNumero: {
    id: 'app.components.Movimentar.RecarregarBilhete.AdicionarBilheteForm.hintNumero',
    defaultMessage: 'Número do bilhete',
  },
  buttonContinuar: {
    id: 'app.components.Movimentar.RecarregarBilhete.AdicionarBilheteForm.buttonContinuar',
    defaultMessage: 'Cadastrar',
  },
});
