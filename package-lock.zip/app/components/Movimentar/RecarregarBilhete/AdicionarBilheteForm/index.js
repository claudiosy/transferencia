import React from 'react';

import { reduxForm, Field } from 'redux-form/immutable';

import { TextField } from 'redux-form-material-ui';
import FlatButton from 'material-ui/FlatButton';
import validateAdicionarBilheteForm from './validation';
import { injectIntl, intlShape } from 'react-intl';
import messages from './messages';

import List from 'components/List';
import ListItem from 'components/ListItem';
import { normalizeBilhete } from 'normalizers';

import personIcon from 'containers/App/person-icon.png';
import bilheteIcon from './bilhete-icon.png';

const AdicionarBilheteForm = props => {
  const { handleSubmit, pristine, submitting } = props;
  const { formatMessage } = props.intl;

  return (
    <form onSubmit={handleSubmit}>
      <List>
        <ListItem key={1} icon={bilheteIcon}>
          <Field autoFocus name="NumeroBilhete" component={TextField} className="redInput wFloatingLabel" floatingLabelText={formatMessage(messages.hintNumero)} normalize={normalizeBilhete} type="tel" tabIndex="1" />
        </ListItem>
        <ListItem key={2} icon={personIcon}>
          <Field name="Descricao" component={TextField} className="redInput wFloatingLabel" floatingLabelText={formatMessage(messages.hintApelido)} tabIndex="2" />
        </ListItem>
      </List>
      <FlatButton name="btnCadastrar" type="submit" className="redButton big centered" label={formatMessage(messages.buttonContinuar)} disabled={pristine || submitting} tabIndex={3} />
    </form>
  );
};

AdicionarBilheteForm.propTypes = {
  pristine: React.PropTypes.bool,
  submitting: React.PropTypes.bool,
  handleSubmit: React.PropTypes.func,
  apelido: React.PropTypes.string,
  digito: React.PropTypes.string,
  numero: React.PropTypes.string,
  columnOrder: React.PropTypes.number,
  intl: intlShape.isRequired,
};

export default injectIntl(reduxForm({
  form: 'adicionarBilheteForm',
  validate: validateAdicionarBilheteForm,
})(AdicionarBilheteForm));
