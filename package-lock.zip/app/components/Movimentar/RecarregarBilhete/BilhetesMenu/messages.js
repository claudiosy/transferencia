import { defineMessages } from 'react-intl';

export default defineMessages({
  addBilhete: {
    id: 'app.components.Movimentar.RecarregarBilhete.BilhetesMenu.addBilhete',
    defaultMessage: 'CADASTRAR NOVO BILHETE',
  },
  informative: {
    id: 'app.components.Movimentar.RecarregarBilhete.BilhetesMenu.informative',
    defaultMessage: 'POR ENQUANTO, APENAS PARA BILHETE ÚNICO DA CIDADE DE SÃO PAULO',
  },
  loadingBilhete: {
    id: 'app.components.Movimentar.RecarregarBilhete.BilhetesMenu.loadingBilhete',
    defaultMessage: 'Carregando bilhetes...',
  },
});
