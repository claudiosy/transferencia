import React from 'react';

import List from 'components/List';
import ListItem from 'components/ListItem';
import CircularProgress from 'material-ui/CircularProgress';
import { FormattedMessage } from 'react-intl';
import messages from './messages';
import iconInfo from 'containers/App/icon-info.png';
import styles from './styles.css';

function BilhetesMenu(props) {
  const { columnSelection, columnOrder, handleStepChange, handleItemClick, loading, bilhetes } = props;

  let bilhetesList = bilhetes.toJS().map((ticket) => { // eslint-disable-line arrow-body-style
    return (
      <ListItem name={ticket.NumeroBilhete} key={ticket.ID} onClick={() => { handleItemClick(ticket); handleStepChange(columnOrder, ticket.NumeroBilhete); }}>
        {ticket.Descricao}
      </ListItem>
    );
  });

  if (loading) {
    bilhetesList = (
      <ListItem key={-3} showProceedIcon={false}>
        <span className={styles.loaderWrapper}>
          <CircularProgress size={0.3} />
        </span>
        <FormattedMessage {...messages.loadingBilhete} />
      </ListItem>
    );
  }

  return (
    <List showProceedIcon showHoverEffect behind={columnSelection !== 0} activeItem={columnSelection}>
      <ListItem name="addBilhete" key={-1} onClick={() => handleStepChange(columnOrder, -1)}>
        <FormattedMessage {...messages.addBilhete} />
      </ListItem>
      {bilhetesList}
      <ListItem key={-2} informative icon={iconInfo} showProceedIcon={false} notButton autoHeight sticky>
        <FormattedMessage {...messages.informative} />
      </ListItem>
    </List>
  );
}

BilhetesMenu.propTypes = {
  bilhetes: React.PropTypes.object,
  columnSelection: React.PropTypes.number,
  columnOrder: React.PropTypes.number,
  handleStepChange: React.PropTypes.func,
  handleItemClick: React.PropTypes.func,
  loading: React.PropTypes.bool,
};

export default BilhetesMenu;
