import React from 'react';
import List from 'components/List';
import ListItem from 'components/ListItem';
import styles from './styles.css';

import bilhete1 from './bilhete-1.png';
import bilhete2 from './bilhete-2.png';
import bilhete3 from './bilhete-3.png';
import bilhete4 from './bilhete-4.png';

class AdicionarBilheteTipo extends React.Component { // eslint-disable-line react/prefer-stateless-function
  render() {
    const { handleSetBilheteTipo } = this.props;
    return (
      <div>
        <h4 className="list-title">Escolha o tipo de bilhete:</h4>
        <List showProceedIcon showHoverEffect>
          <ListItem key={1} onClick={() => handleSetBilheteTipo(1)}>
            <img src={bilhete1} className={styles.btTipoBilhete} role="presentation" />
          </ListItem>
          <ListItem key={2} onClick={() => handleSetBilheteTipo(2)}>
            <img src={bilhete2} className={styles.btTipoBilhete} role="presentation" />
          </ListItem>
          <ListItem key={3} onClick={() => handleSetBilheteTipo(3)}>
            <img src={bilhete3} className={styles.btTipoBilhete} role="presentation" />
          </ListItem>
          <ListItem key={4} onClick={() => handleSetBilheteTipo(4)}>
            <img src={bilhete4} className={styles.btTipoBilhete} role="presentation" />
          </ListItem>
        </List>
      </div>
    );
  }
}

AdicionarBilheteTipo.propTypes = {
  handleSetBilheteTipo: React.PropTypes.func,
};

export default AdicionarBilheteTipo;
