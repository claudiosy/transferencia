import messages from 'containers/App/messages';

const validateInserirBoleto = (valuesFromState, props) => {
  const { formatMessage } = props.intl;
  const errors = {};
  const values = valuesFromState.toJS();

  if (!values.boleto) {
    errors.boleto = formatMessage(messages.mandatoryField);
  }
  if (!values.Valor) {
    errors.Valor = formatMessage(messages.mandatoryField);
  }
  if (!values.desconto) {
    errors.desconto = formatMessage(messages.mandatoryField);
  }
  if (!values.vencimento) {
    errors.vencimento = formatMessage(messages.mandatoryVencimento);
  }
  if (!values.pagarHoje) {
    errors.pagarHoje = formatMessage(messages.mandatoryDataPagamento);
  }
  if (!values.Identificacao) {
    errors.Identificacao = formatMessage(messages.mandatoryIdentificacaoPagamento);
  }
  if (!values.CategoriaId) {
    errors.CategoriaId = formatMessage(messages.mandatoryField);
  }
  return errors;
};

export default validateInserirBoleto;
