import { defineMessages } from 'react-intl';

export default defineMessages({
  header: {
    id: 'superdigital.InserirBoleto.header',
    defaultMessage: 'Inserir Número do Boleto',
  },
  labelCodBarras: {
    id: 'superdigital.InserirBoleto.labelCodBarras',
    defaultMessage: 'Inserir número do boleto',
  },
  labelValor: {
    id: 'superdigital.InserirBoleto.labelValor',
    defaultMessage: 'Valor',
  },
  labelDesconto: {
    id: 'superdigital.InserirBoleto.labelDesconto',
    defaultMessage: 'Desconto',
  },
  labelTotal: {
    id: 'superdigital.InserirBoleto.labelTotal',
    defaultMessage: 'Total a pagar',
  },
  labelVencimento: {
    id: 'superdigital.InserirBoleto.labelVencimento',
    defaultMessage: 'Vencimento',
  },
  labelHoje: {
    id: 'superdigital.InserirBoleto.labelHoje',
    defaultMessage: 'Pagar em',
  },
  labelAgendar: {
    id: 'superdigital.InserirBoleto.labelAgendar',
    defaultMessage: 'Agendar para',
  },
  labelIdentificacao: {
    id: 'superdigital.InserirBoleto.labelIdentificacao',
    defaultMessage: 'Identificação',
  },
  labelCategoria: {
    id: 'superdigital.InserirBoleto.labelCategoria',
    defaultMessage: 'Categoria',
  },
  labelTag: {
    id: 'superdigital.InserirBoleto.labelTag',
    defaultMessage: 'Colocar uma tag',
  },
  ButtonOK: {
    id: 'superdigital.InserirBoleto.ButtonOK',
    defaultMessage: 'OK',
  },
  ButtonCancelar: {
    id: 'superdigital.InserirBoleto.ButtonCancelar',
    defaultMessage: 'Cancelar',
  },
  continueButton: {
    id: 'superdigital.InserirBoleto.continueButton',
    defaultMessage: 'Continuar',
  },
  submitButton: {
    id: 'superdigital.InserirBoleto.submitButton',
    defaultMessage: 'Pagar',
  },
});
