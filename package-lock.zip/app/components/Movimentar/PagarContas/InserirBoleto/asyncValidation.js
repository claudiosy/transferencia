import { boletoValidationApi, somaTotal } from 'containers/Movimentar/PagarContasPage/actions';

const asyncValidateBoleto = (values, dispatch) => {
  const data = values.toJS();
  let valor;
  let desconto;

  if (!data.Valor && !data.Desconto) {
    return new Promise((resolve, reject) => {
      dispatch(boletoValidationApi(data.boleto, resolve, reject));
    }).then((status) => {
      if (status.status === 1) {
        // dispatch(openFormPagarContas());
      }
    });
  }

  if (!data.Valor) {
    valor = 0;
  } else if (data.Valor.toString().indexOf(',') >= 0) {
    valor = parseFloat(data.Valor.replace(',', '|').replace('.', '').replace('|', '.'));
  } else {
    valor = data.Valor;
  }

  if (!data.Desconto) {
    desconto = 0;
  } else if (data.Desconto.toString().indexOf(',') >= 0) {
    desconto = parseFloat(data.Desconto.replace(',', '|').replace('.', '').replace('|', '.'));
  } else {
    desconto = data.Desconto;
  }

  return new Promise((resolve) => {
    dispatch(somaTotal(valor, desconto));
    resolve();
  });
};

export default asyncValidateBoleto;
