import React from 'react';
import { reduxForm, Field } from 'redux-form/immutable';
import { TextField, DatePicker/* ,SelectField*/ } from 'redux-form-material-ui';
import FlatButton from 'material-ui/FlatButton';
// import MenuItem from 'material-ui/MenuItem';
// import ChipInput from 'material-ui-chip-input';
import areIntlLocalesSupported from 'intl-locales-supported';
import { normalizeBoleto, normalizeDecimal } from 'normalizers';
import validateInserirBoleto from './validation';
import asyncValidateBoleto from './asyncValidation';

import { injectIntl, intlShape, FormattedNumber } from 'react-intl';

import messages from './messages';
import styles from './styles.css';

import List from 'components/List';
import ListItem from 'components/ListItem';
import Loader from 'components/Loader';

import barcodeIcon from './barcode-icon.png';
import dolarIcon from './dolar-icon.png';
import calendarioIcon from './calendario-icon.png';
import identificarIcon from './identificar-icon.png';
// import categoriaIcon from './categoria-icon.png';
// import tagIcon from './tag-icon.png';
// import addIcon from './adicionar-icon.png';

let DateTimeFormat;

if (areIntlLocalesSupported('pt-BR')) {
  DateTimeFormat = global.Intl.DateTimeFormat;
} else {
  const IntlPolyfill = require('intl'); // eslint-disable-line global-require
  DateTimeFormat = IntlPolyfill.DateTimeFormat;
  require('intl/locale-data/jsonp/pt-BR'); // eslint-disable-line global-require
}

/* const handleTagPlusClick = () => {
  const eventObj = document.createEventObject ? document.createEventObject() : document.createEvent('Events');

  if (eventObj.initEvent) {
    eventObj.initEvent('keydown', true, true);
  }

  eventObj.keyCode = 13;
  eventObj.which = 13;

  const el = document.getElementsByName('Tags')[0];
  el.dispatchEvent ? el.dispatchEvent(eventObj) : el.fireEvent('onkeydown', eventObj); // eslint-disable-line no-unused-expressions
}; */

const InserirBoleto = props => { // eslint-disable-line react/prefer-stateless-function
  const { handleSubmit/* , handleTags*/, pristine, submitting, loading, message, boletoStatus, valorTotal/* , categorias, dadosPagtoModel*/ } = props;
  const { formatMessage } = props.intl;
  let content;

  const minDateVencimento = new Date();
  const maxDateVencimento = new Date();
  minDateVencimento.setMinutes(minDateVencimento.getMinutes() - 43200);
  maxDateVencimento.setMinutes(maxDateVencimento.getMinutes() + 43200);

  const minDateAgendar = new Date();
  const maxDateAgendar = new Date();

  /* const categoriaList = categorias.toJS().map((ticket) => { // eslint-disable-line arrow-body-style
    return (
      <MenuItem value={ticket.id} primaryText={ticket.descricao} />
    );
  }); */

  if (message) {
    content = (<h2>{message}</h2>);
  } else if (loading) {
    content = (<Loader top={0} />);
  } else {
    content = boletoStatus !== 2 ? (
      <form onSubmit={handleSubmit}>
        <List>
          <ListItem key={1} icon={barcodeIcon}>
            <Field autoFocus name="boleto" className="redInput" component={TextField} hintText={formatMessage(messages.labelCodBarras)} label={formatMessage(messages.labelCodBarras)} type="tel" normalize={normalizeBoleto} tabIndex="1" />
          </ListItem>
        </List>
        <FlatButton name="btnContinuar" className="redButton big centered" type="submit" label={formatMessage(messages.continueButton)} disabled={pristine || submitting} tabIndex="2" />
      </form>
    ) : (
      <form>
        <List>
          <ListItem key={1} icon={barcodeIcon}>
            <Field name="boleto" className="redInput" component={TextField} hintText={formatMessage(messages.labelCodBarras)} label={formatMessage(messages.labelCodBarras)} type="tel" normalize={normalizeBoleto} readOnly tabIndex="1" />
          </ListItem>
          <ListItem key={2} icon={dolarIcon}>
            <Field name="Valor" className="redInput wFloatingLabel" component={TextField} floatingLabelText={formatMessage(messages.labelValor)} label={formatMessage(messages.labelValor)} type="tel" normalize={normalizeDecimal} format={normalizeDecimal} tabIndex="2" />
          </ListItem>
          <ListItem key={3}>
            <Field name="Desconto" className="redInput wFloatingLabel" component={TextField} floatingLabelText={formatMessage(messages.labelDesconto)} label={formatMessage(messages.labelDesconto)} type="tel" normalize={normalizeDecimal} format={normalizeDecimal} tabIndex="3" />
          </ListItem>
          <ListItem key={4}>
            <span className={styles.labelTotal}>{formatMessage(messages.labelTotal)}</span><span className={styles.valorRight}><FormattedNumber style="currency" currency="BRL" value={valorTotal} /></span>
          </ListItem>
          <ListItem key={5} icon={calendarioIcon}>
            <Field
              name="Vencimento"
              className="redInput wFloatingLabel"
              component={DatePicker}
              floatingLabelText={formatMessage(messages.labelVencimento)}
              locale="pt-BR"
              cancelLabel={formatMessage(messages.ButtonCancelar)}
              okLabel={formatMessage(messages.ButtonOK)}
              autoOk
              minDate={minDateVencimento}
              maxDate={maxDateVencimento}
              DateTimeFormat={DateTimeFormat}
              tabIndex="4"
            />
          </ListItem>
          <ListItem key={6} icon={calendarioIcon}>
            <Field
              name="pagarHoje"
              className="redInput wFloatingLabel"
              component={DatePicker}
              floatingLabelText={formatMessage(messages.labelHoje)}
              locale="pt-BR"
              cancelLabel={formatMessage(messages.ButtonCancelar)}
              okLabel={formatMessage(messages.ButtonOK)}
              autoOk
              minDate={minDateAgendar}
              maxDate={maxDateAgendar}
              DateTimeFormat={DateTimeFormat}
              disabled
              tabIndex="5"
            />
          </ListItem>
          <ListItem key={7} icon={identificarIcon}>
            <Field name="Identificacao" className="redInput wFloatingLabel" component={TextField} floatingLabelText={formatMessage(messages.labelIdentificacao)} label={formatMessage(messages.labelIdentificacao)} tabIndex="6" />
          </ListItem>
        </List>
        <FlatButton name="btnPagar" className="redButton big centered" type="button" label={formatMessage(messages.submitButton)} onMouseUp={handleSubmit} disabled={pristine || submitting} tabIndex="10" />
      </form>
    );
  }
  return (
    <div className={styles.formWrapper}>
      {content}
    </div>);
};

InserirBoleto.propTypes = {
  handleTags: React.PropTypes.func,
  handleSubmit: React.PropTypes.func,
  pristine: React.PropTypes.bool,
  loading: React.PropTypes.bool,
  message: React.PropTypes.string,
  submitting: React.PropTypes.bool,
  boletoStatus: React.PropTypes.number,
  boleto: React.PropTypes.string,
  valorTotal: React.PropTypes.number,
  categorias: React.PropTypes.object,
  intl: intlShape.isRequired,
  dadosPagtoModel: React.PropTypes.object,
};

export default injectIntl(reduxForm({
  form: 'inserirBoleto',
  enableReinitialize: true,
  validate: validateInserirBoleto,
  asyncValidate: asyncValidateBoleto,
  asyncBlurFields: ['Valor', 'Desconto'],
})(InserirBoleto));
