import React from 'react';
import { reduxForm } from 'redux-form/immutable';
import List from 'components/List';
import ListItem from 'components/ListItem';
import Loader from 'components/Loader';
import { FormattedNumber, FormattedMessage } from 'react-intl';

import messages from './messages';
import styles from './styles.css';

import calendarioIcon from './calendario-icon.png';
import iconInfo from 'containers/App/icon-info.png';

const PagamentosAgendados = props => { // eslint-disable-line react/prefer-stateless-function
  const { handleStepChangeValues, loading, message, columnSelection, columnOrder, pagtosAgendados } = props;
  let content;
  let pagtosList;

  if (pagtosAgendados.length !== 0) {
    pagtosList = pagtosAgendados.map((ticket) => { // eslint-disable-line arrow-body-style
      return (
        <ListItem key={ticket.ID} icon={calendarioIcon} onClick={() => handleStepChangeValues(columnOrder, ticket.ID, ticket.DataAgendamento, ticket.Identificacao, ticket.Valor)}>
          <span className={styles.identificacao}>{ticket.Identificacao}</span><span className={styles.valor}><FormattedNumber style="currency" currency="BRL" value={ticket.Valor} /></span><br /><span className={styles.data}>{`${ticket.DataAgendamento.substring(8, 10)}/${ticket.DataAgendamento.substring(5, 7)}`}</span>
        </ListItem>
      );
    });
  } else {
    pagtosList = (
      <ListItem key={1} icon={iconInfo} notButton showProceedIcon={false}>
        <FormattedMessage {...messages.semAgendamento} />
      </ListItem>
    );
  }

  if (message) {
    content = (<h2>{message}</h2>);
  } else if (loading) {
    content = (<Loader top={0} />);
  } else {
    content = (
      <List showProceedIcon showHoverEffect behind={columnSelection !== 0} activeItem={columnSelection}>
        {pagtosList}
      </List>
    );
  }
  return (
    <div>
      {content}
    </div>);
};

PagamentosAgendados.propTypes = {
  handleStepChangeValues: React.PropTypes.func,
  pristine: React.PropTypes.bool,
  loading: React.PropTypes.bool,
  message: React.PropTypes.string,
  submitting: React.PropTypes.bool,
  columnSelection: React.PropTypes.number,
  columnOrder: React.PropTypes.number,
  pagtosAgendados: React.PropTypes.object,
};

export default reduxForm({
  form: 'pagamentosAgendados',
})(PagamentosAgendados);
