import { defineMessages } from 'react-intl';

export default defineMessages({
  semAgendamento: {
    id: 'superdigital.PagamentosAgendados.semAgendamento',
    defaultMessage: 'Não existem pagamentos agendados.',
  },
});
