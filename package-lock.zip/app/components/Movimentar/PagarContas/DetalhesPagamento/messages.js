import { defineMessages } from 'react-intl';

export default defineMessages({
  header: {
    id: 'superdigital.DetalhesPagamento.header',
    defaultMessage: 'Detalhes do Pagamento Agendado',
  },
  labelAgendar: {
    id: 'superdigital.InserirBoleto.labelAgendar',
    defaultMessage: 'Agendar Para',
  },
  labelIdentificacao: {
    id: 'superdigital.InserirBoleto.labelIdentificacao',
    defaultMessage: 'Identificação',
  },
  ButtonOK: {
    id: 'superdigital.DetalhesPagamento.ButtonOK',
    defaultMessage: 'OK',
  },
  ButtonCancelar: {
    id: 'superdigital.DetalhesPagamento.ButtonCancelar',
    defaultMessage: 'Cancelar',
  },
  ButtonSalvar: {
    id: 'superdigital.DetalhesPagamento.ButtonSalvar',
    defaultMessage: 'SALVAR',
  },
  excluir: {
    id: 'superdigital.DetalhesPagamento.excluir',
    defaultMessage: 'Cancelar Agendamento',
  },
});
