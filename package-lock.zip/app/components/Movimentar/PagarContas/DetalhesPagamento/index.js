import React from 'react';
import { reduxForm, Field } from 'redux-form/immutable';
import { TextField, DatePicker } from 'redux-form-material-ui';
import FlatButton from 'material-ui/FlatButton';
import Loader from 'components/Loader';
import areIntlLocalesSupported from 'intl-locales-supported';
import validateDetalhesPagamento from './validation';

import { injectIntl, intlShape, FormattedNumber, FormattedMessage } from 'react-intl';

import messages from './messages';
import styles from './styles.css';

import List from 'components/List';
import ListItem from 'components/ListItem';

import dolarIcon from './dolar-icon.png';
import identificarIcon from './identificar-icon.png';
import calendarioIcon from './calendario-icon.png';
import penIcon from './pen-icon.png';
import cancelIcon from './cancel.png';

let DateTimeFormat;

if (areIntlLocalesSupported('pt-BR')) {
  DateTimeFormat = global.Intl.DateTimeFormat;
} else {
  const IntlPolyfill = require('intl'); // eslint-disable-line global-require
  DateTimeFormat = IntlPolyfill.DateTimeFormat;
  require('intl/locale-data/jsonp/pt-BR'); // eslint-disable-line global-require
}

const DetalhesPagamento = props => { // eslint-disable-line react/prefer-stateless-function
  const { handleSubmit, /* pristine, submitting,*/ loading, message, dadosPagtoModel, onDelete } = props;
  const { formatMessage } = props.intl;
  let content;
  const minDate = new Date();
  const maxDate = new Date();
  maxDate.setMinutes(maxDate.getMinutes() + 43200);

  if (message) {
    content = (<h2>{message}</h2>);
  } else if (loading) {
    content = (<Loader top={0} />);
  } else {
    content = (
      <form onSubmit={handleSubmit}>
        <List>
          <ListItem key={1} icon={dolarIcon} notButton>
            <span><FormattedNumber style="currency" currency="BRL" value={dadosPagtoModel.Valor} /></span>
          </ListItem>
          <ListItem key={2} icon={identificarIcon}>
            <Field name="Identificacao" className="redInput" component={TextField} hintText={formatMessage(messages.labelIdentificacao)} label={formatMessage(messages.labelIdentificacao)} tabIndex="1" />
            <img src={penIcon} className={styles.penIcon} alt="" role="presentation" />
          </ListItem>
          <ListItem key={3} icon={calendarioIcon}>
            <Field
              name="DataAgendamento"
              component={DatePicker}
              hintText={formatMessage(messages.labelAgendar)}
              locale="pt-BR"
              cancelLabel={formatMessage(messages.ButtonCancelar)}
              okLabel={formatMessage(messages.ButtonOK)}
              autoOk
              minDate={minDate}
              maxDate={maxDate}
              DateTimeFormat={DateTimeFormat}
              tabIndex="2"
            />
            <img src={penIcon} className={styles.penIcon} alt="" role="presentation" />
          </ListItem>
          <ListItem key={4} onClick={onDelete}>
            <FormattedMessage {...messages.excluir} />
            <img src={cancelIcon} className={styles.penIcon} alt="" role="presentation" />
          </ListItem>
        </List>
        <FlatButton className="redButton big centered" type="submit" label={formatMessage(messages.ButtonSalvar)} tabIndex="3" />
      </form>
    );
  }
  return (
    <div className={styles.formWrapper}>
      {content}
    </div>);
};

DetalhesPagamento.propTypes = {
  handleStepChange: React.PropTypes.func,
  onDelete: React.PropTypes.func,
  handleSubmit: React.PropTypes.func,
  pristine: React.PropTypes.bool,
  loading: React.PropTypes.bool,
  message: React.PropTypes.string,
  submitting: React.PropTypes.bool,
  dadosPagtoModel: React.PropTypes.object,
  identificacao: React.PropTypes.string,
  data: React.PropTypes.string,
  intl: intlShape.isRequired,
};

export default injectIntl(reduxForm({
  form: 'detalhesPagamentoForm',
  enableReinitialize: true,
  validate: validateDetalhesPagamento,
})(DetalhesPagamento));
