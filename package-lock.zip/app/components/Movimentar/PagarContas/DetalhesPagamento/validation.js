import messages from 'containers/App/messages';

const validateDetalhesPagamento = (valuesFromState, props) => {
  const { formatMessage } = props.intl;
  const errors = {};
  const values = valuesFromState.toJS();

  if (!values.Identificacao) {
    errors.boleto = formatMessage(messages.mandatoryField);
  }
  if (!values.DataAgendamento) {
    errors.Valor = formatMessage(messages.mandatoryField);
  }
  return errors;
};

export default validateDetalhesPagamento;
