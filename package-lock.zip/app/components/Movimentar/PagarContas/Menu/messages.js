import { defineMessages } from 'react-intl';

export default defineMessages({
  digitarBoleto: {
    id: 'app.components.Movimentar.PagarContas.Menu.digitarBoleto',
    defaultMessage: 'INSERIR DADOS DO BOLETO',
  },
  pagAgendados: {
    id: 'app.components.Movimentar.PagarContas.Menu.pagAgendados',
    defaultMessage: 'PAGAMENTOS AGENDADOS',
  },
  informative01: {
    id: 'app.components.Movimentar.PagarContas.Menu.informative01',
    defaultMessage: 'HORÁRIO LIMITE PARA PAGAR CONTAS QUE VENCEM HOJE',
  },
  informative02: {
    id: 'app.components.Movimentar.PagarContas.Menu.informative02',
    defaultMessage: 'Abaixo de R$ 1.500,00, até as 18h.',
  },
  informative03: {
    id: 'app.components.Movimentar.PagarContas.Menu.informative03',
    defaultMessage: 'Acima de R$ 1.500,00 ou com desconto, até as 14h30.',
  },
});
