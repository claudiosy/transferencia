import React from 'react';
import { reduxForm } from 'redux-form/immutable';
import List from 'components/List';
import ListItem from 'components/ListItem';
import CircularProgress from 'material-ui/CircularProgress';
import { FormattedMessage } from 'react-intl';
import messages from './messages';

import styles from './styles.css';

import iconInfo from 'containers/App/icon-info.png';

const Menu = props => { // eslint-disable-line react/prefer-stateless-function
  const { handleStepChange, loading, message, columnSelection, columnOrder, showNotice } = props;

  let content;
  let aviso = '';

  if (message) {
    content = (<h2>{message}</h2>);
  } else if (loading) {
    content = (<div><CircularProgress /></div>);
  } else {
    content = (
      <List showProceedIcon showHoverEffect behind={columnSelection !== 0} activeItem={columnSelection}>
        <ListItem name="inserirBoleto" key={1} onClick={() => handleStepChange(columnOrder, 1)}>
          <FormattedMessage {...messages.digitarBoleto} />
        </ListItem>
        <ListItem name="pagAgendados" key={2} onClick={() => handleStepChange(columnOrder, 2)} invisibled /* Ocultado Provisoriamente */>
          <FormattedMessage {...messages.pagAgendados} />
        </ListItem>
      </List>
    );

    if (showNotice) {
      aviso = (
        <div className={styles.aviso}>
          <img className={styles.icon} src={iconInfo} alt="" role="presentation" />
          <p><FormattedMessage {...messages.informative01} /></p>
          <p><FormattedMessage {...messages.informative02} /></p>
          <p><FormattedMessage {...messages.informative03} /></p>
        </div>
      );
    }
  }
  return (
    <div>
      {content}
      {aviso}
    </div>);
};

Menu.propTypes = {
  handleStepChange: React.PropTypes.func,
  pristine: React.PropTypes.bool,
  loading: React.PropTypes.bool,
  message: React.PropTypes.string,
  submitting: React.PropTypes.bool,
  columnSelection: React.PropTypes.number,
  columnOrder: React.PropTypes.number,
  showNotice: React.PropTypes.bool,
};

export default reduxForm({
  form: 'menu',
})(Menu);
