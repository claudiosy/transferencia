import React from 'react';
import { injectIntl, intlShape } from 'react-intl';
import styles from './styles.css';
import messages from '../TermoAceite/messages';

const Box = props => {
  const { retResumoCambioModel } = props;
  const { formatMessage } = props.intl;
  const dataEmArray = new Date(retResumoCambioModel.DataRealizacao).toLocaleString('pt-BR').split(' ');
  const content = (
    <div className={styles.divTable}>
      <div className={styles.ivTableBody}>
        <div className={styles.divTableRow}>
          <div className={styles.divTableCell}>{formatMessage(messages.lblSolicitou)}</div>
          <div className={styles.divTableCell}>{`${retResumoCambioModel.SiglaMoedaDestino} (${retResumoCambioModel.DescricaoMoedaDestino}) ${Number(retResumoCambioModel.ValorVenda).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`}</div>
        </div>
        <div className={styles.divTableRow}>
          <div className={styles.divTableCell}>{formatMessage(messages.lblEm)}</div>
          <div className={styles.divTableCell}>{`${dataEmArray[0]} às ${dataEmArray[1]}`}</div>
        </div>
        <div className={styles.divTableRow}>
          <div className={styles.divTableCell}>{formatMessage(messages.lblTaxa)}</div>
          <div className={styles.divTableCell}>{Number(retResumoCambioModel.Taxa).toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</div>
        </div>
        <div className={styles.divTableRow}>
          <div className={styles.divTableCell}>{formatMessage(messages.lblIOF)}</div>
          <div className={styles.divTableCell}>{`${retResumoCambioModel.SiglaMoedaOrigem} (${retResumoCambioModel.DescricaoMoedaOrigem}) ${Number(retResumoCambioModel.Iof).toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`}</div>
        </div>
        <div className={styles.divTableRow}>
          <div className={styles.divTableCell}>{formatMessage(messages.lblTaxaVET)}</div>
          <div className={styles.divTableCell}>{Number(retResumoCambioModel.TaxaVET).toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</div>
        </div>
        <div className={styles.divTableRow}>
          <div className={styles.divTableCell}>{formatMessage(messages.lblEfetivoTotal)}</div>
          <div className={styles.divTableCell}>{`${retResumoCambioModel.SiglaMoedaOrigem} (${retResumoCambioModel.DescricaoMoedaOrigem}) ${Number(retResumoCambioModel.Total).toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`}</div>
        </div>
        <div className={styles.divTableRow}>
          <div className={styles.divTableCell}>{formatMessage(messages.lblPedido)}</div>
          <div className={styles.divTableCell}>{retResumoCambioModel.Pedido.toString().padStart(5, '0')}</div>
        </div>
      </div>
    </div>
  );

  return (
    <div>
      {content}
    </div>
  );
};

Box.propTypes = {
  retResumoCambioModel: React.PropTypes.object,
  intl: intlShape.isRequired,
};

export default injectIntl(Box);
