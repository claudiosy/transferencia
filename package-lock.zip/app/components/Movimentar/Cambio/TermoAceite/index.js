import React from 'react';
import { Row, Col } from 'react-flexbox-grid/lib/index';
import FlatButton from 'material-ui/FlatButton';
import { FormattedMessage, injectIntl, intlShape } from 'react-intl';
import messages from './messages';
import List from 'components/List';
import ListItem from 'components/ListItem';
import styles from './styles.css';
import CircularProgress from 'material-ui/CircularProgress';
import Box from '../Box';
// import infoIcon from './info-icon.png';

const TermoAceite = props => {
  const { onConfirm, loading, contrato, retResumoCambioModel } = props;
  const { formatMessage } = props.intl;
  let content;
  if (loading) {
    content = (
      <List>
        <ListItem key={-3} showProceedIcon={false}>
          <span className={styles.loaderWrapper}>
            <CircularProgress size={0.3} />
          </span>
          <FormattedMessage {...messages.loadingContrato} />
        </ListItem>
      </List>
    );
  } else {
    content = (
      <form>
        <Row center="xs" className={styles.tituloAceite} >
          <Col sm={12} xs={12}>
            <span>{formatMessage(messages.lblCinfirmaDados)}</span>
          </Col>
        </Row>
        <Row>
          <Col sm={12} xs={12}>
            <Box retResumoCambioModel={retResumoCambioModel} />
          </Col>
        </Row>
        <Row center="xs" className={styles.tituloAceite} >
          <Col sm={12} xs={12}>
            <span>{formatMessage(messages.lblTitulo)}</span>
          </Col>
        </Row>
        <Row className={styles.termoAceite}>
          <Col sm={12} xs={12}>
            <span>{contrato}</span>
          </Col>
        </Row>
        <FlatButton name="btnConcordo" onMouseUp={onConfirm} className="redButton big centered" label={formatMessage(messages.buttonConfirmar)} tabIndex="1" />
      </form>
    );
  }

  return (
    <div>
      {content}
    </div>
  );
};

TermoAceite.propTypes = {
  onConfirm: React.PropTypes.func,
  loading: React.PropTypes.bool,
  contrato: React.PropTypes.object,
  intl: intlShape.isRequired,
  retResumoCambioModel: React.PropTypes.object,
};

export default injectIntl(TermoAceite);
