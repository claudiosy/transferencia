import { defineMessages } from 'react-intl';

export default defineMessages({
  lblTitulo: {
    id: 'app.components.Movimentar.Cambio.TermoAceite.lblTitulo',
    defaultMessage: 'TERMO DE ACEITE',
  },
  loadingContrato: {
    id: 'app.components.Movimentar.Cambio.TermoAceite.loadingContrato',
    defaultMessage: 'Carregando o contrato...',
  },
  buttonConfirmar: {
    id: 'app.components.Movimentar.Cambio.TermoAceite.buttonConfirmar',
    defaultMessage: 'Concordo',
  },
  lblCinfirmaDados: {
    id: 'app.components.Movimentar.Cambio.TermoAceite.lblCinfirmaDados',
    defaultMessage: 'Confirme os dados',
  },
  lblSolicitou: {
    id: 'app.components.Movimentar.Cambio.TermoAceite.lblSolicitou',
    defaultMessage: 'Você solicitou câmbio na sua conta Superdigital para:',
  },
  lblEm: {
    id: 'app.components.Movimentar.Cambio.TermoAceite.lblEm',
    defaultMessage: 'Em:',
  },
  lblTaxa: {
    id: 'app.components.Movimentar.Cambio.TermoAceite.lblTaxa',
    defaultMessage: 'Taxa de:',
  },
  lblIOF: {
    id: 'app.components.Movimentar.Cambio.TermoAceite.lblIOF',
    defaultMessage: 'IOF no valor de:',
  },
  lblTaxaVET: {
    id: 'app.components.Movimentar.Cambio.TermoAceite.lblTaxaVET',
    defaultMessage: 'Taxa VET (Valor Efetivo Total):',
  },
  lblEfetivoTotal: {
    id: 'app.components.Movimentar.Cambio.TermoAceite.lblEfetivoTotal',
    defaultMessage: 'Valor Efetivo Total:',
  },
  lblPedido: {
    id: 'app.components.Movimentar.Cambio.TermoAceite.lblPedido',
    defaultMessage: 'Pedido:',
  },
});
