import React from 'react';
import styles from './styles.css';
import messages from './messages';
import { SelectField, TextField } from 'redux-form-material-ui';
import { reduxForm, Field } from 'redux-form/immutable';
import { FormattedMessage, FormattedNumber, injectIntl, intlShape } from 'react-intl';
import { Row, Col } from 'react-flexbox-grid/lib/index';
import List from 'components/List';
import FlatButton from 'material-ui/FlatButton';
import ListItem from 'components/ListItem';
import MenuItem from 'material-ui/MenuItem';
import CircularProgress from 'material-ui/CircularProgress';
import dolarIcon from './dolar-icon.png';
import Slider from 'react-slick';
import { normalizeDecimal } from 'normalizers';
import iconInfo from 'containers/App/icon-info.png';
import iconNextArrow from 'containers/App/proceed-icon.png';
import iconPrevArrow from 'containers/App/prev-icon.png';
// import validateCotacaoMoedas from './validation';

/* eslint-disable */
const SampleNextArrow = React.createClass({
  render: function() {
    return <div {...this.props} style={{ display: 'block', background: `url(${iconNextArrow}) no-repeat` }}></div>;
  },
});

const SamplePrevArrow = React.createClass({
  render: function() {
    return (
      <div {...this.props} style={{ display: 'block', background: `url(${iconPrevArrow}) no-repeat` }}></div>
    );
  },
});

class CotacaoMoedas extends React.Component { // eslint-disable-line
  constructor() {
    super();
    this.state = { infoOpen: false };
    this.handleClick = this.handleClick.bind(this);
  }
  handleClick(infoOpen) {
    this.setState({ infoOpen: !infoOpen });
  }
  render() {
    const { handleSubmit, loading, saldosMoedas, limiteCambio, moedas, handleSelecaoSaldoMoeda, handleSelecaoMoeda, siglasMoedaModel, retCalulaCambioModel, isCalc } = this.props;
    const { formatMessage, formatNumber } = this.props.intl;
    const { infoOpen } = this.state;
    let content;
    const retorno = retCalulaCambioModel && retCalulaCambioModel.toJS();
    const retTaxa = retorno.Taxa ? parseFloat(retorno.Taxa.replace(',', '|').replace('.', '').replace('|', '.')) : 0.00;
    const retIOF = retorno.Iof && retorno.Iof !== 'Isento' ? parseFloat(retorno.Iof.replace(',', '|').replace('.', '').replace('|', '.')) : 0.00;
    const retTotal = retorno.Total ? parseFloat(retorno.Total.replace(',', '|').replace('.', '').replace('|', '.')) : 0.00;
    const siglaOrigem = siglasMoedaModel.toJS().SiglaOrigem;
    const hintStyle = {
      color: 'rgba(0, 0, 0, 1)',
      width: '100%',
    };
    const settings = {
      dots: false,
      infinite: false,
      speed: 500,
      slidesToShow: 3,
      slidesToScroll: 3,
      initialSlide: 0,
      nextArrow: <SampleNextArrow />,
      prevArrow: <SamplePrevArrow />,
    };
    const moedaList = moedas && moedas.toJS().length && moedas.toJS().map((moeda) => { // eslint-disable-line arrow-body-style
      return (
        <MenuItem value={moeda.Id} primaryText={moeda.Sigla} />
      );
    });
    let contentSelect1;
    let contentSelect2;
    if (moedaList && moedaList.length) {
      contentSelect1 = (
        <Field name="MoedaOrigemId" component={SelectField} className={styles.siglaMoeda} floatingLabelText={formatMessage(messages.cotacaoDe)} onChange={(event, key) => handleSelecaoMoeda(key, 3)} underlineShow={false} tabIndex="1" >
          {moedaList}
        </Field>
      );
      contentSelect2 = (
        <Field name="MoedaDestinoId" component={SelectField} className={styles.siglaMoeda} floatingLabelText={formatMessage(messages.cotacaoPara)} onChange={(event, key) => handleSelecaoMoeda(key, 4)} underlineShow={false} tabIndex="1" >
          {moedaList}
        </Field>
      );
    }

    const sliders = saldosMoedas && saldosMoedas.toJS().length && saldosMoedas.toJS().map((saldo) => { // eslint-disable-line arrow-body-style
      return (
        <div className={styles.sliders}>
          <a href="javascript:;" onClick={() => handleSelecaoSaldoMoeda(saldo.Sigla, saldo.MoedaId, saldo.Saldo, saldo.Simbolo, saldo.Descricao)}>
            <p>{saldo.Sigla}</p>
            <p className="valor"><FormattedNumber style="decimal" minimumFractionDigits={2} value={saldo.Saldo} /></p>
          </a>
        </div>
      );
    });
    let contentSlide;
    if (sliders && sliders.length) {
      contentSlide = (
        <Slider {...settings}>
          {sliders}
        </Slider>
      );
    }
    if (loading) {
      content = (
        <List>
          <ListItem key={-3} showProceedIcon={false}>
            <span className={styles.loaderWrapper}>
              <CircularProgress size={0.3} />
            </span>
            <FormattedMessage {...messages.loadingMoedas} />
          </ListItem>
        </List>
      );
    } else {
      content = (
        <form>
          <Row className={`${styles.slidersMoedas} ${isCalc && styles.slidersHidden}`}>
            <Col sm={12}>
              <List>
                <ListItem key={0} icon={dolarIcon} notButton>
                  <span><FormattedMessage {...messages.moedas} /></span>
                </ListItem>
              </List>
              <div className="contentSlider">
                {contentSlide}
              </div>
            </Col>
          </Row>
          <Row>
            <Col sm={12} xs={12}>
              <List>
                <ListItem key={0} icon={dolarIcon} invisibled={isCalc} notButton>
                  <span><FormattedMessage {...messages.cotacao} /></span>
                </ListItem>
                <ListItem key={1}>
                  <Col className={styles.noMargin} sm={3}>
                      {contentSelect1}
                  </Col>
                  <Col className={styles.noMargin} sm={9}>
                    <Field
                      name="ValorOrigem"
                      component={TextField}
                      className={styles.inputValor}
                      hintText={'0,00'}
                      hintStyle={hintStyle}
                      normalize={normalizeDecimal}
                      type="tel"
                      format={normalizeDecimal}
                      tabIndex="1"
                      onKeyUp={event => {
                        this.props.handleSetValor(event.target.value.replace(',', '|').replace('.', '').replace('|', '.'), 1);
                      }}
                    />
                  </Col>
                </ListItem>
                <ListItem key={2}>
                  <Col className={styles.noMargin} sm={3}>
                      {contentSelect2}
                  </Col>
                  <Col sm={9} className={styles.noMargin}>
                    <Field
                      name="ValorDestino"
                      component={TextField}
                      className={styles.inputValor}
                      hintText={'0,00'}
                      hintStyle={hintStyle}
                      normalize={normalizeDecimal}
                      type="tel"
                      format={normalizeDecimal}
                      tabIndex="2"
                      onKeyUp={event => {
                        this.props.handleSetValor(event.target.value.replace(',', '|').replace('.', '').replace('|', '.'), 2);
                      }}
                    />
                  </Col>
                </ListItem>
                <ListItem key={3} invisibled={!isCalc} notButton>
                  <Col sm={12} className={styles.noMargin}>
                    <span className={styles.listTit}><FormattedMessage {...messages.iofCambio} /> </span>
                    <span className={styles.taxa}>
                      {retorno.Iof !== 'Isento' ? formatNumber(retIOF, { style: 'currency', currency: siglaOrigem }) : 'Isento'}
                    </span>
                  </Col>
                </ListItem>
                <ListItem key={4} notButton>
                  <Col sm={12} xs={12} className={styles.noMargin}>
                    <span className={styles.listTit}><FormattedMessage {...messages.taxaCambio} /></span>
                    <span className={styles.taxa}><FormattedNumber minimumFractionDigits={2} style="currency" currency={siglaOrigem} value={retTaxa} /></span>
                  </Col>
                </ListItem>
                <ListItem key={5} invisibled={!isCalc} notButton>
                  <Col sm={12} className={styles.noMargin}>
                    <span className={styles.listTit}><FormattedMessage {...messages.valorCambio} /></span>
                    <span className={styles.taxa}><FormattedNumber minimumFractionDigits={2} style="currency" currency={siglaOrigem} value={retTotal} /></span>
                  </Col>
                </ListItem>
              </List>
            </Col>
          </Row>
          <Row className={!isCalc && styles.hide}>
            <FlatButton name="btnCambio" className="redButton big centered minCentered" type="button" onMouseUp={handleSubmit} label={formatMessage(messages.submitButton)} />
          </Row>
          <Row className={styles.informative}>
            <List>
              <ListItem key={0} informative icon={iconInfo} notButton autoHeight>
                <span className={styles.textLimites}>{limiteCambio}</span>
              </ListItem>
            </List>
          </Row>
        </form>

      );
    }

    return (
      <div>
        <div className={`${styles.wrapper}`}>
          {content}
        </div>
      </div>
    );
  }
}

CotacaoMoedas.propTypes = {
  handleSubmit: React.PropTypes.func,
  saldosMoedas: React.PropTypes.object,
  moedas: React.PropTypes.object,
  limiteCambio: React.PropTypes.string,
  loading: React.PropTypes.bool,
  handleSelecaoSaldoMoeda: React.PropTypes.func,
  handleSelecaoMoeda: React.PropTypes.func,
  handleSetValor: React.PropTypes.func,
  intl: intlShape.isRequired,
  MoedaOrigemId: React.PropTypes.number,
  MoedaDestinoId: React.PropTypes.number,
  ValorOrigem: React.PropTypes.number,
  ValorDestino: React.PropTypes.number,
  infoOpen: React.PropTypes.bool,
  retCalulaCambioModel: React.PropTypes.object,
  siglasMoedaModel: React.PropTypes.object,
  isCalc: React.PropTypes.bool,
};

export default injectIntl(reduxForm({
  form: 'cotacaoMoeda',
  // validate: validateCotacaoMoedas,
  enableReinitialize: true,
})(CotacaoMoedas));
