import { defineMessages } from 'react-intl';

export default defineMessages({
  header: {
    id: 'app.components.Movimentar.Cambio.CotacaoMoedas.header',
    defaultMessage: 'CÂMBIO',
  },
  loadingMoedas: {
    id: 'app.components.Movimentar.Cambio.CotacaoMoedas.loadingMoedas',
    defaultMessage: 'Carregando as moedas...',
  },
  moedas: {
    id: 'app.components.Movimentar.Cambio.CotacaoMoedas.moedas',
    defaultMessage: 'MINHAS MOEDAS',
  },
  cotacao: {
    id: 'app.components.Movimentar.Cambio.CotacaoMoedas.cotacao',
    defaultMessage: 'FAZER SUA COTAÇÃO',
  },
  cotacaoDe: {
    id: 'app.components.Movimentar.Cambio.CotacaoMoedas.cotacaoDe',
    defaultMessage: 'De:',
  },
  cotacaoPara: {
    id: 'app.components.Movimentar.Cambio.CotacaoMoedas.cotacaoPara',
    defaultMessage: 'Para:',
  },
  taxaCambio: {
    id: 'app.components.Movimentar.Cambio.CotacaoMoedas.taxaCambio',
    defaultMessage: 'TAXA DE CÂMBIO',
  },
  iofCambio: {
    id: 'app.components.Movimentar.Cambio.CotacaoMoedas.iofCambio',
    defaultMessage: 'IOF',
  },
  valorCambio: {
    id: 'app.components.Movimentar.Cambio.CotacaoMoedas.valorCambio',
    defaultMessage: 'TOTAL',
  },
  informative: {
    id: 'app.components.Movimentar.Cambio.CotacaoMoedas.informative',
    defaultMessage: 'LIMITE DÍARIO PARA CÂMBIO:',
  },
  informative2: {
    id: 'app.components.Movimentar.Cambio.CotacaoMoedas.informative2',
    defaultMessage: 'LIMITE DÍARIO PARA CÂMBIO. VEJA COMO FUNCIONA.',
  },
  submitButton: {
    id: 'app.components.Movimentar.Cambio.CotacaoMoedas.submitButton',
    defaultMessage: 'Fazer Câmbio',
  },
});
