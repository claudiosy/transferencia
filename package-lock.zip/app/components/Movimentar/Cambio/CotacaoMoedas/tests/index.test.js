// import Extrato from '../index';
/*
import expect from 'expect';
// import { shallow } from 'enzyme';
// import React from 'react';

describe('<Extrato />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
*/
