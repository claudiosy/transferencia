import React from 'react';
import activeHtml from 'react-active-html';
import { FormattedMessage } from 'react-intl';
import List from 'components/List';
import ListItem from 'components/ListItem';
import messages from './messages';
import iconInfo from 'containers/App/icon-info.png';
import styles from './styles.css';

class AdicionarOutrosBancos extends React.Component { // eslint-disable-line react/prefer-stateless-function
  render() {
    const { handleStepChange, columnSelection, columnOrder, showInformative, bancos, mensagem } = this.props;
    const bancosList = bancos.toJS().map((banco, key) => { // eslint-disable-line arrow-body-style
      return (
        <ListItem name={banco.Sigla} key={key + 1} onClick={() => { handleStepChange(columnOrder, key + 1, banco.Sigla, ''); }}>
          {banco.Nome}
        </ListItem>
      );
    });
    const aviso = (
      <div className={styles.aviso}>
        { activeHtml(mensagem) }
      </div>
    );

    if (showInformative) {
      return (
        <List showProceedIcon showHoverEffect>
          <ListItem key={1} informative icon={iconInfo} showProceedIcon={false} notButton autoHeight>
            <FormattedMessage {...messages.informative} />
          </ListItem>
        </List>
      );
    }

    return (
      <List showProceedIcon showHoverEffect behind={columnSelection !== 0} activeItem={columnSelection}>
        {bancosList}
        {aviso}
      </List>
    );
  }
}

AdicionarOutrosBancos.propTypes = {
  handleStepChange: React.PropTypes.func,
  columnSelection: React.PropTypes.number,
  columnOrder: React.PropTypes.number,
  urlSantander: React.PropTypes.string,
  showInformative: React.PropTypes.bool,
  bancos: React.PropTypes.object,
  mensagem: React.PropTypes.string,
};

export default AdicionarOutrosBancos;
