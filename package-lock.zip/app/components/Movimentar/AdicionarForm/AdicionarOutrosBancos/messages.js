import { defineMessages } from 'react-intl';

export default defineMessages({
  debitoSantander: {
    id: 'app.components.Movimentar.AdicionarForm.AdicionarOutrosBancos.debitoSantander',
    defaultMessage: 'SANTANDER',
  },
  debitoItau: {
    id: 'app.components.Movimentar.AdicionarForm.AdicionarOutrosBancos.debitoItau',
    defaultMessage: 'ITAU',
  },
  debitoBradesco: {
    id: 'app.components.Movimentar.AdicionarForm.AdicionarOutrosBancos.debitoBradesco',
    defaultMessage: 'BRADESCO',
  },
  informative: {
    id: 'app.components.Movimentar.AdicionarForm.AdicionarOutrosBancos.informative',
    defaultMessage: 'Se você conseguiu realizar a transferência com sucesso, o crédito em sua conta Super Digital ocorre após a liberação de seu banco. O prazo estimado é de até quatro horas.',
  },
});
