import React from 'react';
import { reduxForm, Field } from 'redux-form/immutable';
import FlatButton from 'material-ui/FlatButton';
import { /* TextField, */ DatePicker } from 'redux-form-material-ui';
import areIntlLocalesSupported from 'intl-locales-supported';
import List from 'components/List';
import ListItem from 'components/ListItem';

import calendarioIcon from './calendario-icon.png';

import { injectIntl, intlShape } from 'react-intl';
import validateAdicionarBoletoSimula from './validation';

let DateTimeFormat;
/**
 * Use the native Intl.DateTimeFormat if available, or a polyfill if not.
 */
if (areIntlLocalesSupported('pt-BR')) {
  DateTimeFormat = global.Intl.DateTimeFormat;
} else {
  const IntlPolyfill = require('intl'); // eslint-disable-line global-require
  DateTimeFormat = IntlPolyfill.DateTimeFormat;
  require('intl/locale-data/jsonp/pt-BR'); // eslint-disable-line global-require
}

const AdicionarBoletoSimula = props => {
  // eslint-disable-line react/prefer-stateless-function
  const { handleSubmit } = props;

  const minDate = new Date();
  const maxDate = new Date();
  maxDate.setMinutes(minDate.getMinutes() + 86400);

  const content = (
    <form onSubmit={handleSubmit}>
      <List>
        <ListItem key={2} icon={calendarioIcon}>
          <Field
            name="vencimento"
            component={DatePicker}
            hintText="Escolha uma data de vencimento"
            locale="pt-BR"
            cancelLabel="Cancelar"
            okLabel="OK"
            autoOk
            minDate={minDate}
            maxDate={maxDate}
            DateTimeFormat={DateTimeFormat}
            className="commonInput"
            tabIndex="1"
          />
        </ListItem>
      </List>
      <FlatButton
        name="btnSimular"
        className="redButton big centered"
        type="submit"
        label="Continuar"
      />
    </form>
  );

  return <div>{content}</div>;
};

AdicionarBoletoSimula.propTypes = {
  handleSubmit: React.PropTypes.func,
  pristine: React.PropTypes.bool,
  message: React.PropTypes.string,
  submitting: React.PropTypes.bool,
  valor: React.PropTypes.string,
  valorBoleto: React.PropTypes.string,
  vencimento: React.PropTypes.string,
  intl: intlShape.isRequired,
};

export default injectIntl(
  reduxForm({
    form: 'adicionarBoletoSimula',
    validate: validateAdicionarBoletoSimula,
  })(AdicionarBoletoSimula)
);
