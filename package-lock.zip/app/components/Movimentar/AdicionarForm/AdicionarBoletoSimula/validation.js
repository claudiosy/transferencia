import messages from 'containers/App/messages';
import moment from 'moment';

const validateAdicionarBoletoSimula = (valuesFromState, props) => {
  const { formatMessage } = props.intl;
  const errors = {};
  const values = valuesFromState.toJS();

  if (!values.vencimento || values.vencimento.length < 10) {
    errors.vencimento = formatMessage(messages.mandatoryField);
  }
  if (!moment(values.vencimento, 'YYYY-MM-DD').isValid()) {
    errors.vencimento = formatMessage(messages.invalidData);
  }
  return errors;
};

export default validateAdicionarBoletoSimula;
