import React from 'react';
import activeHtml from 'react-active-html';
import { Col } from 'react-flexbox-grid/lib/index';
import { FormattedMessage, injectIntl, intlShape } from 'react-intl';
import messages from './messages';
import List from 'components/List';
import ListItem from 'components/ListItem';
import styles from './styles.css';
import CircularProgress from 'material-ui/CircularProgress';
import adicionarIcon from './adicionar-icon.png';
// import infoIcon from './info-icon.png';

const Deposito = props => {
  const { loading, dadosDeposito, mensagem } = props;

  const aviso = (
    <div className={styles.aviso}>
      { activeHtml(mensagem) }
    </div>
  );

  let content;
  if (loading) {
    content = (
      <List>
        <ListItem key={-3} showProceedIcon={false}>
          <span className={styles.loaderWrapper}>
            <CircularProgress size={0.3} />
          </span>
          <FormattedMessage {...messages.loadingDadosConta} />
        </ListItem>
      </List>
    );
  } else {
    content = (
      <div className={styles.informativoConta}>
        <List>
          <ListItem key={0} icon={adicionarIcon} notButton autoHeight>
            <span><FormattedMessage {...messages.titDeposito} /></span>
          </ListItem>
          <ListItem key={1} notButton autoHeight>
            <FormattedMessage {...messages.informative} />
          </ListItem>
          <ListItem key={2} notButton autoHeight>
            <Col sm={12} className={styles.noMargin}>
              <span className={styles.listTit}><FormattedMessage {...messages.txtBanco} /> </span>
              <span className={styles.value}>
                {dadosDeposito && dadosDeposito.toJS().Banco}
              </span>
            </Col>
          </ListItem>
          <ListItem key={3} notButton autoHeight>
            <Col sm={12} xs={12} className={styles.noMargin}>
              <span className={styles.listTit}><FormattedMessage {...messages.txtAgencia} /></span>
              <span className={styles.value}>
                {dadosDeposito && dadosDeposito.toJS().Agencia}
              </span>
            </Col>
          </ListItem>
          <ListItem key={4} notButton autoHeight>
            <Col sm={12} className={styles.noMargin}>
              <span className={styles.listTit}><FormattedMessage {...messages.txtConta} /></span>
              <span className={styles.value}>
                  {dadosDeposito && dadosDeposito.toJS().Conta}
              </span>
            </Col>
          </ListItem>
          <ListItem key={5} notButton autoHeight>
            <Col sm={12} className={styles.noMargin}>
              <span className={styles.listTit}><FormattedMessage {...messages.txtCPF} /></span>
              <span className={styles.value}>
                {dadosDeposito && dadosDeposito.toJS().CPF}
              </span>
            </Col>
          </ListItem>
          <ListItem key={6} notButton autoHeight>
            {aviso}
          </ListItem>
          <ListItem key={7} notButton autoHeight>
            <FormattedMessage {...messages.informative2} />
          </ListItem>
        </List>
      </div>
    );
  }

  return (
    <div>
      {content}
    </div>
  );
};

Deposito.propTypes = {
  loading: React.PropTypes.bool,
  dadosDeposito: React.PropTypes.object,
  mensagem: React.PropTypes.string,
  intl: intlShape.isRequired,
};

export default injectIntl(Deposito);
