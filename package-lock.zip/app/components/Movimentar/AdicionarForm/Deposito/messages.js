import { defineMessages } from 'react-intl';

export default defineMessages({
  loadingDadosConta: {
    id: 'app.components.Movimentar.AdicionarForm.Deposito.loadingDadosConta',
    defaultMessage: 'Carregando os dados da conta...',
  },
  titDeposito: {
    id: 'app.components.Movimentar.AdicionarForm.Deposito.titDeposito',
    defaultMessage: 'DEPÓSITO',
  },
  informative: {
    id: 'app.components.Movimentar.AdicionarForm.Deposito.informative',
    defaultMessage: 'Você pode depositar $ pelos caixas Santander ou receber transferências de qualquer banco, usando os dados abaixo:',
  },
  informative2: {
    id: 'app.components.Movimentar.AdicionarForm.Deposito.informative2',
    defaultMessage: 'Você não possui uma conta no Santander. Essa é apenas uma conta individual de controle interno para que você ou outra pessoa possa adicionar $ na sua Superdigital, através de depósitos em caixas Santander ou transferências de qualquer banco.',
  },
  txtBanco: {
    id: 'app.components.Movimentar.AdicionarForm.Deposito.txtBanco',
    defaultMessage: 'Banco',
  },
  txtAgencia: {
    id: 'app.components.Movimentar.AdicionarForm.Deposito.txtAgencia',
    defaultMessage: 'Agência',
  },
  txtConta: {
    id: 'app.components.Movimentar.AdicionarForm.Deposito.txtConta',
    defaultMessage: 'Conta',
  },
  txtCPF: {
    id: 'app.components.Movimentar.AdicionarForm.Deposito.txtCPF',
    defaultMessage: 'CPF',
  },
});
