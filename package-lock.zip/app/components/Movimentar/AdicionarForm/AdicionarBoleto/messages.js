import { defineMessages } from 'react-intl';

export default defineMessages({
  labelValor: {
    id: 'superdigital.AdicionarBoleto.labelValor',
    defaultMessage: 'Valor',
  },
  labelVencimento: {
    id: 'superdigital.AdicionarBoleto.labelVencimento',
    defaultMessage: 'Escolha o vencimento',
  },
  submitButton: {
    id: 'superdigital.AdicionarBoleto.submitButton',
    defaultMessage: 'Gerar Boleto',
  },
});
