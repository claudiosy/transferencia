import { defineMessages } from 'react-intl';

export default defineMessages({
  debitoSantander: {
    id: 'app.components.Movimentar.AdicionarForm.AdicionarTipoCarga.debitoSantander',
    defaultMessage: 'DÉBITO SANTANDER',
  },
  debitoOutrosBancos: {
    id: 'app.components.Movimentar.AdicionarForm.AdicionarTipoCarga.debitoOutrosBancos',
    defaultMessage: 'DÉBITO OUTROS BANCOS',
  },
  debitoBancario: {
    id: 'app.components.Movimentar.AdicionarForm.AdicionarTipoCarga.debitoBancario',
    defaultMessage: 'DÉBITO DO SEU BANCO',
  },
  deposito: {
    id: 'app.components.Movimentar.AdicionarForm.AdicionarTipoCarga.deposito',
    defaultMessage: 'DEPÓSITO EM $',
  },
  boleto: {
    id: 'app.components.Movimentar.AdicionarForm.AdicionarTipoCarga.boleto',
    defaultMessage: 'DEPÓSITO EM BOLETO',
  },
  informative: {
    id: 'app.components.Movimentar.AdicionarForm.AdicionarTipoCarga.informative',
    defaultMessage: 'Se você conseguiu realizar a transferência com sucesso, o crédito em sua conta Super Digital ocorre após a liberação de seu banco. O prazo estimado é de até quatro horas.',
  },
});
