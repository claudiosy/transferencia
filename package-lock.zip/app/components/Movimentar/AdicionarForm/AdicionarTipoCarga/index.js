import React from 'react';

import { FormattedMessage } from 'react-intl';
import List from 'components/List';
import ListItem from 'components/ListItem';
import messages from './messages';
import iconInfo from 'containers/App/icon-info.png';

class AdicionarTipoCarga extends React.Component {
  // eslint-disable-line react/prefer-stateless-function
  componentWillMount() {
    document.getElementsByTagName('body')[0].scrollTop = 0;
  }
  render() {
    const {
      handleStepChange,
      handleStepDeposito,
      columnSelection,
      columnOrder,
      showInformative,
    } = this.props;
    if (showInformative) {
      return (
        <List showProceedIcon showHoverEffect>
          <ListItem
            key={1}
            informative
            icon={iconInfo}
            showProceedIcon={false}
            notButton
            autoHeight
          >
            <FormattedMessage {...messages.informative} />
          </ListItem>
        </List>
      );
    }

    return (
      <List
        showProceedIcon
        showHoverEffect
        behind={columnSelection !== 0}
        activeItem={columnSelection}
      >
        <ListItem
          name="debitoBancario"
          key={1}
          onClick={() => handleStepChange(columnOrder, 1, '', '')}
        >
          <FormattedMessage {...messages.debitoBancario} />
        </ListItem>
        <ListItem name="deposito" key={2} onClick={() => handleStepDeposito()}>
          <FormattedMessage {...messages.deposito} />
        </ListItem>
        <ListItem
          name="boleto"
          key={3}
          onClick={() => handleStepChange(2, 4, '', '')}
        >
          <FormattedMessage {...messages.boleto} />
        </ListItem>
      </List>
    );
  }
}

AdicionarTipoCarga.propTypes = {
  handleStepChange: React.PropTypes.func,
  handleStepDeposito: React.PropTypes.func,
  columnSelection: React.PropTypes.number,
  columnOrder: React.PropTypes.number,
  showInformative: React.PropTypes.bool,
};

export default AdicionarTipoCarga;
