import { defineMessages } from 'react-intl';

export default defineMessages({
  title: {
    id: 'app.components.Movimentar.AdicionarForm.AdicionarValor.title',
    defaultMessage: 'Escolha Um Valor:',
  },
  outroValorLabel: {
    id: 'app.components.Movimentar.AdicionarForm.AdicionarValor.outroValorLabel',
    defaultMessage: 'DIGITE UM VALOR',
  },
});
