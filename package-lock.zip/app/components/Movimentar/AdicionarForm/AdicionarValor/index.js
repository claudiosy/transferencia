import React from 'react';
import { connect } from 'react-redux';
import { reduxForm, Field, formValueSelector } from 'redux-form/immutable';
// import { Grid, Row, Col } from 'react-flexbox-grid/lib/index';
import { injectIntl, intlShape, FormattedMessage } from 'react-intl';
import { TextField } from 'redux-form-material-ui';
import List from 'components/List';
import ListItem from 'components/ListItem';
import styles from './styles.css';
import realIcon from 'containers/App/real-icon.png';
import timeIcon from 'containers/App/history-icon.png';
import tecladoIcon from './teclado-icon.png';
import { normalizeDecimal } from 'normalizers';
import messages from './messages';

class AdicionarValor extends React.Component {
  // eslint-disable-line react/prefer-stateless-function
  constructor() {
    super();
    this.state = { proceedVisible: false };
    this.handleCustomValue = this.handleCustomValue.bind(this);
    this.handleProceedVisibility = this.handleProceedVisibility.bind(this);
  }
  showBoletoCLick = () => {
    const { isHistoricoEnabled } = this.props;
    if (!isHistoricoEnabled) return;
    this.props.handleShowHistoricoBoleto(true);
  };
  handleValueClick(columnOrder, selectionColumn, valor) {
    this.valueDisabled = true;
    this.props.handleStepChange(columnOrder, selectionColumn);
    this.props.handleSetValor(valor, valor.toFixed(2).replace('.', ','));
  }
  handleCustomValue(event, columnOrder) {
    if (event.target.value) {
      this.props.handleStepChange(columnOrder, 4);
      this.props.handleSetValor(
        event.target.value
          .replace(',', '|')
          .replace('.', '')
          .replace('|', '.'),
        event.target.value
      );
    }
  }
  handleProceedVisibility(event) {
    this.setState({ proceedVisible: event.target.value && true });
  }
  render() {
    const { columnSelection, columnOrder, isHistoricoEnabled } = this.props;
    const { formatMessage } = this.props.intl;
    // const valueDisabled = false;
    return (
      <List
        showProceedIcon
        showHoverEffect
        behind={columnSelection !== 0}
        activeItem={columnSelection}
      >
        <h4 className="list-title">
          <FormattedMessage {...messages.title} />
        </h4>
        <ListItem
          name="add20"
          key={1}
          icon={realIcon}
          onClick={() => this.handleValueClick(columnOrder, 1, 20)}
        >
          <span className={styles.btValor}>20,00</span>
        </ListItem>
        <ListItem
          name="add100"
          key={2}
          icon={realIcon}
          onClick={() => this.handleValueClick(columnOrder, 2, 100)}
        >
          <span className={styles.btValor}>100,00</span>
        </ListItem>
        <ListItem
          name="add200"
          key={3}
          icon={realIcon}
          onClick={() => this.handleValueClick(columnOrder, 3, 200)}
        >
          <span className={styles.btValor}>200,00</span>
        </ListItem>
        <ListItem
          name="addOutroValor"
          key={4}
          icon={tecladoIcon}
          showProceedIcon={this.state.proceedVisible}
        >
          <Field
            autoFocus
            name="valor"
            component={TextField}
            hintText={formatMessage(messages.outroValorLabel)}
            normalize={normalizeDecimal}
            type="tel"
            // disabled={this.valueDisabled}
            onBlur={event => {
              this.handleCustomValue(event, columnOrder);
            }}
            onKeyUp={event => {
              this.handleProceedVisibility(event);
              if (event.keyCode === 13) {
                this.handleCustomValue(event, columnOrder);
              }
            }}
            tabIndex="1"
          />
        </ListItem>
        <ListItem
          className={!isHistoricoEnabled ? styles.listDisabled : ''}
          name="historico"
          key={5}
          icon={timeIcon}
          onClick={this.showBoletoCLick}
        >
          <span className={!isHistoricoEnabled ? styles.listDisabled : ''}>HISTÓRICO DE BOLETOS</span>
        </ListItem>
      </List>
    );
  }
}

AdicionarValor.propTypes = {
  handleStepChange: React.PropTypes.func,
  handleSetValor: React.PropTypes.func,
  columnSelection: React.PropTypes.number,
  columnOrder: React.PropTypes.number,
  intl: intlShape.isRequired,
  handleShowHistoricoBoleto: React.PropTypes.func,
  isHistoricoEnabled: React.PropTypes.bool,
};

const selector = formValueSelector('adicionarValorForm');
export default connect(state => {
  const valorAtual = selector(state, 'valor');
  return {
    valorAtual,
  };
})(
  injectIntl(
    reduxForm({
      form: 'adicionarValorForm',
    })(AdicionarValor)
  )
);
