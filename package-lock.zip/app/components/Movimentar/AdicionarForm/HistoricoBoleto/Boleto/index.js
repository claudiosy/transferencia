import React from 'react';
import FlatButton from 'material-ui/FlatButton';
import Card from 'material-ui/Card';
import Divider from 'material-ui/Divider';
import IconCheck from 'material-ui/svg-icons/action/check-circle';
import IconClose from 'material-ui/svg-icons/navigation/close';
import IconTime from 'material-ui/svg-icons/device/access-time';

import saveIcon from './save-icon.png';
import copyIcon from './copy-icon.png';
import mailIcon from './email-icon.png';

import { injectIntl, intlShape } from 'react-intl';
import styles from './styles.css';
import { Snackbar, IconButton } from 'material-ui';

/* eslint-disable no-script-url */

class Boleto extends React.Component {
  // eslint-disable-line react/prefer-stateless-function
  static defaultProp = {
    dadosComprovante: [
      {
        Data: null,
        DataVenc: null,
        Barras: null,
        Valor: null,
        Pdf: null,
        Custo: null,
        Situacao: null,
      },
    ],
  };

  constructor() {
    super();
    this.state = {
      snackbarCopiar: false,
      snackbarEmail: false,
    };
  }

  copyToClipboard = codBarras => {
    const dummy = document.createElement('input');
    document.body.appendChild(dummy);
    dummy.setAttribute('value', codBarras);
    dummy.select();
    document.execCommand('copy');
    document.body.removeChild(dummy);
    this.showCopiarSnackbar();
  };

  showEmailSnackbar = () => {
    this.setState({ snackbarCopiar: false, snackbarEmail: true });
  };

  showCopiarSnackbar = () => {
    this.setState({ snackbarCopiar: true, snackbarEmail: false });
  };

  handleClose = (e, reason) => {
    if (reason === 'clickaway') return;
    this.setState({ snackbarCopiar: false });
  };

  assembleSituacao = situacao => {
    switch (situacao) {
      case 'Pago':
        return (
          <div>
            <IconCheck className={styles.iconGreen} />
            <span className={`${styles.title} ${styles.text}`}>
              Boleto Pago
            </span>
          </div>
        );
      case 'Pendente':
        return (
          <div>
            <IconTime className={styles.iconOrange} />
            <span className={`${styles.title} ${styles.text}`}>
              Aguardando Pagamento
            </span>
          </div>
        );
      case 'Vencido':
        return (
          <div>
            <IconClose className={styles.iconRed} />
            <span className={`${styles.title} ${styles.text}`}>
              Boleto Vencido
            </span>
          </div>
        );
      default:
        return null;
    }
  };

  render = () => {
    const {
      Data,
      DataVenc,
      Barras,
      Valor,
      Pdf,
      Custo,
      Situacao,
    } = this.props.dados[0];

    const { handleSendEmail } = this.props;

    const textoSuperior = `${styles.blockTitle} ${styles.textSm} ${
      styles.textLight
    }`;
    const textoInferior = `${styles.blockTitle} ${styles.textMd} ${
      styles.text
    }`;
    let footer;
    if (Situacao === 'Pendente') {
      footer = (
        <table>
          <tr>
            <td width="50%">
              <FlatButton
                type="button"
                label="Copiar"
                onClick={() => this.copyToClipboard(Barras)}
              >
                <img src={copyIcon} alt="Copiar o código de barras" />
              </FlatButton>
              <Snackbar
                style={{ left: '24px', bottom: '78px' }}
                bodyStyle={{ margin: 0, fontSize: '42px' }}
                open={this.state.snackbarCopiar}
                autoHideDuration={6000}
                onClose={this.handleClose}
                message={<span>Código de Barras copiado!</span>}
                action={
                  <IconButton
                    style={{ transform: 'translateY(-15%)', color: '#ffffff' }}
                    key="close"
                    aria-label="close"
                    onClick={this.handleClose}
                  >
                    <IconClose color="#ffffff" />
                  </IconButton>
                }
              />
            </td>
            <td>
              <a href={Pdf}>
                <FlatButton type="button" label="Salvar">
                  <img src={saveIcon} alt="Salvar PDF em seu computador" />
                </FlatButton>
              </a>
            </td>
          </tr>
          <tr>
            <td>
              <FlatButton
                onClick={() => {
                  handleSendEmail();
                  this.showEmailSnackbar();
                }}
                type="button"
                label="Enviar por email"
              >
                <img src={mailIcon} alt="Enviar link para email" />
              </FlatButton>
              <Snackbar
                style={{ left: '24px', bottom: '78px' }}
                bodyStyle={{ margin: 0, fontSize: '42px' }}
                open={this.state.snackbarEmail}
                autoHideDuration={6000}
                onClose={this.handleClose}
                message={<span>Emai enviado!</span>}
                action={
                  <IconButton
                    style={{ transform: 'translateY(-15%)', color: '#ffffff' }}
                    key="close"
                    aria-label="close"
                    onClick={this.handleClose}
                  >
                    <IconClose color="#ffffff" />
                  </IconButton>
                }
              />
            </td>
            <td />
          </tr>
        </table>
      );
    }

    return (
      <div id="boleto">
        <div className={`${styles.defaultMargin} ${styles.spacer}`}>
          <span className={`${styles.textTop} ${styles.blockTitle}`}>
            DEPÓSITO EM BOLETO
          </span>
          <span className={`${styles.blockTitle} ${styles.textBottom}`}>
            Boleto {Data}
          </span>
        </div>
        <Card className={`${styles.defaultMargin} ${styles.cardPadding}`}>
          <div className={`${styles.spacer}`}>
            {this.assembleSituacao(Situacao)}
          </div>
          <Divider className={`${styles.spacer}`} />
          <div className={`${styles.spacer}`}>
            <span className={textoSuperior}>Codigo de Barras</span>
            <span className={textoInferior}>{Barras}</span>
          </div>
          <div className={`${styles.spacer}`}>
            <div className={`${styles.divLeft}`}>
              <span className={textoSuperior}>Pagar Ate</span>
              <span className={textoInferior}>{DataVenc}</span>
            </div>
            <div className={`${styles.divRight}`}>
              <span className={textoSuperior}>Taxa de emissao</span>
              <span className={textoInferior}>{Custo}</span>
            </div>
          </div>
          <Divider className={`${styles.spacer}`} />
          <div className={styles.flexBox}>
            <span className={textoSuperior}>Valor do boleto</span>
            <span className={`${textoInferior} ${styles.textXl}`}>{Valor}</span>
          </div>
          {footer}
        </Card>
      </div>
    );
  };
}

Boleto.propTypes = {
  pristine: React.PropTypes.bool,
  handleClick: React.PropTypes.func,
  dadosComprovante: React.PropTypes.object,
  intl: intlShape.isRequired,
  dados: React.PropTypes.object,
  handleSendEmail: React.PropTypes.func,
};

export default injectIntl(Boleto);
