import React from 'react';

import Divider from 'material-ui/Divider';
import { injectIntl } from 'react-intl';
import styles from './styles.css';

import IconBack from 'material-ui/svg-icons/hardware/keyboard-arrow-left';
import IconButton from 'material-ui/IconButton';
import IconWarning from 'material-ui/svg-icons/alert/warning';

import ListaBoleto from './Lista/ListaBoleto';
import Boleto from './Boleto';

/* eslint-disable no-script-url */

class HistoricoBoleto extends React.Component {
  static defaultProps = {
    dadosHistorico: null,
  };

  // eslint-disable-line react/prefer-stateless-function
  constructor() {
    super();
    this.state = {
      selectedBoleto: null,
    };
  }

  componentDidUpdate = () => {
    this.props.handleSetEmailId(this.state.selectedBoleto[0].ID);
  }

  clickHandle = idBoleto => {
    const selectedBoleto = this.props.dadosHistorico.boletos.filter(
      ({ ID }) => ID === idBoleto
    );
    this.setState({
      selectedBoleto,
    }, () => this.props.handleSetEmailId(this.state.selectedBoleto[0].ID));
  };

  buildLegenda = () => {};

  handleGoBack = () => {
    this.setState({
      selectedBoleto: null,
    });
  };

  render = () => {
    const { dadosHistorico, handleSendEmail } = this.props;

    let content;

    if (dadosHistorico == null) {
      content = (
        <div className={`${styles.avisoBox}`}>
          <IconWarning className={`${styles.avisoIcon}`} />
          <span className={`${styles.avisoText}`}>
            Não foi possível acessar o histórico
          </span>
        </div>
      );
    } else if (
      this.state.selectedBoleto === null &&
      dadosHistorico.boletos.length > 0
    ) {
      // render lista
      content = (
        <div>
          <span> {this.buildLegenda()} </span>
          <ListaBoleto
            clickHandle={this.clickHandle}
            dadosHistorico={dadosHistorico.boletos}
          />
          <Divider />
          <span> {`Total a Pagar: ${dadosHistorico.totalPendente}`} </span>
        </div>
      );
    } else if (this.state.selectedBoleto !== null) {
      content = <Boleto handleSendEmail={handleSendEmail} dados={this.state.selectedBoleto} />;
    } else if (dadosHistorico.boletos.length <= 0) {
      content = (
        <div className={`${styles.avisoBox}`}>
          <IconWarning className={`${styles.avisoIcon}`} />
          <span className={`${styles.avisoText}`}>
            Não há histórico a ser mostrado
          </span>
        </div>
      );
    }

    return (
      <div className={`${styles.defaultMargin}`}>
        <div className={`${styles.flexBox}`}>
          <IconButton
            onClick={this.handleGoBack}
            style={{
              display: this.state.selectedBoleto == null ? 'none' : 'inherit',
            }}
          >
            <IconBack className={`${styles.iconBack}`} />
          </IconButton>
          <span className={`${styles.text} ${styles.textXxl}`}>
            Histórico de boletos
          </span>
        </div>
        <Divider /> {content}
      </div>
    );
  };
}

HistoricoBoleto.propTypes = {
  dadosHistorico: React.PropTypes.object,
  handleSendEmail: React.PropTypes.func,
  handleSetEmailId: React.PropTypes.func,
};

export default injectIntl(HistoricoBoleto);
