import React from 'react';

import { injectIntl } from 'react-intl';

import IconCheck from 'material-ui/svg-icons/action/check-circle';
import IconClose from 'material-ui/svg-icons/navigation/close';
import IconTime from 'material-ui/svg-icons/device/access-time';
import IconProceed from 'material-ui/svg-icons/hardware/keyboard-arrow-right';

import List from 'material-ui/List/List';
import ListItem from 'material-ui/List/ListItem';

import styles from './styles.css';
class ListaBoleto extends React.Component {
  static defaultProps = {
    dadosHistorico: [],
  };

  componentDidMount = () => {};
  buildIcon = situacao => {
    switch (situacao) {
      case 'Pendente':
        return <IconTime className={`${styles.iconTime}`} />;
      case 'Vencido':
        return <IconTime className={`${styles.iconClose}`} />;
      case 'Erro':
        return <IconClose className={`${styles.iconClose}`} />;
      case 'Não Autorizado':
        return <IconClose className={`${styles.iconClose}`} />;
      case 'Cancelado':
        return <IconClose className={`${styles.iconClose}`} />;
      case 'Pago':
        return <IconCheck className={`${styles.iconCheck}`} />;
      default:
        return null;
    }
  };

  buildList = () => {
    if (this.props.dadosHistorico) {
      return this.props.dadosHistorico.map(
        ({ DataVenc, Situacao, ID, Valor }) => (
          <ListItem onClick={() => this.props.clickHandle(ID)}>
            <div className={`${styles.listItem}`}>
              {this.buildIcon(Situacao)}
              <span
                className={`${styles.text}`}
              >{`${DataVenc} - ${Situacao} - ${Valor}`}</span>
              <IconProceed className={`${styles.iconProceed}`} />
            </div>
          </ListItem>
        )
      );
    }
    return null;
  };

  render = () => (
    <div>
      <List>{this.buildList()}</List>
    </div>
  );
}

ListaBoleto.propTypes = {
  dadosHistorico: React.PropTypes.object,
  clickHandle: React.PropTypes.func,
};

export default injectIntl(ListaBoleto);
