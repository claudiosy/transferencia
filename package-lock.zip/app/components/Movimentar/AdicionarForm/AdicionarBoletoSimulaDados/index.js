import React from 'react';
import { reduxForm } from 'redux-form/immutable';
import FlatButton from 'material-ui/FlatButton';

import styles from './styles.css';

import clockIcon from './time-grey-icon.png';
import rightIcon from './boleto-icon.png';

import { injectIntl, intlShape } from 'react-intl';
import validateAdicionarBoletoSimulaDados from './validation';

const AdicionarBoletoSimulaDados = props => {
  // eslint-disable-line react/prefer-stateless-function
  const { handleSubmit, dados } = props;

  const content = (
    <form className={styles.form} onSubmit={handleSubmit}>
      <p className={styles.title}> DEPÓSITO EM BOLETO </p>
      <p className={styles.subTitle}>
        Está tudo certo com as suas informações ?
      </p>

      <div className={styles.card}>
        <div className={styles.flexBox}>
          <img src={rightIcon} alt="boleto" />
          <span className={styles.boletoTitulo}>Boleto Bancário</span>
        </div>
        <p className={styles.divider} />
        <div className={`${styles.flexBox} ${styles.flexBoxJustify}`}>
          <div>
            <span className={styles.subtituloClaro}> Pagar até </span>
            <span className={styles.subtitulo}> {dados.Data} </span>
          </div>
          <div>
            <span className={styles.subtituloClaro}>Taxa de emissão</span>
            <span className={styles.subtitulo}> {dados.Taxa} </span>
          </div>
        </div>
        <p className={styles.observacao}>{dados.Observacao}</p>
        <p className={styles.divider} />
        <div className={`${styles.flexBox} ${styles.flexBoxJustify}`}>
          <span className={styles.subtituloClaro}>Valor do boleto</span>
          <div className={styles.flexBox}>
            <span className={styles.moeda}> R$ </span>
            <span className={styles.valor}> {dados.Valor} </span>
          </div>
        </div>
      </div>

      <br />
      <br />
      <table>
        <tr>
          <td width="70%" />
          <td width="30%">
            <FlatButton
              name="btnSimular"
              className="redButton"
              type="submit"
              label="Confirmar"
            />
          </td>
        </tr>
      </table>
      <br />
      <img src={clockIcon} role="presentation" />
      <span>
        Após a realização do pagamento, o dinheiro leva até 2 dias úteis para
        cair na sua conta
      </span>
    </form>
  );

  return <div> {content} </div>;
};

AdicionarBoletoSimulaDados.propTypes = {
  handleSubmit: React.PropTypes.func,
  pristine: React.PropTypes.bool,
  message: React.PropTypes.string,
  submitting: React.PropTypes.bool,
  dados: React.PropTypes.object,
  intl: intlShape.isRequired,
};

export default injectIntl(
  reduxForm({
    form: 'adicionarBoletoSimulaDados',
    validate: validateAdicionarBoletoSimulaDados,
  })(AdicionarBoletoSimulaDados)
);
