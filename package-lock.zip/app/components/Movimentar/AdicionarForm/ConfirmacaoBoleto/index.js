import React from 'react';
import { Grid } from 'react-flexbox-grid/lib/index';
import FlatButton from 'material-ui/FlatButton';

import { injectIntl, intlShape } from 'react-intl';
import messages from './messages';
import styles from './styles.css';

import saveIcon from './save-icon.png';

/* eslint-disable no-script-url */

const ConfirmacaoBoleto = props => { // eslint-disable-line react/prefer-stateless-function
  const { handleClick, dadosComprovante } = props;
  const { codBarras, strValor } = dadosComprovante.toJS();
  const { formatMessage } = props.intl;

  return (
    <div className={styles.formWrapper}>
      <Grid fluid>
        <div className={styles.topo}>
          <span className={styles.data}>14 Out</span>
        </div>
        <div className={styles.confirmacao}>
          <div className={styles.groupRow}>
            <span className={styles.titulo}>CONFIRMAÇÃO <span className={styles.hora}>4:16 PM</span></span>
            <div className={styles.sep}>
              <span className={styles.moeda}>R$</span><span className={styles.valor}>{strValor}</span>
            </div>
          </div>
          <div className={styles.groupRow}>
            <div className={styles.itemRow}>
              <span className={styles.subtituloClaro}>CÓDIGO DE BARRAS</span>
              <span className={styles.subtitulo}>{codBarras}</span>
            </div>
          </div>
          <div className={styles.groupRow}>
            <div className={styles.itemRow}>
              <span className={styles.subtituloClaro}>CTRL</span>
              <span className={styles.subtitulo}>45221</span>
            </div>
            <div>
              <span className={styles.subtituloClaro}>AUTENTICAÇÃO</span>
              <span className={styles.subtitulo}>742585</span>
            </div>
          </div>
          <div className={styles.lastGroupRow}>
            <FlatButton type="button" label={formatMessage(messages.ButtonCopiar)} onClick={() => handleClick()} >
              <img src={saveIcon} alt="" />
            </FlatButton>
          </div>
        </div>
      </Grid>
    </div>);
};

ConfirmacaoBoleto.propTypes = {
  pristine: React.PropTypes.bool,
  handleClick: React.PropTypes.func,
  dadosConfirmacao: React.PropTypes.object,
  intl: intlShape.isRequired,
  dadosComprovante: React.PropTypes.object,
};

export default injectIntl(ConfirmacaoBoleto);
