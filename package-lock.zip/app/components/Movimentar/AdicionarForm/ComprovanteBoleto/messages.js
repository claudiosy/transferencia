import { defineMessages } from 'react-intl';

export default defineMessages({
  header: {
    id: 'app.components.Movimentar.AdicionarForm.ComprovanteBoleto.header',
    defaultMessage: 'Comprovante',
  },
  ButtonCopiar: {
    id: 'app.components.Movimentar.AdicionarForm.ComprovanteBoleto.ButtonCopiar',
    defaultMessage: 'COPIAR CÓDIGO',
  },
});
