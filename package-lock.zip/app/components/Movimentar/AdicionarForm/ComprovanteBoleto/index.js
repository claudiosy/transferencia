import React from 'react';
import FlatButton from 'material-ui/FlatButton';
import Snackbar from 'material-ui/Snackbar';

import { injectIntl, intlShape } from 'react-intl';
import styles from './styles.css';

import saveIcon from './save-icon.png';
import copyIcon from './copy-icon.png';
import mailIcon from './email-icon.png';
import clockIcon from './time-grey-icon.png';
import rightIcon from './time-sucess-icon.png';
import { IconButton } from 'material-ui';

import CloseIcon from 'material-ui/svg-icons/navigation/close';

/* eslint-disable no-script-url */

// eslint-disable-next-line react/prefer-stateless-function
class ComprovanteBoleto extends React.Component {
  constructor() {
    super();
    this.state = {
      snackbarCopiar: false,
      snackbarEmail: false,
    };
  }

  handleClose = (e, reason) => {
    if (reason === 'clickaway') return;
    this.setState({ snackbarCopiar: false, snackbarEmail: false });
  };

  copyToClipboard = codBarras => {
    const dummy = document.createElement('input');
    document.body.appendChild(dummy);
    dummy.setAttribute('value', codBarras);
    dummy.select();
    document.execCommand('copy');
    document.body.removeChild(dummy);
    this.showCopiarSnackbar();
  };

  showEmailSnackbar = () => {
    this.setState({ snackbarCopiar: false, snackbarEmail: true });
  };

  showCopiarSnackbar = () => {
    this.setState({ snackbarCopiar: true, snackbarEmail: false });
  };

  render = () => {
    const { dadosComprovante, handleSendEmail } = this.props;
    const {
      codBarras,
      strValor,
      taxa,
      validade,
      Pdf,
    } = dadosComprovante.toJS();

    return (
      <div className={styles.formWrapper}>
        <div className={styles.comprovante}>
          <div className={styles.groupRow}>
            <p className={styles.boletoTitulo}> Depósito em Boleto </p>
            <div className={styles.card}>
              <div
                className={styles.flexBox}
                style={{
                  alignContents: 'center',
                }}
              >
                <img
                  className={styles.iconBoleto}
                  src={rightIcon}
                  alt="boleto"
                />
                <span className={styles.boleto}> Boleto gerado! </span>
              </div>
              <p className={styles.divider} />
              <div className={`${styles.flexBox}`}>
                <div>
                  <span className={styles.subtituloClaro}>
                    Código de Barras
                  </span>
                  <span className={styles.subtitulo}> {codBarras} </span>
                </div>
              </div>
              <div className={`${styles.flexBox}`}>
                <div className={styles.marginMd}>
                  <span className={styles.subtituloClaro}> Pagar até </span>
                  <span className={styles.subtitulo}> {validade} </span>
                </div>
                <div>
                  <span className={styles.subtituloClaro}>Taxa de emissão</span>
                  <span className={styles.subtitulo}> {taxa} </span>
                </div>
              </div>
              <p className={styles.divider} />
              <div className={`${styles.flexBox} ${styles.flexBoxJustify}`}>
                <span className={styles.subtituloClaro}> Valor do boleto </span>
                <div className={styles.flexBox}>
                  <span className={styles.moeda}> R$ </span>
                  <span className={styles.valor}> {strValor} </span>
                </div>
              </div>
            </div>
            <div className={styles.lastGroupRow}>
              <p className={styles.deseja}> O que deseja fazer ? </p>
              <table>
                <tr>
                  <td width="50%">
                    <FlatButton
                      type="button"
                      label="Copiar código"
                      onClick={() => this.copyToClipboard(codBarras)}
                    >
                      <img src={copyIcon} alt="Copiar o código de barras" />
                    </FlatButton>
                    <Snackbar
                      style={{ left: '142px', bottom: '24px' }}
                      bodyStyle={{ margin: 0, fontSize: '42px' }}
                      open={this.state.snackbarCopiar}
                      autoHideDuration={6000}
                      onClose={this.handleClose}
                      message={<span>Código de Barras copiado!</span>}
                      action={
                        <IconButton
                          style={{ transform: 'translateY(-15%)', color: '#ffffff' }}
                          key="close"
                          aria-label="close"
                          onClick={this.handleClose}
                        >
                          <CloseIcon color="#ffffff" />
                        </IconButton>
                      }
                    />
                  </td>
                  <td>
                    <a href={Pdf}>
                      <FlatButton type="button" label="Salvar">
                        <img
                          src={saveIcon}
                          alt="Salvar PDF em seu computador"
                        />
                      </FlatButton>
                    </a>
                  </td>
                </tr>
                <tr>
                  <td>
                    <FlatButton onClick={() => { handleSendEmail(); this.showEmailSnackbar(); }} type="button" label="Enviar por email">
                      <img src={mailIcon} alt="Enviar link para email" />
                    </FlatButton>
                    <Snackbar
                      style={{ left: '142px', bottom: '24px' }}
                      bodyStyle={{ margin: 0, fontSize: '42px' }}
                      open={this.state.snackbarEmail}
                      autoHideDuration={6000}
                      onClose={this.handleClose}
                      message={<span>Emai enviado!</span>}
                      action={
                        <IconButton
                          style={{ transform: 'translateY(-15%)', color: '#ffffff' }}
                          key="close"
                          aria-label="close"
                          onClick={this.handleClose}
                        >
                          <CloseIcon color="#ffffff" />
                        </IconButton>
                      }
                    />
                  </td>
                  <td />
                </tr>
              </table>
              <br />
              <p className={styles.pagamento}>
                <img
                  className={styles.relogio}
                  src={clockIcon}
                  role="presentation"
                />
                Após a realização do pagamento, o dinheiro leva até 2 dias úteis
                para cair na sua conta
              </p>
            </div>
          </div>
        </div>
      </div>
    );
  };
}

ComprovanteBoleto.propTypes = {
  pristine: React.PropTypes.bool,
  handleClick: React.PropTypes.func,
  handleSendEmail: React.PropTypes.func,
  dadosComprovante: React.PropTypes.object,
  intl: intlShape.isRequired,
};

export default injectIntl(ComprovanteBoleto);
