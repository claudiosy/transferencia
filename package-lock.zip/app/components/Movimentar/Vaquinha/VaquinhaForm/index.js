import React from 'react';
import { reduxForm } from 'redux-form/immutable';
import moment from 'moment';
import List from 'components/List';
import ListItem from 'components/ListItem';
import CircularProgress from 'material-ui/CircularProgress';
import validateVaquinha from './validation';

import { injectIntl, intlShape, FormattedMessage, FormattedNumber } from 'react-intl';
import messages from './messages';
import styles from './styles.css';

import vaquinhaIcon from './vaquinha-icon.png';
import racharIcon from './rachar-icon.png';
import vaquinhaImg from 'containers/App/vaquinha-icon.png';
import racharImg from 'containers/App/rachar-icon.png';
import calendarioIcon from './calendario-icon.png';
import dolarIcon from './dolar-icon.png';
import personIcon from 'containers/App/person-icon.png';

const VaquinhaForm = props => { // eslint-disable-line react/prefer-stateless-function
  const { loading, message, dadosVaquinhaModel, pagamentosModel } = props;
  const { Tipo, CobrarAte, Valor, Imagem, Nome } = dadosVaquinhaModel.toJS();
  const tipoGrupo = Tipo === 1 ? 'Dividir' : 'Vaquinha';
  const DataTermino = moment(new Date(CobrarAte)).format('DD/MM/YYYY');
  const Foto = Imagem !== null ? (<img src={Imagem} className={styles.imgFoto} alt="" />) : (<img src={Tipo === 1 ? racharImg : vaquinhaImg} alt="" />);
  let valores = '';
  let valorArrecadado = 0;
  let ParticipantesPagos = 0;

  valores = (<div><span className={styles.rigthValor}><FormattedNumber minimumFractionDigits={2} style="currency" currency="BRL" value={Valor} /></span></div>);

  for (let i = 0; i < pagamentosModel.toJS().length; i++) {
    valorArrecadado += pagamentosModel.toJS()[i].ValorPago;
    ParticipantesPagos += pagamentosModel.toJS()[i].ValorPago != null ? 1 : 0;
  }

  let content;

  if (message) {
    content = (<h2>{message}</h2>);
  } else if (loading) {
    content = (
      <List showProceedIcon={false} showHoverEffect>
        <ListItem key={-3} showProceedIcon={false}>
          <span className={styles.loaderWrapper}>
            <CircularProgress size={0.3} />
          </span>
          <FormattedMessage {...messages.loadingDetalhes} />
        </ListItem>
      </List>
    );
  } else {
    content = (
      <form>
        <List>
          <ListItem key={1} notButton showProceedIcon={false} autoHeight>
            <div className={styles.divFoto}>{Foto}</div>
          </ListItem>
          <ListItem key={2} icon={Tipo === 1 ? racharIcon : vaquinhaIcon} notButton showProceedIcon={false}>
            <h4 className={styles.nomeGrupo}>{Nome}</h4>
            <p className={styles.tipoGrupo}>{tipoGrupo}</p>
            {valores}
          </ListItem>
          <ListItem key={3} icon={calendarioIcon} notButton showProceedIcon={false}>
            <div><FormattedMessage {...messages.labelData} /></div>
            <div>{DataTermino}</div>
          </ListItem>
          <ListItem key={4} icon={personIcon} notButton showProceedIcon={false}>
            <div>{pagamentosModel.toJS().length + 1} <FormattedMessage {...messages.labelParticipantes} /></div>
          </ListItem>
          <ListItem key={5} icon={dolarIcon} notButton showProceedIcon={false}>
            <h4 className={styles.nomeGrupo}><FormattedMessage {...messages.labelValorArrecadado} /></h4>
            <p className={styles.tipoGrupo}>{ParticipantesPagos} <FormattedMessage {...messages.labelParticipantes} /></p>
            <div><FormattedNumber style="currency" currency="BRL" value={valorArrecadado} /></div>
          </ListItem>
        </List>
      </form>
    );
  }
  return (
    <div className={styles.formWrapper}>
      {content}
    </div>);
};

VaquinhaForm.propTypes = {
  handleStepChange: React.PropTypes.func,
  pristine: React.PropTypes.bool,
  loading: React.PropTypes.bool,
  message: React.PropTypes.string,
  submitting: React.PropTypes.bool,
  columnSelection: React.PropTypes.number,
  columnOrder: React.PropTypes.number,
  grupos: React.PropTypes.object,
  intl: intlShape.isRequired,
  dadosVaquinhaModel: React.PropTypes.object,
  pagamentosModel: React.PropTypes.object,
};

export default injectIntl(reduxForm({
  form: 'vaquinhaForm',
  validate: validateVaquinha,
  enableReinitialize: true,
})(VaquinhaForm));
