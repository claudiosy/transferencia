import { defineMessages } from 'react-intl';

export default defineMessages({
  loadingDetalhes: {
    id: 'app.components.Movimentar.Vaquinha.VaquinhaForm.loadingDetalhes',
    defaultMessage: 'Carregando detalhes da vaquinha...',
  },
  labelData: {
    id: 'app.components.Movimentar.Vaquinha.VaquinhaForm.labelData',
    defaultMessage: 'Data de Término',
  },
  labelValorArrecadado: {
    id: 'app.components.Movimentar.Vaquinha.VaquinhaForm.labelValorArrecadado',
    defaultMessage: 'Valor Arrecadado',
  },
  labelParticipantes: {
    id: 'app.components.Movimentar.Vaquinha.VaquinhaForm.labelParticipantes',
    defaultMessage: 'Participante(s)',
  },
});
