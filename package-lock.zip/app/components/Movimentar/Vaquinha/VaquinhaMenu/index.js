import React from 'react';

import List from 'components/List';
import ListItem from 'components/ListItem';
import CircularProgress from 'material-ui/CircularProgress';
import messages from './messages';

import styles from './styles.css';
import { FormattedNumber, FormattedMessage, intlShape } from 'react-intl';

import vaquinhaIcon from 'containers/App/vaquinha-icon.png';
import racharIcon from 'containers/App/rachar-icon.png';
import iconInfo from 'containers/App/icon-info.png';

function renderChildren(names, props) {
  return names.map((grupos) => {
    const tipoGrupo = grupos.Tipo === 1 ? 'Dividir' : 'Vaquinha';
    let valores = '';
    const miniFoto = grupos.Imagem !== null ? (<img src={grupos.Imagem} className={styles.leftIcon} alt="" />) : (<img src={grupos.Tipo === 1 ? racharIcon : vaquinhaIcon} className={styles.leftIcon} alt="" />);

    valores = (<div><span className={styles.rigthValor}><FormattedNumber style="decimal" minimumFractionDigits={2} value={grupos.Valor} /></span><span className={styles.rigthMoeda}>R$ </span></div>);

    if (grupos.Nome.toLowerCase().indexOf(props.buscaNome ? props.buscaNome.toLowerCase() : '') !== -1) {
      return (
        <ListItem showProceedIcon={false} key={grupos.Identificacao} id={grupos.Identificacao} onClick={() => props.handleClick(props.columnOrder, grupos.Identificacao, grupos.Identificacao, grupos.Nome, grupos.Imagem, grupos.Tipo, grupos.Valor, grupos.CobrarAte, grupos.Pagamentos)} className={styles.listaGrupos}>
          {miniFoto}
          <h4 className={styles.nomeGrupo}>{grupos.Nome}</h4>
          <p className={styles.tipoGrupo}>{tipoGrupo}</p>
          {valores}
        </ListItem>
      );
    }

    return null;
  });
}

const VaquinhaMenu = props => { // eslint-disable-line react/prefer-stateless-function
  const { loading, message, columnSelection, grupos } = props;

  let content;

  if (message) {
    content = (<h2>{message}</h2>);
  } else if (loading) {
    content = (
      <List showProceedIcon={false} showHoverEffect behind={columnSelection !== 0} activeItem={columnSelection}>
        <ListItem key={-3} showProceedIcon={false}>
          <span className={styles.loaderWrapper}>
            <CircularProgress size={0.3} />
          </span>
          <FormattedMessage {...messages.loadingRachamento} />
        </ListItem>
      </List>
    );
  } else if (grupos.length !== 0) {
    content = (
      <div>
        <List showProceedIcon={false} showHoverEffect behind={columnSelection !== 0} activeItem={columnSelection}>
          {renderChildren(grupos, props)}
        </List>
      </div>
    );
  } else {
    content = (
      <List showProceedIcon={false} behind={columnSelection !== 0} activeItem={columnSelection}>
        <ListItem key={1} icon={iconInfo} notButton showProceedIcon={false}>
          <FormattedMessage {...messages.semVaquinha} />
        </ListItem>
      </List>
    );
  }

  return (
    <div>
      {content}
    </div>);
};

VaquinhaMenu.propTypes = {
  pristine: React.PropTypes.bool,
  loading: React.PropTypes.bool,
  message: React.PropTypes.string,
  submitting: React.PropTypes.bool,
  columnOrder: React.PropTypes.number,
  columnSelection: React.PropTypes.number,
  grupos: React.PropTypes.object,
  intl: intlShape.isRequired,
  handleClick: React.PropTypes.func,
  buscaNome: React.PropTypes.string,
};

export default VaquinhaMenu;
