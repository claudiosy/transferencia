import { defineMessages } from 'react-intl';

export default defineMessages({
  loadingRachamento: {
    id: 'app.components.Movimentar.Vaquinha.VaquinhaMenu.loadingRachamento',
    defaultMessage: 'Carregando vaquinhas...',
  },
  labelBusca: {
    id: 'app.components.Movimentar.Vaquinha.VaquinhaMenu.labelBusca',
    defaultMessage: 'Buscar Vaquinha',
  },
  semVaquinha: {
    id: 'app.components.Movimentar.Vaquinha.VaquinhaMenu.semVaquinha',
    defaultMessage: 'Você ainda não participou de nenhuma vaquinha',
  },
});
