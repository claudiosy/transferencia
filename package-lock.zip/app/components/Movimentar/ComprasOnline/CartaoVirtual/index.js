import React from 'react';
import List from 'components/List';
import ListItem from 'components/ListItem';
import { Row, Col } from 'react-flexbox-grid/lib/index';
import { reduxForm } from 'redux-form/immutable';
import styles from './styles.css';
import messages from './messages';
import { FormattedMessage, injectIntl, intlShape } from 'react-intl';
// import Logo from './logo.png';
import cardSegurancaIcon from './cod-seguranca.png';
import comprasOnlineIcon from 'components/SideMenu/compras-online.png';
import moment from 'moment';

function CartaoVirtual(props) {
  const { dadosCartao } = props;
  const { formatMessage } = props.intl;

  const criadoEm = moment(new Date(dadosCartao.MembroDesde)).format('MM/YY');
  const validoAte = moment(new Date(dadosCartao.DataValidade)).format('MM/YY');

  return (
    // eslint-disable-next-line react/jsx-boolean-value
    <div className={styles.tituloModulo}>
      <List>
        <ListItem key={0} notButton>
          <span><FormattedMessage {...messages.cardDigital} /></span>
        </ListItem>
      </List>
      <div className={styles.mainCard}>
        <Row center="xs">
          <Col sm={12} md={12} xs={12}>
            <Row>
              <Col sm={11} md={5} xs={12}>
                <div className={styles.contentCard}>
                  <div style={{ backgroundImage: `url(${cardSegurancaIcon})` }} className={styles.codImg}>
                    <span className={styles.numCod}>{dadosCartao.CodigoSeguranca}</span>
                  </div>
                  <div className={styles.DetalhesCard}>
                    <span>{dadosCartao.Nome}</span>
                    <span><img src={comprasOnlineIcon} className={styles.icon} alt="" />{dadosCartao.Apelido}</span>
                    <span className={styles.numeroCard}>{dadosCartao.Numero}</span>
                  </div>
                  <div className={styles.ValidadeCard}>
                    <span>{formatMessage(messages.validade)} {validoAte}</span>
                  </div>
                </div>
              </Col>
              <Col sm={1} className="hidden-xs hidden-sm">
              </Col>
              <Col sm={11} md={6} xs={12}>
                <div className={styles.dadosCard}>
                  <div className={styles.itemDados}>
                    <span className={styles.titulo}>{formatMessage(messages.criadoEm)}</span>
                    <span className={styles.descricao}>{criadoEm}</span>
                  </div>
                  <div className={styles.itemDados}>
                    <span className={styles.titulo}>{formatMessage(messages.validoAte)}</span>
                    <span className={styles.descricao}>{validoAte}</span>
                  </div>
                  <div className={`${styles.itemDados}`}>
                    <span className={styles.titulo}>{formatMessage(messages.codSeguranca)}</span>
                    <span className={styles.descricao}>{dadosCartao.CodigoSeguranca}</span>
                  </div>
                </div>
              </Col>
            </Row>
          </Col>
        </Row>
      </div>
    </div>
  );
}

CartaoVirtual.propTypes = {
  dadosCartao: React.PropTypes.object,
  columnSelection: React.PropTypes.number,
  columnOrder: React.PropTypes.number,
  intl: intlShape.isRequired,
};

export default injectIntl(reduxForm({
  form: 'cartaoVirtualForm',
})(CartaoVirtual));
