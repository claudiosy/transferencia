import { defineMessages } from 'react-intl';

export default defineMessages({
  cardDigital: {
    id: 'app.components.Movimentar.ComprasOnline.CartaoVirtual.cardDigital',
    defaultMessage: 'CARTÃO VIRTUAL',
  },
  criadoEm: {
    id: 'app.components.Movimentar.ComprasOnline.CartaoVirtual.criadoEm',
    defaultMessage: 'DESDE',
  },
  validoAte: {
    id: 'app.components.Movimentar.ComprasOnline.CartaoVirtual.validoAte',
    defaultMessage: 'VÁLIDO ATÉ',
  },
  codSeguranca: {
    id: 'app.components.Movimentar.ComprasOnline.CartaoVirtual.codSeguranca',
    defaultMessage: 'CÓDIGO DE SEGURANÇA',
  },
  validade: {
    id: 'app.components.Movimentar.ComprasOnline.CartaoVirtual.validade',
    defaultMessage: 'VALIDADE',
  },
});
