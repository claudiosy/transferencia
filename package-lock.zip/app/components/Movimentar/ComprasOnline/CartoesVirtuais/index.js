import React from 'react';
import { CardStack } from 'react-cardstack';
import List from 'components/List';
import ListItem from 'components/ListItem';
import { reduxForm } from 'redux-form/immutable';
import styles from './styles.css';
import messages from './messages';
import { FormattedMessage, injectIntl, intlShape } from 'react-intl';
import CircularProgress from 'material-ui/CircularProgress';
import Card from 'components/Organizar/Cartoes/Card';
import ContentCard from 'components/Organizar/Cartoes/ContentCard';

function CartoesVirtuais(props) {
  const { handleToggle, handleStepChange, columnSelection, columnOrder, cartoes, loading } = props;
  let counter = 1;
  const background = '#5400a3';
  // const background = 'linear-gradient(45deg, rgba(84,0,163,1) 0%, rgba(84,0,163,1) 48%, rgba(16,141,187,1) 100%)'
  let contendCards = '';
  let cardSpace = -80;
  let cartoesList = cartoes && cartoes.toJS().length && cartoes.toJS().map((cartao) => { // eslint-disable-line prefer-const
    counter++;
    cardSpace += 80;
    return (
      <Card
        key={counter}
        background={background}
        handleStepChange={handleStepChange}
        columnOrder={columnOrder}
        cartaoId={cartao.CartaoId}
        cardType={cartao.TipoIndividualizacaoId}
        cardIsBlocked={cartao.StatusCartao === '20'}
        isHover
        cardSpace={cardSpace}
      >
        <ContentCard dadosCartao={cartao} handleToggle={handleToggle} />
      </Card>
    );
  });
  counter++;
  // const altura = 127; // 320
  const espacamento = 122;
  if (loading) {
    contendCards = (
      <List showProceedIcon showHoverEffect behind={columnSelection !== 0} activeItem={columnSelection}>
        <ListItem key={-3} showProceedIcon={false}>
          <span className={styles.loaderWrapper}>
            <CircularProgress size={0.3} />
          </span>
          <FormattedMessage {...messages.loadingCards} />
        </ListItem>
      </List>
    );
  } else if (cartoesList && cartoesList.length > 1) {
    contendCards = (
      <div className={`${styles.cardsWrapper} ${columnSelection === -1 ? styles.testeBehind : ''}`} style={{ height: `${(cartoesList.length * 80) + 140}px` }}>
        <CardStack
          height={202}
          width={400}
          hoverOffset={espacamento}
        >
          {cartoesList}
        </CardStack>
      </div>
    );
  } else if (cartoesList && cartoesList.length === 1) {
    contendCards = (
      <div className={`${styles.cardsWrapper} ${columnSelection === -1 ? styles.testeBehind : ''}`} style={{ height: `${(cartoesList.length * 80) + 140}px` }}>
        <ul className={styles.cardsUnique}>
          {cartoesList}
        </ul>
      </div>
    );
  } else {
    contendCards = (
      <List>
        <ListItem key={0} showProceedIcon={false}>
          <FormattedMessage {...messages.notCards} />
        </ListItem>
      </List>
    );
  }
  return (
    // eslint-disable-next-line react/jsx-boolean-value
    <div>
      <div className={styles.pageBg}>
        {contendCards}
      </div>
    </div>
  );
}

CartoesVirtuais.propTypes = {
  loading: React.PropTypes.bool,
  cartoes: React.PropTypes.object,
  columnSelection: React.PropTypes.number,
  columnOrder: React.PropTypes.number,
  handleStepChange: React.PropTypes.func,
  handleToggle: React.PropTypes.func,
  intl: intlShape.isRequired,
};

export default injectIntl(reduxForm({
  form: 'cartoesVirtuaisForm',
})(CartoesVirtuais));
