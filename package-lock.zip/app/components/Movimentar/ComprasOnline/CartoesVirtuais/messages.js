import { defineMessages } from 'react-intl';

export default defineMessages({
  loadingCards: {
    id: 'app.components.Movimentar.ComprasOnline.CartoesVirtuais.loadingCards',
    defaultMessage: 'Carregando os seus cartões...',
  },
  notCards: {
    id: 'app.components.Movimentar.ComprasOnline.CartoesVirtuais.notCards',
    defaultMessage: 'Você não possui nenhum cartão virtual.',
  },
});
