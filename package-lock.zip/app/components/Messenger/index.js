import React from 'react';
import List from 'components/List';
import ListItem from 'components/ListItem';

import isMobile from 'utils/isMobile';

import ChatbotWindow from 'components/ChatbotWindow';

import { connect } from 'react-redux';
import { createStructuredSelector } from 'reselect';
import { injectIntl, intlShape } from 'react-intl';
import { selectChatMessages } from 'containers/App/selectors';
import { appendChatMessage } from 'containers/App/actions';
import messages from './messages';

import styles from './styles.css';
import avatar from './avatar.png';


function Messenger(props) {
  const { chatMessages, handleAppendChatMessage, chatOpen } = props;
  const { formatMessage } = props.intl;
  const title = chatOpen ? (
    ''
  ) : (
    <List showHoverEffect>
      <ListItem key={1}>
        <img src={avatar} role="presentation" />
        <p className={styles.contactName}>{formatMessage(messages.labelSupportContact)}</p>
        <p className={styles.lastMessage}></p>
        <span className={styles.timeStamp}></span>
      </ListItem>
    </List>
  );

  let content = (
    <div className={styles.messenger}>
      {title}
      <ChatbotWindow visible chatMessages={chatMessages} onAppendMessage={handleAppendChatMessage} chatOpen={chatOpen} />
    </div>);

  if (!isMobile()) {
    content = (<div className={`${styles.bg} outside`}></div>);
  }

  return (content);
}

Messenger.propTypes = {
  intl: intlShape.isRequired,
  chatOpen: React.PropTypes.bool,
};

const mapStateToProps = createStructuredSelector({
  chatMessages: selectChatMessages(),
});

function mapDispatchToProps(dispatch) {
  return {
    handleAppendChatMessage: (from, message, at) => {
      dispatch(appendChatMessage(from, message, at));
    },
    dispatch,
  };
}


export default connect(mapStateToProps, mapDispatchToProps)(injectIntl(Messenger));
