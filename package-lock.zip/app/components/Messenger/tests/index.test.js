// import Messenger from '../index';
/*
import expect from 'expect';
// import { shallow } from 'enzyme';
// import React from 'react';

describe('<Messenger />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
*/
