import { defineMessages } from 'react-intl';

export default defineMessages({
  labelSupportContact: {
    id: 'superdigital.Messenger.labelSupportContact',
    defaultMessage: 'Assistente Superdigital',
  },
});
