import React from 'react';
import { connect } from 'react-redux';
import { push } from 'react-router-redux';
import { createStructuredSelector } from 'reselect';
import { Row, Col } from 'react-flexbox-grid/lib/index';
import FlatButton from 'material-ui/FlatButton';
import isMobile from 'utils/isMobile';

import styles from './styles.css';
import closeIcon from 'containers/App/close.png';
import backIcon from 'containers/App/prev-icon.png';

function Breadcrumb(props) {
  const { handleClose, titleImagePath, titleDescription, handleBackButtonClick, showBackButton, className, disableButtons } = props;
  let iconOrBackButton = null;

  if (showBackButton) {
    iconOrBackButton = (
      <FlatButton name="btnBack" className={styles.backButton} onMouseUp={handleBackButtonClick}>
        <img src={backIcon} alt="" />
      </FlatButton>);
  } else {
    iconOrBackButton = (
      <div className={styles.imgTitle}>
        <img src={titleImagePath} alt="" role="presentation" />
      </div>);
  }

  return (
    <Row className={`${styles.breadcrumb} ${className}`}>
      <Col sm={3} xs={11}>
        {iconOrBackButton}
        <div className={styles.title}>{titleDescription}</div>
      </Col>
      <Col sm={5} xs={1} className={styles.contentBar}>
        <div className={styles.content}>
          {React.Children.toArray(props.children)}
        </div>
        <FlatButton name="btnClose" className={styles.closeButton} onMouseUp={handleClose} disabled={disableButtons}>
          <img src={closeIcon} alt="" />
        </FlatButton>
      </Col>
      <Col sm={4} className={isMobile() && styles.hidden}>
      </Col>
    </Row>
  );
}

Breadcrumb.propTypes = {
  handleClose: React.PropTypes.func,
  handleBackButtonClick: React.PropTypes.func,
  showBackButton: React.PropTypes.bool,
  children: React.PropTypes.node,
  titleImagePath: React.PropTypes.string,
  titleDescription: React.PropTypes.string,
  className: React.PropTypes.string,
  disableButtons: React.PropTypes.bool,
};

const mapStateToProps = createStructuredSelector({});

function mapDispatchToProps(dispatch) {
  return {
    handleClose: () => {
      dispatch(push('/dashboard'));
    },
    dispatch,
  };
}

export default connect(mapStateToProps, mapDispatchToProps)(Breadcrumb);
