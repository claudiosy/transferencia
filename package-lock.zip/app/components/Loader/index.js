import React from 'react';

import loader from 'containers/App/loading-s.gif';
import styles from './styles.css';

function Loader(props) {
  const { top, left, type, childStyle } = props;
  const style = childStyle || { top: `${top || 'calc(50% - 28px)'}`, left: `${left || ''}` };
  return (
    <div className={styles.modalMain} {...props}>
      <div
        className={`${childStyle ? styles.mobile : null} ${styles.loader} ${!type && styles.regular} `}
        style={{ style }}
      >
        {type && <img style={{ style }} src={loader} alt="" role="presentation" />}
      </div>
    </div>
  );
}

Loader.propTypes = {
  top: React.PropTypes.oneOfType([
    React.PropTypes.string,
    React.PropTypes.number,
  ]),
  left: React.PropTypes.oneOfType([
    React.PropTypes.string,
    React.PropTypes.number,
  ]),
  type: React.PropTypes.string,
  childStyle: React.PropTypes.object,
};

export default Loader;
