/**
*
* Alert
*
*/

import React from 'react';
import FlatButton from 'material-ui/FlatButton';
import { Row, Col } from 'react-flexbox-grid/lib/index';

import { injectIntl, intlShape } from 'react-intl';
import messages from './messages';

import styles from './styles.css';

class Alert extends React.Component {
  constructor() {
    super();
    this.state = { visible: true };
    this.handleClick = this.handleClick.bind(this);
  }
  componentWillMount() {
    this.setState({ message: this.message });
  }
  componentWillReceiveProps(nextProps) {
    if (this.props.message !== nextProps.message || this.props.title !== nextProps.title) {
      this.setState({ visible: true });
    }
  }
  handleClick() {
    this.setState({ visible: false });
  }
  handleConfirmClick() {
    this.handleClick();
    if (this.props.onConfirmClick) {
      this.props.onConfirmClick();
    }
  }
  handleCancelClick() {
    this.handleClick();
    if (this.props.onCancelClick) {
      this.props.onCancelClick();
    }
  }
  render() {
    const { type, title, message, needWrapper, altStyle, solidOverlay, labelButtonAlert } = this.props;
    const { visible } = this.state;
    const { formatMessage } = this.props.intl;

    if (message === '' || message == null || message === undefined || message.size === 0) return null;
    if (message.toString() === 'Error: Not Found') { return null; }
    if (message.toString() === 'TypeError: Failed to fetch') { return null; }

    let button;
    let button2;
    let bodyAlert;

    if (message) {
      if (typeof message === 'string') {
        bodyAlert = (<p className={styles.alertMessage}>{message}</p>);
      } else {
        bodyAlert = message.map((item) => { // eslint-disable-line arrow-body-style
          return (
            <p className={styles.alertMessage}>{item.toString()}</p>
          );
        });
      }
    }
    if (!type || type === 'alert') {
      button = (<FlatButton name="btnOK" className={`redButton negative ${styles.alertButton}`} label={!labelButtonAlert ? formatMessage(messages.alertOkButton) : formatMessage(labelButtonAlert)} onMouseUp={() => this.handleConfirmClick()} />);
    } else if (type === 'confirm') {
      button = (<FlatButton name="btnYes" className={`redButton negative ${styles.alertButton} ${styles.alertButtonTwo}`} label={formatMessage(messages.alertYesButton)} onMouseUp={() => this.handleConfirmClick()} />);
      button2 = (<FlatButton name="btnCancel" className={`redButton negative ${styles.alertButton} ${styles.alertButtonTwo}`} label={formatMessage(messages.alertCancelButton)} onMouseUp={() => this.handleCancelClick()} />);
    }

    let content = (
      <div className={`${styles.alertOverlay} ${altStyle && styles.altStyle} ${solidOverlay && styles.solid} ${visible && (message && message.length) && styles.visible}`}>
        <div name="divAlert" className={`${styles.alertPopup} ${altStyle && styles.altStyle} ${type === 'confirm' && styles.alertConfirm}`}>
          <h4 className={styles.alertTitle}>{title || formatMessage(messages.defaultTitle)}</h4>
          {bodyAlert}
          {button}
          {button2}
        </div>
      </div>
    );

    if (needWrapper) {
      content = (
        <Row className={`${styles.alertWrapper} ${visible && (message && message.length) && styles.visible}`}>
          <Col sm={8} className={styles.wrapper}>
            {content}
          </Col>
        </Row>
      );
    }

    return (content);
  }
}

Alert.propTypes = {
  onConfirmClick: React.PropTypes.func,
  onCancelClick: React.PropTypes.func,
  type: React.PropTypes.string,
  title: React.PropTypes.string,
  visible: React.PropTypes.bool,
  needWrapper: React.PropTypes.bool,
  altStyle: React.PropTypes.bool,
  solidOverlay: React.PropTypes.bool,
  intl: intlShape.isRequired,
  labelButtonAlert: React.PropTypes.string,
  message: React.PropTypes.object,
};

export default injectIntl(Alert);
