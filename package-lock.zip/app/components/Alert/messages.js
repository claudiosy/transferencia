/*
 * Alert Messages
 *
 * This contains all the text for the Alert component.
 */
import { defineMessages } from 'react-intl';

export default defineMessages({
  alertOkButton: {
    id: 'superdigital.Alert.alertOkButton',
    defaultMessage: 'OK',
  },
  alertYesButton: {
    id: 'superdigital.Alert.alertYesButton',
    defaultMessage: 'Sim',
  },
  alertCancelButton: {
    id: 'superdigital.Alert.alertCancelButton',
    defaultMessage: 'Cancelar',
  },
  alertFecharButton: {
    id: 'superdigital.Alert.alertFecharButton',
    defaultMessage: 'Fechar',
  },
  defaultTitle: {
    id: 'superdigital.Alert.defaultTitle',
    defaultMessage: 'Atenção!',
  },
});
