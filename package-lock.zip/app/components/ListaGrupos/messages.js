import { defineMessages } from 'react-intl';

export default defineMessages({
  header: {
    id: 'superdigital.ListaGrupos.header',
    defaultMessage: 'Lista de Grupos',
  },
});
