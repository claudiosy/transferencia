import React from 'react';
import List from 'components/List';
import ListItem from 'components/ListItem';
import CircularProgress from 'material-ui/CircularProgress';

import styles from './styles.css';
import { FormattedNumber } from 'react-intl';

import avatarIcon from './avatar.png';
import vaquinhaIcon from 'containers/App/groups-icon.png';
import racharIcon from 'containers/App/value-icon.png';
import chatIcon from 'containers/App/close.png';

function renderChildren(names, props) {
  return names.map((grupos) => {
    let iconGrupo = '';
    let tipoGrupo = '';
    let valores = '';
    const miniFoto = grupos.urlFoto !== '' ? (<img src={grupos.urlFoto} className={styles.leftIcon} alt="" />) : (<img src={avatarIcon} className={styles.leftIcon} alt="" />);

    if (grupos.tipo === 1) {
      tipoGrupo = 'Vaquinha';
      iconGrupo = (<img src={vaquinhaIcon} className={styles.iconGrupo} alt="" />);
      valores = (<span className={styles.rigthValor}><FormattedNumber minimumFractionDigits={2} style="currency" currency="BRL" value={grupos.valor} /></span>);
    } else if (grupos.tipo === 2) {
      tipoGrupo = 'Dividir';
      iconGrupo = (<img src={racharIcon} className={styles.iconGrupo} alt="" />);
      valores = (<span className={styles.rigthValor}><FormattedNumber minimumFractionDigits={2} style="currency" currency="BRL" value={grupos.valor} /></span>);
    } else if (grupos.tipo === 3) {
      tipoGrupo = 'Conversar';
      iconGrupo = (<img src={chatIcon} className={styles.iconGrupo} alt="" />);
      valores = (<span className={styles.rigthValor}>{grupos.qtdeAmigos} Amigos</span>);
    }

    return (
      <ListItem key={grupos.id} id={grupos.id} onClick={() => props.handleGroupClick(grupos.id, grupos.nome, grupos.urlFoto, grupos.tipo, grupos.valor)} className={styles.listaGrupos}>
        {miniFoto}
        <h4 className={styles.nomeGrupo}>{grupos.nome}</h4>
        <p className={styles.tipoGrupo}>{tipoGrupo}</p>
        {iconGrupo}
        {valores}
      </ListItem>
    );
  });
}

const ListaGrupos = props => { // eslint-disable-line react/prefer-stateless-function
  const { loading, message, grupos } = props;

  let content;

  if (message) {
    content = (<h2>{message}</h2>);
  } else if (loading) {
    content = (<div><CircularProgress /></div>);
  } else {
    content = (
      <List>
        {renderChildren(grupos, props)}
      </List>
    );
  }
  return (content);
};

ListaGrupos.propTypes = {
  pristine: React.PropTypes.bool,
  loading: React.PropTypes.bool,
  message: React.PropTypes.string,
  grupos: React.PropTypes.object,
};

export default ListaGrupos;
