import React from 'react';
import { reduxForm, Field, change, formValueSelector } from 'redux-form/immutable';
import { createStructuredSelector } from 'reselect';
import { connect } from 'react-redux';
import { TextField } from 'redux-form-material-ui';
import { injectIntl, intlShape } from 'react-intl';
import { Row, Col } from 'react-flexbox-grid/lib/index';
import FlatButton from 'material-ui/FlatButton';
import FloatingActionButton from 'material-ui/FloatingActionButton';
import ConfirmMosaicValue from 'components/ConfirmMosaicValue';
import Alert from 'components/Alert';

import messages from './messages';

import styles from './styles.css';
import lowerS from './lower-s.png';
// import lowerSAnimated from './lower-s-animated.png';
// import lowerSanimated from './lower-s-animated.png';
import upperS from './upper-s.png';
import grid from './grid.png';
import arrow from './arrow.png';
import clearIcon from 'containers/App/close.png';
import loaderS from 'containers/App/loading-s.gif';

import { selectBalanceData } from 'containers/BalancePanel/selectors';

class ConfirmMosaic extends React.Component {
  constructor() {
    super();
    this.handleCheckFunds = this.handleCheckFunds.bind(this);
  }
  handleCheckFunds(valor, saldo, saldoCardSelected) {
    if (valor > saldo) {
      this.props.handleInsufficientFunds(saldoCardSelected);
      return;
    }
    this.props.onConfirm();
  }
  render() {
    const effectDuration = 3000;
    const { formatMessage } = this.props.intl;
    const {
      transactionValue,
      transactionLabelDone,
      transactionToLabelDone,
      transactionToName,
      // onConfirm,
      onFinish,
      onClose,
      picture,
      loading,
      done,
      currencySymbol,
      LancamentoId,
      balanceData,
      messageState,
      clearState,
      saldoCardSelected,
    } = this.props;
    let {
      transactionLabel,
      transactionToLabel,
    } = this.props;

    const picTo = picture ? (<img className={styles.picTo} src={picture} role="presentation" />) : '';
    let interaction = null;

    let displayTransactionValue = (<ConfirmMosaicValue className={styles.transactionValue} currency={currencySymbol || 'R$'} value={transactionValue} />);
    let displayTransactionToValue = (<ConfirmMosaicValue className={styles.transactionToName} value={transactionToName} />);

    transactionLabel = transactionLabel || formatMessage(messages.defaultTransactionLabel);
    transactionToLabel = transactionToLabel || formatMessage(messages.defaultTransactionToLabel);

    const simbolo = currencySymbol || 'R$';
    const saldo = !saldoCardSelected && saldoCardSelected !== 0 ? balanceData.toJS().filter((moeda) => { // eslint-disable-line arrow-body-style
      return moeda.Simbolo === simbolo;
    })[0].Valor : saldoCardSelected;

    if (done) {
      interaction = (<FloatingActionButton className={styles.okButton} label={formatMessage(messages.okButtonLabel)} onMouseUp={() => onFinish(LancamentoId)}>
        <span>{formatMessage(messages.okButtonLabel)}</span>
      </FloatingActionButton>);

      transactionLabel = transactionLabelDone || formatMessage(messages.defaultTransactionLabelDone);
      transactionToLabel = transactionToLabelDone || formatMessage(messages.defaultTransactionToLabelDone);

      displayTransactionValue = (<ConfirmMosaicValue className={styles.transactionValue} value={0} animateFrom={transactionValue} effectDuration={effectDuration} currency={currencySymbol || 'R$'} displayWhenDone />);
      displayTransactionToValue = (<ConfirmMosaicValue className={`${styles.transactionToName} ${styles.wValue}`} value={transactionValue} animateFrom={0} effectDuration={effectDuration} currency={currencySymbol || 'R$'} />);
    } else if (loading) {
      interaction = (<div className={`${styles.proceedButton} ${styles.wLoading}`}>
        <span className={styles.redDot}>●</span> <span>{formatMessage(messages.loading)}</span>
      </div>);
    } else {
      interaction = (<FlatButton name="btnContinuarTransferir" className={styles.proceedButton} type="button" label={formatMessage(messages.proceedButtonLabel)} onMouseUp={() => this.handleCheckFunds(transactionValue, saldo, saldoCardSelected)}>
        <img src={arrow} role="presentation" />
      </FlatButton>);
    }

    return (
      <Row>
        <Col sm={8} className={styles.wrapper}>
          <Field component={TextField} className="iptHidden" name="Message" type="hidden" underlineShow={false} />
          <FlatButton name="btnFechar" className={styles.closeButton} onMouseUp={onClose} >
            <img src={clearIcon} alt="" />
          </FlatButton>
          <div className={styles.presentationDataLeft}>
            <div className={styles.transactionName}>{transactionLabel}</div>
            {displayTransactionValue}
          </div>
          <div className={styles.presentationDataRight}>
            <div className={styles.transactionTo}>{transactionToLabel}</div>
            {displayTransactionToValue}
          </div>
          {interaction}
          {!loading && <img className={`${styles.upperS} ${done && styles.static}`} src={upperS} role="presentation" />}
          {!loading && <img className={`${styles.lowerS} ${done && styles.static}`} src={lowerS} role="presentation" />}
          {loading && <img src={loaderS} className={styles.loaderS} role="presentation" alt="" />}
          <div className={styles.mosaicLeft}></div>
          <div className={`${styles.mosaicRight} ${picTo ? styles.wGrid : ''}`}>
            <div className={styles.grid} style={{ backgroundImage: `url(${grid})` }}></div>
            {picTo}
          </div>
          <Alert message={messageState} onConfirmClick={clearState} />
        </Col>
      </Row>
    );
  }
}

ConfirmMosaic.propTypes = {
  transactionToName: React.PropTypes.string,
  transactionLabel: React.PropTypes.string,
  transactionLabelDone: React.PropTypes.string,
  transactionValue: React.PropTypes.number,
  transactionToLabel: React.PropTypes.string,
  transactionToLabelDone: React.PropTypes.string,
  onConfirm: React.PropTypes.func,
  onFinish: React.PropTypes.func,
  onClose: React.PropTypes.func,
  picture: React.PropTypes.string,
  loading: React.PropTypes.bool,
  done: React.PropTypes.bool,
  currencySymbol: React.PropTypes.string,
  intl: intlShape.isRequired,
  LancamentoId: React.PropTypes.number,
  balanceData: React.PropTypes.object,
  handleInsufficientFunds: React.PropTypes.func,
  messageState: React.PropTypes.string,
  clearState: React.PropTypes.func,
  saldoCardSelected: React.PropTypes.number,
};

const mapStateToProps = createStructuredSelector({
  balanceData: selectBalanceData(),
});

function mapDispatchToProps(dispatch) {
  return {
    handleInsufficientFunds: (saldoCardSelected) => {
      dispatch(change('confirmMosaicForm', 'Message', !saldoCardSelected && saldoCardSelected !== 0 ? 'Você não tem saldo suficiente. Carregue sua conta para continuar.' : 'O saldo no cartão é inferior ao valor de resgate.'));
    },
    clearState: () => {
      dispatch(change('confirmMosaicForm', 'Message', ''));
    },
    dispatch,
  };
}

const selector = formValueSelector('confirmMosaicForm');

ConfirmMosaic = connect( // eslint-disable-line
  state => {
    const messageState = selector(state, 'Message');
    return {
      messageState,
    };
  }
)(ConfirmMosaic);

export default connect(mapStateToProps, mapDispatchToProps)(injectIntl(reduxForm({
  form: 'confirmMosaicForm',
})(ConfirmMosaic)));
