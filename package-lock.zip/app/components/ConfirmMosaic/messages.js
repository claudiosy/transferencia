/*
 * ConfirmMosaic Messages
 *
 * This contains all the text for the ConfirmMosaic component.
 */
import { defineMessages } from 'react-intl';

export default defineMessages({
  proceedButtonLabel: {
    id: 'superdigital.components.ConfirmMosaic.proceedButtonLabel',
    defaultMessage: 'clique aqui para continuar',
  },
  okButtonLabel: {
    id: 'superdigital.components.ConfirmMosaic.okButtonLabel',
    defaultMessage: 'OK',
  },
  defaultTransactionLabel: {
    id: 'superdigital.components.ConfirmMosaic.defaultTransactionLabel',
    defaultMessage: 'Enviar',
  },
  defaultTransactionLabelDone: {
    id: 'superdigital.components.ConfirmMosaic.defaultTransactionLabelDone',
    defaultMessage: 'Envio completo',
  },
  defaultTransactionLabelLoading: {
    id: 'superdigital.components.ConfirmMosaic.defaultTransactionLabelLoading',
    defaultMessage: 'Enviando...',
  },
  defaultTransactionToLabel: {
    id: 'superdigital.components.ConfirmMosaic.defaultTransactionToLabel',
    defaultMessage: 'Para',
  },
  defaultTransactionToLabelDone: {
    id: 'superdigital.components.ConfirmMosaic.defaultTransactionToLabelDone',
    defaultMessage: 'Valor recebido',
  },
  loading: {
    id: 'superdigital.components.ConfirmMosaic.loading',
    defaultMessage: 'Aguarde...',
  },
});
