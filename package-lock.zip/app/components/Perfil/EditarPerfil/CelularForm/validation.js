import messages from 'containers/App/messages';

const validateCelularForm = (valuesFromState, props) => {
  const { formatMessage } = props.intl;
  const errors = {};
  const values = valuesFromState.toJS();

  if (!values.Telefone || values.Telefone.length < 15) {
    errors.Telefone = formatMessage(messages.mandatoryField);
  }

  return errors;
};

export default validateCelularForm;
