import React from 'react';
import { reduxForm, Field, change, formValueSelector } from 'redux-form/immutable';
import { connect } from 'react-redux';
import { TextField } from 'redux-form-material-ui';
import FlatButton from 'material-ui/FlatButton';
import { injectIntl, intlShape, FormattedMessage } from 'react-intl';
import Dropzone from 'react-dropzone';
import messages from './messages';
import Loader from 'components/Loader';
import { Row, Col } from 'react-flexbox-grid/lib/index';
import List from 'components/List';
import ListItem from 'components/ListItem';
import validateCelularForm from './validation';
import styles from './styles.css';
import iconConfirm from 'containers/App/confirm-icon.png';
import iconInfo from 'containers/App/icon-info.png';
import { normalizeCelular } from 'normalizers';

class CelularForm extends React.Component {
  constructor() {
    super();
    this.state = {
      arquivoSelfie: null,
    };
    this.onDrop = this.onDrop.bind(this);
  }
  onDrop(files, name) {
    const file = files[0];
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = () => {
      const fileInfo = {
        thumb: file.preview,
        base64: reader.result,
      };
      const obj = {};
      obj[name] = fileInfo;
      this.setState(obj);
      this.props.handleSetSelfie(fileInfo.base64);
    };
  }
  render() {
    const { handleSubmit, pristine, submitting, loading } = this.props;
    const { formatMessage } = this.props.intl;
    const { arquivoSelfie } = this.state;
    let content = (
      <form onSubmit={handleSubmit} className={styles.celularForm}>
        <Field component={TextField} className="iptHidden" name="Selfie" type="hidden" value={arquivoSelfie && arquivoSelfie.base64} underlineShow={false} />
        <Field component={TextField} className="iptHidden" name="Email" type="hidden" underlineShow={false} />
        <List>
          <ListItem key={1}>
            <Field autoFocus name="Telefone" component={TextField} className={`${styles.inputCel} redInput wFloatingLabel`} floatingLabelText={formatMessage(messages.hintCelular)} type="tel" normalize={normalizeCelular} format={normalizeCelular} tabIndex="1" />
          </ListItem>
          <ListItem key={2} autoHeight>
            <Dropzone accept="image/*" onDrop={(event) => this.onDrop(event, 'arquivoSelfie')} className={styles.dropzone} activeClassName={styles.dropzoneActive} maxSize="2097152">
              <div className={`${styles.preview} ${!arquivoSelfie && styles.bg}`}>
                <div style={{ backgroundImage: `url(${iconConfirm})` }} className={`${arquivoSelfie && styles.block} ${styles.hide} ${styles.confirImg} `}></div>
                <img className={`${arquivoSelfie && styles.block} ${styles.hide} `} src={arquivoSelfie && arquivoSelfie.thumb} role="presentation" />
              </div>
              <div className={styles.lblTit}><FormattedMessage {...messages.hintSelfie} /></div>
              <div className={styles.lblButton}><FormattedMessage {...messages.dropArquivoRG} /></div>
            </Dropzone>
          </ListItem>
          <ListItem key={3} icon={iconInfo} informative notButton>
            <FormattedMessage {...messages.infoToken} />
          </ListItem>
        </List>
        <Row>
          <Col xs={12} xs={12}>
            <FlatButton name="btnContinuar" className="redButton big centered" type="submit" label={formatMessage(messages.buttonEnviar)} disabled={pristine || submitting || !arquivoSelfie} tabIndex="2" />
          </Col>
        </Row>
      </form>
    );

    if (loading) {
      content = (<Loader />);
    }

    return (
      content
    );
  }
}

CelularForm.propTypes = {
  pristine: React.PropTypes.bool,
  submitting: React.PropTypes.bool,
  handleSubmit: React.PropTypes.func,
  handleSetSelfie: React.PropTypes.func,
  Email: React.PropTypes.func,
  Telefone: React.PropTypes.func,
  Selfie: React.PropTypes.string,
  loading: React.PropTypes.bool,
  intl: intlShape.isRequired,
};

function mapDispatchToProps(dispatch) {
  return {
    handleSetSelfie: (fileBase64) => {
      dispatch(change('CelularForm', 'Selfie', fileBase64));
    },
    dispatch,
  };
}

const selector = formValueSelector('CelularForm');
export default connect(
  state => {
    const Selfie = selector(state, 'Selfie');
    return {
      Selfie,
    };
  }, mapDispatchToProps)(injectIntl(reduxForm({
    form: 'CelularForm',
    validate: validateCelularForm,
    enableReinitialize: true,
  })(CelularForm)));
