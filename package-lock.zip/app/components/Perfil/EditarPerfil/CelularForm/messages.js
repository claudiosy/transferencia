import { defineMessages } from 'react-intl';

export default defineMessages({
  titulo: {
    id: 'app.components.Perfil.EditarPerfil.CelularForm.titulo',
    defaultMessage: 'Recuperar Senha',
  },
  hintCelular: {
    id: 'app.components.Perfil.EditarPerfil.CelularForm.hintCelular',
    defaultMessage: 'Novo número de celular',
  },
  hintSelfie: {
    id: 'app.components.Perfil.EditarPerfil.CelularForm.hintSelfie',
    defaultMessage: 'SELFIE',
  },
  infoToken: {
    id: 'app.components.Perfil.EditarPerfil.CelularForm.infoToken',
    defaultMessage: 'Ao clicar em CONTINUAR, enviaremos um código de 6 dígitos ao seu novo celular',
  },
  dropArquivoRG: {
    id: 'app.components.Perfil.EditarPerfil.CelularForm.dropArquivoRG',
    defaultMessage: 'Clique para selecionar o arquivo, ou arraste ele aqui (máx. 2Mb).',
  },
  buttonEnviar: {
    id: 'app.components.Perfil.EditarPerfil.CelularForm.buttonEnviar',
    defaultMessage: 'CONTINUAR',
  },
});
