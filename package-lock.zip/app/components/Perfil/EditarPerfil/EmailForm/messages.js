import { defineMessages } from 'react-intl';

export default defineMessages({
  hintEmail: {
    id: 'app.components.Perfil.EditarPerfil.EmailForm.hintEmail',
    defaultMessage: 'Novo Email',
  },
  hintSelfie: {
    id: 'app.components.Perfil.EditarPerfil.EmailForm.hintSelfie',
    defaultMessage: 'SELFIE',
  },
  infoToken: {
    id: 'app.components.Perfil.EditarPerfil.EmailForm.infoToken',
    defaultMessage: 'Ao clicar em CONTINUAR, enviaremos um código de 6 dígitos ao seu novo email',
  },
  dropArquivoRG: {
    id: 'app.components.Perfil.EditarPerfil.EmailForm.dropArquivoRG',
    defaultMessage: 'Clique para selecionar o arquivo, ou arraste ele aqui (máx. 2Mb).',
  },
  buttonEnviar: {
    id: 'app.components.Perfil.EditarPerfil.EmailForm.buttonEnviar',
    defaultMessage: 'CONTINUAR',
  },
});
