import React from 'react';
import { reduxForm, Field, change, formValueSelector } from 'redux-form/immutable';
import { connect } from 'react-redux';
import { TextField } from 'redux-form-material-ui';
import FlatButton from 'material-ui/FlatButton';
import { injectIntl, intlShape, FormattedMessage } from 'react-intl';
import Dropzone from 'react-dropzone';
import messages from './messages';
import Loader from 'components/Loader';
import { Row, Col } from 'react-flexbox-grid/lib/index';
import List from 'components/List';
import ListItem from 'components/ListItem';
import validateEmailForm from './validation';
import styles from './styles.css';
import iconConfirm from 'containers/App/confirm-icon.png';
import iconInfo from 'containers/App/icon-info.png';

class EmailForm extends React.Component {
  constructor() {
    super();
    this.state = {
      arquivoSelfie: null,
    };
    this.onDrop = this.onDrop.bind(this);
  }
  onDrop(files, name) {
    const file = files[0];
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = () => {
      const fileInfo = {
        thumb: file.preview,
        base64: reader.result,
      };
      const obj = {};
      obj[name] = fileInfo;
      this.setState(obj);
      this.props.handleSetSelfie(fileInfo.base64);
    };
  }
  render() {
    const { handleSubmit, pristine, submitting, loading } = this.props;
    const { formatMessage } = this.props.intl;
    const { arquivoSelfie } = this.state;
    let content = (
      <form onSubmit={handleSubmit} className={styles.emailForm}>
        <Field component={TextField} className="iptHidden" name="Selfie" type="hidden" value={arquivoSelfie && arquivoSelfie.base64} underlineShow={false} />
        <Field component={TextField} className="iptHidden" name="Telefone" type="hidden" underlineShow={false} />
        <List>
          <ListItem key={1}>
            <Field autoFocus name="Email" component={TextField} className={`${styles.inputEmail} redInput wFloatingLabel`} floatingLabelText={formatMessage(messages.hintEmail)} type="text" tabIndex="1" />
          </ListItem>
          <ListItem key={2} autoHeight>
            <Dropzone accept="image/*" onDrop={(event) => this.onDrop(event, 'arquivoSelfie')} className={styles.dropzone} activeClassName={styles.dropzoneActive} maxSize="2097152">
              <div className={`${styles.preview} ${!arquivoSelfie && styles.bg}`}>
                <div style={{ backgroundImage: `url(${iconConfirm})` }} className={`${arquivoSelfie && styles.block} ${styles.hide} ${styles.confirImg} `}></div>
                <img className={`${arquivoSelfie && styles.block} ${styles.hide} `} src={arquivoSelfie && arquivoSelfie.thumb} role="presentation" />
              </div>
              <div className={styles.lblTit}><FormattedMessage {...messages.hintSelfie} /></div>
              <div className={styles.lblButton}><FormattedMessage {...messages.dropArquivoRG} /></div>
            </Dropzone>
          </ListItem>
          <ListItem key={3} informative icon={iconInfo} notButton>
            <FormattedMessage {...messages.infoToken} />
          </ListItem>
        </List>
        <Row>
          <Col xs={12} xs={12}>
            <FlatButton name="btnContinuar" className="redButton big centered" type="submit" label={formatMessage(messages.buttonEnviar)} disabled={pristine || submitting || !arquivoSelfie} tabIndex="2" />
          </Col>
        </Row>
      </form>
    );

    if (loading) {
      content = (<Loader />);
    }

    return (
      content
    );
  }
}

EmailForm.propTypes = {
  pristine: React.PropTypes.bool,
  submitting: React.PropTypes.bool,
  handleSubmit: React.PropTypes.func,
  handleSetSelfie: React.PropTypes.func,
  Email: React.PropTypes.func,
  Telefone: React.PropTypes.func,
  Selfie: React.PropTypes.string,
  loading: React.PropTypes.bool,
  intl: intlShape.isRequired,
};

function mapDispatchToProps(dispatch) {
  return {
    handleSetSelfie: (fileBase64) => {
      dispatch(change('EmailForm', 'Selfie', fileBase64));
    },
    dispatch,
  };
}

const selector = formValueSelector('EmailForm');
export default connect(
  state => {
    const Selfie = selector(state, 'Selfie');
    return {
      Selfie,
    };
  }, mapDispatchToProps)(injectIntl(reduxForm({
    form: 'EmailForm',
    validate: validateEmailForm,
    // enableReinitialize: true,
  })(EmailForm)));
