import React from 'react';
import { connect } from 'react-redux';
import { push } from 'react-router-redux';
import List from 'components/List';
import ListItem from 'components/ListItem';
import { Row, Col } from 'react-flexbox-grid/lib/index';
import styles from './styles.css';
import messages from './messages';
import FlatButton from 'material-ui/FlatButton';
import { FormattedMessage, injectIntl, intlShape } from 'react-intl';
import cardDigital from 'components/Perfil/CompletarPerfil/CartaoDigital/cartao-super-digital.png';
import Loader from 'components/Loader';
import iconOpenArrow from 'containers/App/openarrow-icon.png';

const ConfirmSucesso = props => {
  const { redirectAdicionar, redirectPedirCartao, planos, completarPerfilModel, loading } = props;
  const { formatMessage } = props.intl;
  const temNumeroCartao = completarPerfilModel.toJS().DadosCartao.NumeroCartao !== null;
  const planoEscolhido = planos.toJS().filter((item) => { // eslint-disable-line arrow-body-style
    return item.PlanoId === completarPerfilModel.toJS().Plano.PlanoId;
  })[0];

  let content = (
    <div>
      <List>
        <ListItem key={1} autoHeight notButton>
          <p className={styles.titulo}>
            <span><FormattedMessage {...messages.titleSucesso} /></span>
            <span className={styles.nomePlano}>{planoEscolhido.Nome}</span>
          </p>
        </ListItem>
      </List>
      <div className={styles.mainCard}>
        <Row center="xs">
          <Col sm={12} md={12} xs={12}>
            <div className={styles.contentCard}>
              <img src={cardDigital} alt="" />
            </div>
          </Col>
        </Row>
      </div>
      <Row center="xs" className={styles.divButtons} >
        <Col sm={12} md={12} xs={12}>
          <div>
            <img src={iconOpenArrow} alt="" />
          </div>
          <div>
            <p><FormattedMessage {...messages.infoAdicionar1} /></p>
            <p className={styles.msgInfo2}><FormattedMessage {...messages.infoAdicionar2} /><span className={styles.msgBold}> <FormattedMessage {...messages.infoAdicionar3} /></span></p>
          </div>
        </Col>
      </Row>
      <div className={`${temNumeroCartao ? styles.hide : ''} `}>
        <FlatButton className={`${styles.btnCartaoRed} redButton big`} label={formatMessage(messages.buttonReceberCartao)} onMouseUp={redirectAdicionar} />
      </div>
      <div className={`${temNumeroCartao || planoEscolhido.PlanoId === 176 ? styles.hide : ''} `}>
        <FlatButton className={`${styles.btnCartao} redButton big`} label={formatMessage(messages.buttonCartaoAdicional)} onMouseUp={redirectPedirCartao} />
      </div>
    </div>
  );

  if (loading) {
    content = (<Loader />);
  }

  return (
    // eslint-disable-next-line react/jsx-boolean-value
    <div>
      {content}
    </div>
  );
};

ConfirmSucesso.propTypes = {
  redirectAdicionar: React.PropTypes.func,
  redirectPedirCartao: React.PropTypes.func,
  loading: React.PropTypes.bool,
  planos: React.PropTypes.object,
  completarPerfilModel: React.PropTypes.object,
  intl: intlShape.isRequired,
};

function mapDispatchToProps(dispatch) {
  return {
    redirectAdicionar: () => {
      dispatch(push('/movimentar/adicionar'));
    },
    redirectPedirCartao: () => {
      dispatch(push('/organizar/cartoes/pedir/adicional'));
    },
    dispatch,
  };
}

export default connect(null, mapDispatchToProps)(injectIntl(ConfirmSucesso));
