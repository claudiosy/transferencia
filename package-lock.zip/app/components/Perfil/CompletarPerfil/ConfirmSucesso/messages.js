import { defineMessages } from 'react-intl';

export default defineMessages({
  titleSucesso: {
    id: 'app.components.Perfil.CompletarPerfil.ConfirmSucesso.titleSucesso',
    defaultMessage: 'Parabéns! Agora, você tem a assinatura',
  },
  infoAdicionar1: {
    id: 'app.components.Perfil.CompletarPerfil.ConfirmSucesso.infoAdicionar1',
    defaultMessage: 'Para receber o seu cartão,',
  },
  infoAdicionar2: {
    id: 'app.components.Perfil.CompletarPerfil.ConfirmSucesso.infoAdicionar2',
    defaultMessage: 'você',
  },
  infoAdicionar3: {
    id: 'app.components.Perfil.CompletarPerfil.ConfirmSucesso.infoAdicionar3',
    defaultMessage: ' precisa adicionar $',
  },
  buttonReceberCartao: {
    id: 'app.components.Perfil.CompletarPerfil.ConfirmSucesso.buttonReceberCartao',
    defaultMessage: 'RECEBER CARTÃO',
  },
  buttonCartaoAdicional: {
    id: 'app.components.Perfil.CompletarPerfil.ConfirmSucesso.buttonCartaoAdicional',
    defaultMessage: 'SOLICITAR CARTÃO ADICIONAL',
  },
});
