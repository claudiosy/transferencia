import messages from 'containers/App/messages';

const validateCartaoDigital = (valuesFromState, props) => {
  const { formatMessage } = props.intl;
  const errors = {};
  const values = valuesFromState.toJS();

  if (!values.NumeroCartao || values.NumeroCartao.length < 16) {
    errors.NumeroCartao = formatMessage(messages.mandatoryField);
  }
  if (!values.CodigoSeguranca || values.CodigoSeguranca.length < 3) {
    errors.CodigoSeguranca = formatMessage(messages.mandatoryField);
  }

  return errors;
};

export default validateCartaoDigital;
