import React from 'react';
import { connect } from 'react-redux';
import List from 'components/List';
import ListItem from 'components/ListItem';
import { Row, Col } from 'react-flexbox-grid/lib/index';
import { reduxForm, Field, change, formValueSelector } from 'redux-form/immutable';
import { TextField } from 'redux-form-material-ui';
import styles from './styles.css';
import messages from './messages';
import FlatButton from 'material-ui/FlatButton';
import { FormattedMessage, injectIntl, intlShape } from 'react-intl';
import cardDigital from './cartao-super-digital.png';
import iconInfo from 'containers/App/icon-info-red.png';
import validateCartaoDigital from './validation';
import btnVoltar from 'containers/App/prev-icon.png';
import { normalizeDigitoBilhete, normalizeNumeroCartao } from 'normalizers';

const CartaoDigital = props => {
  const { handleSubmit, pristine, submitting, handleStepFormChange, handleSetPossuiCartao, handleBack, possuiCartao } = props;
  const { formatMessage } = props.intl;
  return (
    // eslint-disable-next-line react/jsx-boolean-value
    <form>
      <List>
        <ListItem key={0} icon={iconInfo} notButton>
          <span><FormattedMessage {...messages.cardDigital} /></span>
        </ListItem>
      </List>
      <div className={styles.mainCard}>
        <Row center="xs">
          <Col sm={12} md={12} xs={12}>
            <div className={styles.contentCard}>
              <img src={cardDigital} alt="" />
            </div>
          </Col>
        </Row>
      </div>
      <List>
        <ListItem key={1} invisibled={!possuiCartao}>
          <Field name="NumeroCartao" component={TextField} className="redInput wFloatingLabel" floatingLabelText={formatMessage(messages.hintNumeroCartao)} type="tel" normalize={normalizeNumeroCartao} tabIndex="1" />
        </ListItem>
        <ListItem key={2} invisibled={!possuiCartao}>
          <Field name="CodigoSeguranca" component={TextField} className="redInput wFloatingLabel" floatingLabelText={formatMessage(messages.hintCodigoSeguranca)} tabIndex="2" type="tel" normalize={normalizeDigitoBilhete} />
        </ListItem>
      </List>
      <Row center="xs" className={`${possuiCartao ? styles.hide : ''} ${styles.grpBts}`}>
        <Col sm={6} xs={12}>
          <FlatButton className="redButton big centered inRight" label={formatMessage(messages.buttonSim)} onMouseUp={() => handleSetPossuiCartao()} />
        </Col>
        <Col sm={6} xs={12}>
          <FlatButton className="redButton big centered inLeft" label={formatMessage(messages.buttonNao)} onMouseUp={() => handleStepFormChange(5)} />
        </Col>
      </Row>
      <div className={`${possuiCartao ? styles.block : ''} ${styles.hide}`}>
        <FlatButton className="redButton big centered" label={formatMessage(messages.buttonContinuar)} disabled={pristine || submitting} tabIndex={5} onMouseUp={handleSubmit} />
      </div>
      <Row center="xs" className={`${possuiCartao ? styles.block : ''} ${styles.hide}`}>
        <Col sm={12} xs={12}>
          <FlatButton className={styles.btnVoltar} label={formatMessage(messages.btVoltar)} onMouseUp={handleBack}>
            <img src={btnVoltar} role="presentation" alt="" />
          </FlatButton>
        </Col>
      </Row>
    </form>
  );
};

CartaoDigital.propTypes = {
  pristine: React.PropTypes.bool,
  submitting: React.PropTypes.bool,
  handleSubmit: React.PropTypes.func,
  handleStepFormChange: React.PropTypes.func,
  handleSetPossuiCartao: React.PropTypes.func,
  handleBack: React.PropTypes.func,
  possuiCartao: React.PropTypes.bool,
  NumeroCartao: React.PropTypes.string,
  CodigoSeguranca: React.PropTypes.string,
  intl: intlShape.isRequired,
};

function mapDispatchToProps(dispatch) {
  return {
    handleSetPossuiCartao: () => {
      dispatch(change('cartaoDigitalForm', 'possuiCartao', true));
    },
    handleBack: () => {
      dispatch(change('cartaoDigitalForm', 'possuiCartao', false));
    },
    dispatch,
  };
}

const selector = formValueSelector('cartaoDigitalForm');
export default connect(
  state => {
    const possuiCartao = selector(state, 'possuiCartao');
    return {
      possuiCartao,
    };
  }, mapDispatchToProps)(injectIntl(reduxForm({
    form: 'cartaoDigitalForm',
    validate: validateCartaoDigital,
  })(CartaoDigital)));
