import { defineMessages } from 'react-intl';

export default defineMessages({
  cardDigital: {
    id: 'app.components.Perfil.CompletarPerfil.CartaoDigital.cardDigital',
    defaultMessage: 'VOCÊ ESTÁ COM O CARTÃO SUPERDIGITAL NA MÃO?',
  },
  hintNumeroCartao: {
    id: 'app.components.Perfil.CompletarPerfil.CartaoDigital.hintNumeroCartao',
    defaultMessage: 'NÚMERO DO CARTÃO SUPERDIGITAL',
  },
  hintCodigoSeguranca: {
    id: 'app.components.Perfil.CompletarPerfil.CartaoDigital.hintCodigoSeguranca',
    defaultMessage: 'CÓDIGO DE SEGURANÇA',
  },
  buttonSim: {
    id: 'app.components.Perfil.CompletarPerfil.CartaoDigital.buttonSim',
    defaultMessage: 'SIM',
  },
  buttonNao: {
    id: 'app.components.Perfil.CompletarPerfil.CartaoDigital.buttonNao',
    defaultMessage: 'NÃO',
  },
  buttonContinuar: {
    id: 'app.components.Perfil.CompletarPerfil.CartaoDigital.buttonContinuar',
    defaultMessage: 'Continuar',
  },
  btVoltar: {
    id: 'app.components.Perfil.CompletarPerfil.CartaoDigital.btVoltar',
    defaultMessage: 'Voltar',
  },
});
