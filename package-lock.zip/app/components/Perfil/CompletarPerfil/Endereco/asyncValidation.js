import { buscaCEP, setDadosCEP } from 'containers/CompletarPerfilPage/actions';

const asyncValidateEndereco = (values, dispatch) => { // eslint-disable-line arrow-body-style
  const data = values.toJS();
  return new Promise((resolve, reject) => {
    dispatch(buscaCEP(data.CEP, resolve, reject, null, (value) => { // eslint-disable-line arrow-body-style
      return value.Sucesso;
    }));
  }).then((status) => {
    if (status.Sucesso) {
      dispatch(setDadosCEP(status.Dados, 4));
    }
  });
};

export default asyncValidateEndereco;
