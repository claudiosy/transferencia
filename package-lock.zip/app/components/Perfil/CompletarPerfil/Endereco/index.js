import React from 'react';
import { reduxForm, Field, change, formValueSelector } from 'redux-form/immutable';
import { TextField, SelectField } from 'redux-form-material-ui';
import { connect } from 'react-redux';
import FlatButton from 'material-ui/FlatButton';
import { Row, Col } from 'react-flexbox-grid/lib/index';
import validateEndereco from './validation';
import asyncValidateEndereco from './asyncValidation';
import { injectIntl, intlShape, FormattedMessage } from 'react-intl';
import messages from './messages';
import { normalizeCEP, normalizeNumber } from 'normalizers';
import SelectItem from 'components/SelectItem';
import List from 'components/List';
import ListItem from 'components/ListItem';
import styles from './styles.css';
import comercioIcon from './comercio-icon.png';
import CircularProgress from 'material-ui/CircularProgress';

class Endereco extends React.Component {
  componentWillMount() {
    this.props.handleInitTipoEndereco();
  }
  handleOpenDadosComercial() {
    this.props.handleSubmit();
    this.props.handleFlgComercial();
  }
  render() {
    const { handleSubmit, pristine, submitting, tipoLogradouros, estados, loadingEndereco } = this.props;
    const { formatMessage } = this.props.intl;

    return (
      <form>
        <Field component={TextField} className="iptHidden" name="TipoEnderecoID" type="hidden" underlineShow={false} />
        <h4 className="list-title"><FormattedMessage {...messages.titEndResidencial} /></h4>
        <List>
          <ListItem key={1}>
            <Field
              name="CEP"
              component={TextField}
              className="redInput wFloatingLabel"
              floatingLabelText={formatMessage(messages.hintCEP)}
              normalize={normalizeCEP}
              type="tel"
              tabIndex="1"
              format={normalizeCEP}
            />
            <span className={`${loadingEndereco ? styles.block : ''} ${styles.hide} ${styles.loaderWrapper}`}>
              <CircularProgress size={0.3} />
            </span>
          </ListItem>
          <ListItem key={2}>
            <SelectItem
              selectData={tipoLogradouros}
              name="TipoLogradouroID"
              component={SelectField}
              className="redInput wFloatingLabel"
              floatingLabelText={formatMessage(messages.hintTipoLogradouro)}
              tabIndex="2"
              autoWidth
              disabled
            />
          </ListItem>
          <ListItem key={3}>
            <Field name="Logradouro" component={TextField} className="redInput wFloatingLabel" floatingLabelText={formatMessage(messages.hintLogradouro)} disabled tabIndex="3" />
          </ListItem>
          <ListItem key={4}>
            <Field name="Numero" component={TextField} className="redInput wFloatingLabel" floatingLabelText={formatMessage(messages.hintNumero)} tabIndex="4" type="tel" normalize={normalizeNumber} />
          </ListItem>
          <ListItem key={5}>
            <Field name="Complemento" component={TextField} className="redInput wFloatingLabel" floatingLabelText={formatMessage(messages.hintComplemento)} tabIndex="5" />
          </ListItem>
          <ListItem key={6}>
            <Field name="Bairro" component={TextField} className="redInput wFloatingLabel" floatingLabelText={formatMessage(messages.hintBairro)} disabled tabIndex="6" />
          </ListItem>
          <ListItem key={7}>
            <SelectItem
              selectData={estados}
              name="EstadoID"
              component={SelectField}
              className="redInput wFloatingLabel"
              floatingLabelText={formatMessage(messages.hintEstado)}
              tabIndex="7"
              autoWidth
              disabled
            />
          </ListItem>
          <ListItem key={8}>
            <Field name="Cidade" component={TextField} className="redInput wFloatingLabel" floatingLabelText={formatMessage(messages.hintCidade)} disabled tabIndex="8" />
          </ListItem>
        </List>
        <Row center="xs" className={styles.btComercial}>
          <Col sm={12} xs={12}>
            <FlatButton className={styles.addComercial} onMouseUp={() => this.handleOpenDadosComercial()}>
              <img src={comercioIcon} role="presentation" />
              <FormattedMessage {...messages.buttonAdComercial} />
            </FlatButton>
          </Col>
        </Row>
        <Row center="xs" className={styles.btComercial}>
          <Col sm={12} xs={12}>
            <FlatButton className="redButton big centered" label={formatMessage(messages.buttonContinuar)} disabled={pristine || submitting} tabIndex={11} onMouseUp={handleSubmit} />
          </Col>
        </Row>
      </form>
    );
  }
}

Endereco.propTypes = {
  pristine: React.PropTypes.bool,
  submitting: React.PropTypes.bool,
  handleSubmit: React.PropTypes.func,
  handleInitTipoEndereco: React.PropTypes.func,
  handleOpenDadosComercial: React.PropTypes.func,
  handleFlgComercial: React.PropTypes.func,
  handleBuscaCEP: React.PropTypes.func,
  CEP: React.PropTypes.string,
  TipoLogradouroID: React.PropTypes.number,
  Logradouro: React.PropTypes.string,
  Numero: React.PropTypes.string,
  Complemento: React.PropTypes.string,
  Bairro: React.PropTypes.string,
  TipoEnderecoID: React.PropTypes.number,
  Cidade: React.PropTypes.string,
  EstadoID: React.PropTypes.number,
  tipoLogradouros: React.PropTypes.object,
  estados: React.PropTypes.object,
  loadingEndereco: React.PropTypes.bool,
  intl: intlShape.isRequired,
};

function mapDispatchToProps(dispatch) {
  return {
    handleInitTipoEndereco: () => {
      dispatch(change('enderecoForm', 'TipoEnderecoID', 4));
    },
    dispatch,
  };
}

const selector = formValueSelector('enderecoForm');
export default connect(
  state => {
    const TipoEnderecoID = selector(state, 'TipoEnderecoID');
    return {
      TipoEnderecoID,
    };
  }, mapDispatchToProps)(injectIntl(reduxForm({
    form: 'enderecoForm',
    validate: validateEndereco,
    asyncValidate: asyncValidateEndereco,
    asyncBlurFields: ['CEP'],
    enableReinitialize: true,
  })(Endereco)));
