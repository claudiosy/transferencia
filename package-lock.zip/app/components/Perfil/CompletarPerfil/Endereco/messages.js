import { defineMessages } from 'react-intl';

export default defineMessages({
  titEndResidencial: {
    id: 'app.components.Perfil.CompletarPerfil.Endereco.titEndResidencial',
    defaultMessage: 'Endereço Residencial',
  },
  hintCEP: {
    id: 'app.components.Perfil.CompletarPerfil.Endereco.hintCEP',
    defaultMessage: 'CEP',
  },
  hintTipoLogradouro: {
    id: 'app.components.Perfil.CompletarPerfil.Endereco.hintTipoLogradouro',
    defaultMessage: 'LOGRADOURO',
  },
  hintExTipoLogradouro: {
    id: 'app.components.Perfil.CompletarPerfil.Endereco.hintExTipoLogradouro',
    defaultMessage: '(rua, avenida, etc.)',
  },
  hintLogradouro: {
    id: 'app.components.Perfil.CompletarPerfil.Endereco.hintLogradouro',
    defaultMessage: 'ENDEREÇO',
  },
  hintNumero: {
    id: 'app.components.Perfil.CompletarPerfil.Endereco.hintNumero',
    defaultMessage: 'NÚMERO',
  },
  hintComplemento: {
    id: 'app.components.Perfil.CompletarPerfil.Endereco.hintComplemento',
    defaultMessage: 'COMPLEMENTO',
  },
  hintBairro: {
    id: 'app.components.Perfil.CompletarPerfil.Endereco.hintBairro',
    defaultMessage: 'BAIRRO',
  },
  hintEstado: {
    id: 'app.components.Perfil.CompletarPerfil.Endereco.hintEstado',
    defaultMessage: 'ESTADO',
  },
  hintCidade: {
    id: 'app.components.Perfil.CompletarPerfil.Endereco.hintCidade',
    defaultMessage: 'CIDADE',
  },
  buttonAdComercial: {
    id: 'app.components.Perfil.CompletarPerfil.Endereco.buttonAdComercial',
    defaultMessage: 'QUER ADICIONAR SEU ENDEREÇO COMERCIAL?',
  },
  buttonContinuar: {
    id: 'app.components.Perfil.CompletarPerfil.Endereco.buttonContinuar',
    defaultMessage: 'Continuar',
  },
});
