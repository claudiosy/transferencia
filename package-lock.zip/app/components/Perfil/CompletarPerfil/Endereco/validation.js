import messages from 'containers/App/messages';

const validateEndereco = (valuesFromState, props) => {
  const { formatMessage } = props.intl;
  const errors = {};
  const values = valuesFromState.toJS();

  if (!values.CEP) {
    errors.CEP = formatMessage(messages.mandatoryField);
  }
  if (!values.TipoLogradouroID) {
    errors.TipoLogradouroID = formatMessage(messages.mandatoryField);
  }
  if (!values.Logradouro) {
    errors.Logradouro = formatMessage(messages.mandatoryField);
  }
  if (values.Logradouro && values.Logradouro.length > 100) {
    errors.Logradouro = formatMessage(messages.maxlengthField);
  }
  if (!values.Numero) {
    errors.Numero = formatMessage(messages.mandatoryField);
  }
  if (values.Numero && values.Numero.length > 10) {
    errors.Numero = formatMessage(messages.maxlengthField);
  }
  if (values.Complemento && values.Complemento.length > 50) {
    errors.Complemento = formatMessage(messages.maxlengthField);
  }
  if (!values.Bairro) {
    errors.Bairro = formatMessage(messages.mandatoryField);
  }
  if (values.Bairro && values.Bairro.length > 50) {
    errors.Bairro = formatMessage(messages.maxlengthField);
  }
  if (!values.EstadoID) {
    errors.EstadoID = formatMessage(messages.mandatoryField);
  }
  if (!values.Cidade) {
    errors.Cidade = formatMessage(messages.mandatoryField);
  }
  if (values.Cidade && values.Cidade.length > 50) {
    errors.Cidade = formatMessage(messages.maxlengthField);
  }
  return errors;
};

export default validateEndereco;
