import { defineMessages } from 'react-intl';

export default defineMessages({
  titEndComercial: {
    id: 'app.components.Perfil.CompletarPerfil.EnderecoComercial.titEndComercial',
    defaultMessage: 'Endereço Comercial',
  },
  hintCEP: {
    id: 'app.components.Perfil.CompletarPerfil.EnderecoComercial.hintCEP',
    defaultMessage: 'CEP',
  },
  hintTipoLogradouro: {
    id: 'app.components.Perfil.CompletarPerfil.EnderecoComercial.hintTipoLogradouro',
    defaultMessage: 'LOGRADOURO',
  },
  hintExTipoLogradouro: {
    id: 'app.components.Perfil.CompletarPerfil.EnderecoComercial.hintExTipoLogradouro',
    defaultMessage: '(rua, avenida, etc.)',
  },
  hintLogradouro: {
    id: 'app.components.Perfil.CompletarPerfil.EnderecoComercial.hintLogradouro',
    defaultMessage: 'ENDEREÇO',
  },
  hintNumero: {
    id: 'app.components.Perfil.CompletarPerfil.EnderecoComercial.hintNumero',
    defaultMessage: 'NÚMERO',
  },
  hintComplemento: {
    id: 'app.components.Perfil.CompletarPerfil.EnderecoComercial.hintComplemento',
    defaultMessage: 'COMPLEMENTO',
  },
  hintBairro: {
    id: 'app.components.Perfil.CompletarPerfil.EnderecoComercial.hintBairro',
    defaultMessage: 'BAIRRO',
  },
  hintEstado: {
    id: 'app.components.Perfil.CompletarPerfil.EnderecoComercial.hintEstado',
    defaultMessage: 'ESTADO',
  },
  hintCidade: {
    id: 'app.components.Perfil.CompletarPerfil.EnderecoComercial.hintCidade',
    defaultMessage: 'CIDADE',
  },
  buttonAdComercial: {
    id: 'app.components.Perfil.CompletarPerfil.EnderecoComercial.buttonAdComercial',
    defaultMessage: 'QUER ADICIONAR SEU ENDEREÇO COMERCIAL?',
  },
  buttonContinuar: {
    id: 'app.components.Perfil.CompletarPerfil.EnderecoComercial.buttonContinuar',
    defaultMessage: 'Continuar',
  },
});
