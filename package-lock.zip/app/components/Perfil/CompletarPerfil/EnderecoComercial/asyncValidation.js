import { buscaCEP, setDadosCEP } from 'containers/CompletarPerfilPage/actions';

const asyncValidateEnderecoComercial = (values, dispatch) => { // eslint-disable-line arrow-body-style
  const data = values.toJS();
  return new Promise((resolve, reject) => {
    dispatch(buscaCEP(data.CEP, resolve, reject, 'CEP', (value) => { // eslint-disable-line arrow-body-style
      return value.Sucesso;
    }));
  }).then((status) => {
    if (status.Sucesso) {
      dispatch(setDadosCEP(status.Dados, 2));
    }
  });
};

export default asyncValidateEnderecoComercial;
