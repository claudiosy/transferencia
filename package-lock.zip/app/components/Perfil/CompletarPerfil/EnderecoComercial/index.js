import React from 'react';
import { reduxForm, Field, change, formValueSelector } from 'redux-form/immutable';
import { TextField, SelectField } from 'redux-form-material-ui';
import { connect } from 'react-redux';
import FlatButton from 'material-ui/FlatButton';
import { Row, Col } from 'react-flexbox-grid/lib/index';
import validateEnderecoComercial from './validation';
import asyncValidateEnderecoComercial from './asyncValidation';
import { injectIntl, intlShape, FormattedMessage } from 'react-intl';
import messages from './messages';
import { normalizeCEP, normalizeNumber } from 'normalizers';
import SelectItem from 'components/SelectItem';
import List from 'components/List';
import ListItem from 'components/ListItem';
import CircularProgress from 'material-ui/CircularProgress';
import styles from './styles.css';

class EnderecoComercial extends React.Component {
  componentWillMount() {
    this.props.handleInitTipoEndereco();
  }
  render() {
    const { handleSubmit, pristine, submitting, tipoLogradouros, estados, loadingEndereco } = this.props;
    const { formatMessage } = this.props.intl;

    return (
      <form onSubmit={handleSubmit}>
        <Field component={TextField} className="iptHidden" name="TipoEnderecoID" type="hidden" underlineShow={false} />
        <h4 className="list-title"><FormattedMessage {...messages.titEndComercial} /></h4>
        <List>
          <ListItem key={1}>
            <Field name="CEP" component={TextField} className="redInput wFloatingLabel" floatingLabelText={formatMessage(messages.hintCEP)} type="tel" normalize={normalizeCEP} tabIndex="1" />
            <span className={`${loadingEndereco ? styles.block : ''} ${styles.hide} ${styles.loaderWrapper}`}>
              <CircularProgress size={0.3} />
            </span>
          </ListItem>
          <ListItem key={2}>
            <SelectItem
              selectData={tipoLogradouros}
              name="TipoLogradouroID"
              component={SelectField}
              className="redInput wFloatingLabel"
              floatingLabelText={formatMessage(messages.hintTipoLogradouro)}
              tabIndex="2"
              autoWidth
              disabled
            />
          </ListItem>
          <ListItem key={3}>
            <Field name="Logradouro" component={TextField} className="redInput wFloatingLabel" floatingLabelText={formatMessage(messages.hintLogradouro)} disabled tabIndex="3" />
          </ListItem>
          <ListItem key={4}>
            <Field name="Numero" component={TextField} className="redInput wFloatingLabel" floatingLabelText={formatMessage(messages.hintNumero)} tabIndex="4" type="tel" normalize={normalizeNumber} />
          </ListItem>
          <ListItem key={5}>
            <Field name="Complemento" component={TextField} className="redInput wFloatingLabel" floatingLabelText={formatMessage(messages.hintComplemento)} tabIndex="5" />
          </ListItem>
          <ListItem key={6}>
            <Field name="Bairro" component={TextField} className="redInput wFloatingLabel" floatingLabelText={formatMessage(messages.hintBairro)} disabled tabIndex="6" />
          </ListItem>
          <ListItem key={7}>
            <SelectItem
              selectData={estados}
              name="EstadoID"
              component={SelectField}
              className="redInput wFloatingLabel"
              floatingLabelText={formatMessage(messages.hintEstado)}
              tabIndex="7"
              autoWidth
              disabled
            />
          </ListItem>
          <ListItem key={8}>
            <Field name="Cidade" component={TextField} className="redInput wFloatingLabel" floatingLabelText={formatMessage(messages.hintCidade)} disabled tabIndex="8" />
          </ListItem>
        </List>
        <Row center="xs">
          <Col sm={12} xs={12}>
            <FlatButton type="submit" className="redButton big centered" label={formatMessage(messages.buttonContinuar)} disabled={pristine || submitting} tabIndex={11} />
          </Col>
        </Row>
      </form>
    );
  }
}

EnderecoComercial.propTypes = {
  pristine: React.PropTypes.bool,
  submitting: React.PropTypes.bool,
  handleSubmit: React.PropTypes.func,
  handleInitTipoEndereco: React.PropTypes.func,
  CEP: React.PropTypes.string,
  TipoLogradouroID: React.PropTypes.number,
  Logradouro: React.PropTypes.string,
  Numero: React.PropTypes.string,
  Complemento: React.PropTypes.string,
  Bairro: React.PropTypes.string,
  TipoEnderecoID: React.PropTypes.number,
  Cidade: React.PropTypes.string,
  EstadoID: React.PropTypes.number,
  tipoLogradouros: React.PropTypes.object,
  estados: React.PropTypes.object,
  loadingEndereco: React.PropTypes.bool,
  intl: intlShape.isRequired,
};

function mapDispatchToProps(dispatch) {
  return {
    handleInitTipoEndereco: () => {
      dispatch(change('enderecoComercialForm', 'TipoEnderecoID', 2));
      dispatch(change('enderecoComercialForm', 'CEP', ''));
      dispatch(change('enderecoComercialForm', 'TipoLogradouroID', ''));
      dispatch(change('enderecoComercialForm', 'Logradouro', ''));
      dispatch(change('enderecoComercialForm', 'Numero', ''));
      dispatch(change('enderecoComercialForm', 'Complemento', ''));
      dispatch(change('enderecoComercialForm', 'Bairro', ''));
      dispatch(change('enderecoComercialForm', 'Cidade', ''));
      dispatch(change('enderecoComercialForm', 'EstadoID', ''));
    },
    dispatch,
  };
}

const selector = formValueSelector('enderecoComercialForm');
export default connect(
  state => {
    const TipoEnderecoID = selector(state, 'TipoEnderecoID');
    return {
      TipoEnderecoID,
    };
  }, mapDispatchToProps)(injectIntl(reduxForm({
    form: 'enderecoComercialForm',
    validate: validateEnderecoComercial,
    asyncValidate: asyncValidateEnderecoComercial,
    asyncBlurFields: ['CEP'],
    enableReinitialize: true,
  })(EnderecoComercial)));
