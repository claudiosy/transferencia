import React from 'react';
import { reduxForm } from 'redux-form/immutable';
import FlatButton from 'material-ui/FlatButton';
// import validateAnexosFotos from './validation';
import { injectIntl, intlShape, FormattedMessage } from 'react-intl';
import Dropzone from 'react-dropzone';
import messages from './messages';
import List from 'components/List';
import ListItem from 'components/ListItem';
import styles from './styles.css';
import iconConfirm from 'containers/App/confirm-icon.png';

class AnexosFotos extends React.Component {
  constructor() {
    super();
    this.state = {
      arquivoRg: null,
      arquivoVersoRg: null,
      // arquivoComprovanteEnd: null,
      arquivoSelfie: null,
    };
    this.onDrop = this.onDrop.bind(this);
  }
  onDrop(files, name) {
    const file = files[0];
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = () => {
      const fileInfo = {
        thumb: file.preview,
        base64: reader.result,
      };
      const obj = {};
      obj[name] = fileInfo;
      this.setState(obj);
    };
  }
  render() {
    const { handleCompletarPerfilSubmit } = this.props;
    const { formatMessage } = this.props.intl;
    const { arquivoRg, arquivoVersoRg, /* arquivoComprovanteEnd,*/ arquivoSelfie } = this.state;
    const arquivos = {
      base64Rg: arquivoRg && arquivoRg.base64,
      base64VersoRg: arquivoVersoRg && arquivoVersoRg.base64,
      // base64ComprovanteEnd: arquivoComprovanteEnd && arquivoComprovanteEnd.base64,
      base64Selfie: arquivoSelfie && arquivoSelfie.base64,
    };
    return (
      <form className={styles.listArquivos}>
        <List>
          <ListItem key={1} autoHeight>
            <Dropzone accept="image/*" onDrop={(event) => this.onDrop(event, 'arquivoRg')} className={styles.dropzone} activeClassName={styles.dropzoneActive} maxSize="2097152">
              <div className={`${styles.preview} ${!arquivoRg && styles.bg}`}>
                <div style={{ backgroundImage: `url(${iconConfirm})` }} className={`${arquivoRg && styles.block} ${styles.hide} ${styles.confirImg} `}></div>
                <img className={`${arquivoRg && styles.block} ${styles.hide} `} src={arquivoRg && arquivoRg.thumb} role="presentation" />
              </div>
              <div className={styles.lblTit}><FormattedMessage {...messages.hintRG} /></div>
              <div className={styles.lblButton}><FormattedMessage {...messages.dropArquivoRG} /></div>
            </Dropzone>
          </ListItem>
          <ListItem key={2} autoHeight>
            <Dropzone accept="image/*" onDrop={(event) => this.onDrop(event, 'arquivoVersoRg')} className={styles.dropzone} activeClassName={styles.dropzoneActive} maxSize="2097152">
              <div className={`${styles.preview} ${!arquivoVersoRg && styles.bg}`}>
                <div style={{ backgroundImage: `url(${iconConfirm})` }} className={`${arquivoVersoRg && styles.block} ${styles.hide} ${styles.confirImg} `}></div>
                <img className={`${arquivoVersoRg && styles.block} ${styles.hide} `} src={arquivoVersoRg && arquivoVersoRg.thumb} role="presentation" />
              </div>
              <div className={styles.lblTit}><FormattedMessage {...messages.hintVersoRG} /></div>
              <div className={styles.lblButton}><FormattedMessage {...messages.dropArquivoRG} /></div>
            </Dropzone>
          </ListItem>
          {/* <ListItem key={3} autoHeight>
            <Dropzone onDrop={(event) => this.onDrop(event, 'arquivoComprovanteEnd')} className={styles.dropzone} activeClassName={styles.dropzoneActive}>
              <div className={`${styles.preview} ${!arquivoComprovanteEnd && styles.bg}`}>
                <div style={{ backgroundImage: `url(${iconConfirm})` }} className={`${arquivoComprovanteEnd && styles.block} ${styles.hide} ${styles.confirImg} `}></div>
                <img className={`${arquivoComprovanteEnd && styles.block} ${styles.hide} `} src={arquivoComprovanteEnd && arquivoComprovanteEnd.thumb} role="presentation" />
              </div>
              <div className={styles.lblTit}><FormattedMessage {...messages.hintComprovanteEnd} /></div>
              <div className={styles.lblButton}><FormattedMessage {...messages.dropArquivoRG} /></div>
            </Dropzone>
          </ListItem> */}
          <ListItem key={3} autoHeight>
            <Dropzone accept="image/*" onDrop={(event) => this.onDrop(event, 'arquivoSelfie')} className={styles.dropzone} activeClassName={styles.dropzoneActive} maxSize="2097152">
              <div className={`${styles.preview} ${!arquivoSelfie && styles.bg}`}>
                <div style={{ backgroundImage: `url(${iconConfirm})` }} className={`${arquivoSelfie && styles.block} ${styles.hide} ${styles.confirImg} `}></div>
                <img className={`${arquivoSelfie && styles.block} ${styles.hide} `} src={arquivoSelfie && arquivoSelfie.thumb} role="presentation" />
              </div>
              <div className={styles.lblTit}><FormattedMessage {...messages.hintSelfie} /></div>
              <div className={styles.lblButton}><FormattedMessage {...messages.dropArquivoRG} /></div>
            </Dropzone>
          </ListItem>
        </List>
        <div className={`${arquivoRg && arquivoVersoRg && arquivoSelfie && styles.block} ${styles.hide}`}>
          <FlatButton className="redButton big centered" label={formatMessage(messages.buttonContinuar)} tabIndex={11} onMouseUp={() => handleCompletarPerfilSubmit(arquivos)} />
        </div>
      </form>
    );
  }
}

AnexosFotos.propTypes = {
  handleCompletarPerfilSubmit: React.PropTypes.func,
  arquivoRg: React.PropTypes.object,
  arquivoVersoRg: React.PropTypes.object,
  // arquivoComprovanteEnd: React.PropTypes.object,
  arquivoSelfie: React.PropTypes.object,
  arquivos: React.PropTypes.object,
  intl: intlShape.isRequired,
};

export default injectIntl(reduxForm({
  form: 'anexosFotosForm',
  // validate: validateCotacaoMoedas,
  enableReinitialize: true,
})(AnexosFotos));
