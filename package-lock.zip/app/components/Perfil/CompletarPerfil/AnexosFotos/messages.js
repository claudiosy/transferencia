import { defineMessages } from 'react-intl';

export default defineMessages({
  hintRG: {
    id: 'app.components.Perfil.CompletarPerfil.AnexosFotos.hintRG',
    defaultMessage: 'Documento com CPF',
  },
  dropArquivoRG: {
    id: 'app.components.Perfil.CompletarPerfil.AnexosFotos.dropArquivoRG',
    defaultMessage: 'Clique para selecionar o arquivo, ou arraste ele aqui (máx. 2Mb).',
  },
  hintVersoRG: {
    id: 'app.components.Perfil.CompletarPerfil.AnexosFotos.hintVersoRG',
    defaultMessage: 'Verso do Documento',
  },
  hintComprovanteEnd: {
    id: 'app.components.Perfil.CompletarPerfil.AnexosFotos.hintComprovanteEnd',
    defaultMessage: 'COMPROVANTE DE ENDEREÇO',
  },
  hintSelfie: {
    id: 'app.components.Perfil.CompletarPerfil.AnexosFotos.hintSelfie',
    defaultMessage: 'Selfie',
  },
  buttonAnexar: {
    id: 'app.components.Perfil.CompletarPerfil.AnexosFotos.buttonAnexar',
    defaultMessage: 'Anexar Foto',
  },
  buttonContinuar: {
    id: 'app.components.Perfil.CompletarPerfil.AnexosFotos.buttonContinuar',
    defaultMessage: 'Continuar',
  },
});
