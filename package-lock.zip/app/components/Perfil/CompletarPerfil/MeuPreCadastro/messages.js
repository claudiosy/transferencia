import { defineMessages } from 'react-intl';

export default defineMessages({
  hintCPF: {
    id: 'app.components.Perfil.CompletarPerfil.MeuPreCadastro.hintCPF',
    defaultMessage: 'CPF',
  },
  hintNome: {
    id: 'app.components.Perfil.CompletarPerfil.MeuPreCadastro.hintNome',
    defaultMessage: 'NOME COMPLETO',
  },
  hintNascimento: {
    id: 'app.components.Perfil.CompletarPerfil.MeuPreCadastro.hintNascimento',
    defaultMessage: 'DATA DE NASCIMENTO',
  },
  hintIdentidade: {
    id: 'app.components.Perfil.CompletarPerfil.MeuPreCadastro.hintOperadora',
    defaultMessage: 'DOCUMENTO DE IDENTIDADE',
  },
  hintOrgaoEmissor: {
    id: 'app.components.Perfil.CompletarPerfil.MeuPreCadastro.hintOrgaoEmissor',
    defaultMessage: 'ORGÃO EMISSOR',
  },
  hintCelular: {
    id: 'app.components.Perfil.CompletarPerfil.MeuPreCadastro.hintCelular',
    defaultMessage: 'CELULAR',
  },
  hintEmail: {
    id: 'app.components.Perfil.CompletarPerfil.MeuPreCadastro.hintEmail',
    defaultMessage: 'E-MAIL',
  },
  hintPais: {
    id: 'app.components.Perfil.CompletarPerfil.MeuPreCadastro.hintPais',
    defaultMessage: 'PAIS DE NASCIMENTO',
  },
  hintSexo: {
    id: 'app.components.Perfil.CompletarPerfil.MeuPreCadastro.hintSexo',
    defaultMessage: 'GÊNERO',
  },
  hintNomeMae: {
    id: 'app.components.Perfil.CompletarPerfil.MeuPreCadastro.hintNomeMae',
    defaultMessage: 'NOME DA MÃE',
  },
  loadingMeusDados: {
    id: 'app.components.Perfil.CompletarPerfil.MeuPreCadastro.loadingMeusDados',
    defaultMessage: 'Carregando seus dados...',
  },
  buttonContinuar: {
    id: 'app.components.Perfil.CompletarPerfil.MeuPreCadastro.buttonContinuar',
    defaultMessage: 'Continuar',
  },
});
