import React from 'react';
import { reduxForm, Field, change, formValueSelector } from 'redux-form/immutable';
import { connect } from 'react-redux';
import { TextField, SelectField } from 'redux-form-material-ui';
import FlatButton from 'material-ui/FlatButton';
import validateMeuPreCadastro from './validation';
import { injectIntl, intlShape, FormattedMessage } from 'react-intl';
import messages from './messages';
import CircularProgress from 'material-ui/CircularProgress';
import { normalizeCPF, normalizeData, normalizeCelular, normalizeNomeMae, normalizeDocumento, normalizeOrgaoEmissor } from 'normalizers';
import SelectItem from 'components/SelectItem';
import List from 'components/List';
import ListItem from 'components/ListItem';
import styles from './styles.css';

const MeuPreCadastro = props => {
  const { handleSubmit, handleConfirmDados, pristine, submitting, loading, loadingPaises, paises, dadosConfirm, sexo } = props;
  const { formatMessage } = props.intl;
  let content;

  if (loading || loadingPaises) {
    content = (
      <List>
        <ListItem key={-3} showProceedIcon={false}>
          <span className={styles.loaderWrapper}>
            <CircularProgress size={0.3} />
          </span>
          <FormattedMessage {...messages.loadingMeusDados} />
        </ListItem>
      </List>
    );
  } else {
    content = (
      <form onSubmit={handleSubmit}>
        <List>
          <ListItem key={1} invisibled={dadosConfirm} notButton>
            <Field name="CPF" component={TextField} className="redInput wFloatingLabel" floatingLabelText={formatMessage(messages.hintCPF)} type="tel" normalize={normalizeCPF} tabIndex="1" readOnly />
          </ListItem>
          <ListItem key={2} invisibled={dadosConfirm} notButton>
            <Field name="Nome" component={TextField} className="redInput wFloatingLabel" floatingLabelText={formatMessage(messages.hintNome)} tabIndex="2" readOnly />
          </ListItem>
          <ListItem key={3} invisibled={dadosConfirm} notButton>
            <Field name="DataNascimento" component={TextField} className="redInput wFloatingLabel" floatingLabelText={formatMessage(messages.hintNascimento)} type="tel" normalize={normalizeData} format={normalizeData} tabIndex="3" readOnly />
          </ListItem>
          <ListItem key={4} invisibled={dadosConfirm} notButton>
            <Field name="Celular" component={TextField} className="redInput wFloatingLabel" floatingLabelText={formatMessage(messages.hintCelular)} type="tel" normalize={normalizeCelular} format={normalizeCelular} tabIndex="4" readOnly />
          </ListItem>
          <ListItem key={5} invisibled={dadosConfirm} notButton>
            <Field name="Email" component={TextField} className="redInput wFloatingLabel" floatingLabelText={formatMessage(messages.hintEmail)} tabIndex="5" readOnly />
          </ListItem>
          <ListItem key={6} invisibled={!dadosConfirm}>
            <SelectItem
              selectData={paises}
              name="PaisID"
              component={SelectField}
              className="redInput wFloatingLabel"
              floatingLabelText={formatMessage(messages.hintPais)}
              tabIndex="6"
              autoWidth
            />
          </ListItem>
          <ListItem key={7} invisibled={!dadosConfirm}>
            <Field name="NumeroDocumento" component={TextField} className="redInput wFloatingLabel" floatingLabelText={formatMessage(messages.hintIdentidade)} normalize={normalizeDocumento} tabIndex="7" />
          </ListItem>
          <ListItem key={8} invisibled={!dadosConfirm}>
            <Field name="OrgaoEmissorDocumento" component={TextField} className="redInput wFloatingLabel" floatingLabelText={formatMessage(messages.hintOrgaoEmissor)} normalize={normalizeOrgaoEmissor} tabIndex="8" />
          </ListItem>
          <ListItem key={9} invisibled={!dadosConfirm}>
            <SelectItem
              selectData={sexo}
              name="Sexo"
              component={SelectField}
              className="redInput wFloatingLabel"
              floatingLabelText={formatMessage(messages.hintSexo)}
              tabIndex="9"
              autoWidth
            />
          </ListItem>
          <ListItem key={10} invisibled={!dadosConfirm}>
            <Field name="NomeMae" component={TextField} className="redInput wFloatingLabel" floatingLabelText={formatMessage(messages.hintNomeMae)} normalize={normalizeNomeMae} tabIndex="10" />
          </ListItem>
        </List>
        <div className={`${!dadosConfirm ? styles.block : ''} ${styles.hide}`}>
          <FlatButton className="redButton big centered" label={formatMessage(messages.buttonContinuar)} tabIndex={11} onClick={() => handleConfirmDados()} />
        </div>
        <div className={`${dadosConfirm ? styles.block : ''} ${styles.hide}`}>
          <FlatButton type="submit" className="redButton big centered" label={formatMessage(messages.buttonContinuar)} disabled={pristine || submitting} tabIndex={12} />
        </div>
      </form>
    );
  }

  return (
    <div>
      {content}
    </div>
  );
};

MeuPreCadastro.propTypes = {
  pristine: React.PropTypes.bool,
  submitting: React.PropTypes.bool,
  handleSubmit: React.PropTypes.func,
  handleConfirmDados: React.PropTypes.func,
  loading: React.PropTypes.bool,
  loadingPaises: React.PropTypes.bool,
  paises: React.PropTypes.object,
  CPF: React.PropTypes.string,
  Nome: React.PropTypes.string,
  DataNascimento: React.PropTypes.string,
  NumeroDocumento: React.PropTypes.string,
  OrgaoEmissorDocumento: React.PropTypes.string,
  NomeMae: React.PropTypes.string,
  Celular: React.PropTypes.string,
  Email: React.PropTypes.string,
  PaisID: React.PropTypes.string,
  dadosConfirm: React.PropTypes.bool,
  intl: intlShape.isRequired,
  sexo: React.PropTypes.object,
};

function mapDispatchToProps(dispatch) {
  return {
    handleConfirmDados: () => {
      dispatch(change('meuPreCadastroForm', 'dadosConfirm', true));
    },
    dispatch,
  };
}

const selector = formValueSelector('meuPreCadastroForm');
export default connect(
  state => {
    const dadosConfirm = selector(state, 'dadosConfirm');
    return {
      dadosConfirm,
    };
  }, mapDispatchToProps)(injectIntl(reduxForm({
    form: 'meuPreCadastroForm',
    validate: validateMeuPreCadastro,
    enableReinitialize: true,
  })(MeuPreCadastro)));
