import messages from 'containers/App/messages';

const validateMeuPreCadastro = (valuesFromState, props) => {
  const { formatMessage } = props.intl;
  const errors = {};
  const values = valuesFromState.toJS();

  if (!values.PaisID) {
    errors.PaisID = formatMessage(messages.mandatoryField);
  }
  if (!values.NumeroDocumento) {
    errors.NumeroDocumento = formatMessage(messages.mandatoryField);
  }
  if (!values.OrgaoEmissorDocumento) {
    errors.OrgaoEmissorDocumento = formatMessage(messages.mandatoryField);
  }
  if (!values.Sexo) {
    errors.Sexo = formatMessage(messages.mandatoryField);
  }
  if (!values.NomeMae) {
    errors.NomeMae = formatMessage(messages.mandatoryField);
  }

  return errors;
};

export default validateMeuPreCadastro;
