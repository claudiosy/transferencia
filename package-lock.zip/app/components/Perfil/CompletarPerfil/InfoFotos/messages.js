import { defineMessages } from 'react-intl';

export default defineMessages({
  informativo: {
    id: 'app.components.Perfil.CompletarPerfil.InfoFotos.informativo',
    defaultMessage: 'O último passo para completar seu perfil Superdigital é inserir imagens do seu documento com CPF.',
  },
  buttonInserirImgs: {
    id: 'app.components.Perfil.CompletarPerfil.InfoFotos.buttonInserirImgs',
    defaultMessage: 'INSERIR IMAGENS',
  },
  buttonPularEtapa: {
    id: 'app.components.Perfil.CompletarPerfil.InfoFotos.buttonPularEtapa',
    defaultMessage: 'PULAR ESTA ETAPA',
  },
});
