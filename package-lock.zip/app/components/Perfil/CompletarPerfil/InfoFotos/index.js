import React from 'react';
import List from 'components/List';
import ListItem from 'components/ListItem';
import { Row, Col } from 'react-flexbox-grid/lib/index';
import styles from './styles.css';
import messages from './messages';
import FlatButton from 'material-ui/FlatButton';
import { FormattedMessage, injectIntl, intlShape } from 'react-intl';

const InfoFotos = props => {
  // const { handleStepFormChange, handleCompletarPerfilSubmit } = props;
  const { handleStepFormChange } = props;
  const { formatMessage } = props.intl;
  return (
    // eslint-disable-next-line react/jsx-boolean-value
    <div className={styles.informativo}>
      <List>
        <ListItem key={1} autoHeight notButton>
          <p>
            <span><FormattedMessage {...messages.informativo} /></span>
          </p>
        </ListItem>
      </List>
      <Row center="xs">
        <Col sm={12} xs={12}>
          <FlatButton className="redButton big centered" label={formatMessage(messages.buttonInserirImgs)} onMouseUp={() => handleStepFormChange(6)} />
        </Col>
        {/* <Col sm={6} xs={12}>
          <FlatButton className="redButton big centered inLeftBig" label={formatMessage(messages.buttonPularEtapa)} onMouseUp={() => handleCompletarPerfilSubmit()} />
        </Col> */}
      </Row>
    </div>
  );
};

InfoFotos.propTypes = {
  handleStepFormChange: React.PropTypes.func,
  // handleCompletarPerfilSubmit: React.PropTypes.func,
  intl: intlShape.isRequired,
};

export default (injectIntl(InfoFotos));
