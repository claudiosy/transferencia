import { defineMessages } from 'react-intl';

export default defineMessages({
  btAcessar: {
    id: 'superdigital.CompletarPerfil.Planos.btAcessar',
    defaultMessage: 'Quero experimentar a Superdigital sem uma assinatura agora',
  },
  btContinuar: {
    id: 'superdigital.CompletarPerfil.Planos.btContinuar',
    defaultMessage: 'CONTINUAR',
  },
  escolhePlano: {
    id: 'superdigital.CompletarPerfil.Planos.escolhePlano',
    defaultMessage: 'QUERO ESTE',
  },
  lblConcordo: {
    id: 'superdigital.CompletarPerfil.Planos.lblConcordo',
    defaultMessage: 'Li e concordo com os',
  },
  lblTermoUso: {
    id: 'superdigital.CompletarPerfil.Planos.lblTermoUso',
    defaultMessage: 'Termos de Uso',
  },
  lblSuperdigital: {
    id: 'superdigital.CompletarPerfil.Planos.lblSuperdigital',
    defaultMessage: 'da Superdigital',
  },
  lblAceitePromocoes: {
    id: 'superdigital.CompletarPerfil.Planos.lblAceitePromocoes',
    defaultMessage: 'Aceito receber e-mails promocionais ',
  },
});
