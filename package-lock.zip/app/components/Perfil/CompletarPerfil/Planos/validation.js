import messages from 'containers/App/messages';

const validatePlanos = (valuesFromState, props) => {
  const { formatMessage } = props.intl;
  const errors = {};
  const values = valuesFromState.toJS();
  if (!values.TermoUso) {
    errors.TermoUso_Check = formatMessage(messages.mandatoryTermoUso);
  }
  return errors;
};

export default validatePlanos;
