import React from 'react';
import { connect } from 'react-redux';
import { reduxForm, change, formValueSelector, Field } from 'redux-form/immutable';
import { Checkbox, TextField } from 'redux-form-material-ui';
import { FormattedNumber, injectIntl, intlShape } from 'react-intl';
import { Row, Col } from 'react-flexbox-grid/lib/index';
import FlatButton from 'material-ui/FlatButton';
import List from 'components/List';
import ListItem from 'components/ListItem';
import messages from './messages';
import styles from './styles.css';
import validatePlanos from './validation';
import openarrowIcon from 'containers/App/openarrow-icon.png';
import closearrowIcon from 'containers/App/closearrow-icon.png';

const Planos = props => { // eslint-disable-line react/prefer-stateless-function
  const { /* redirectDashboard,*/ planos, handleSubmit, handleSelectPlano, handleOpenPlano, planoSelected, PlanoId, showFreemium } = props;
  const { formatMessage } = props.intl;

  const planosList = planos && planos.toJS().map((plano) => { // eslint-disable-line arrow-body-style
    return (
      <ListItem key={plano.PlanoId} onClick={() => handleOpenPlano(plano.PlanoId, planoSelected)} autoHeight>
        <div className={styles.formWrapperSucess}>
          <Row className={styles.itemPlano}>
            <Col sm={8} xs={12}>
              <span className={`${styles.lblTit} ${PlanoId === plano.PlanoId && styles.lblTitAtivo}`}>{plano.Nome}</span>
              <span>{plano.Descricao}</span>
            </Col>
            <Col sm={4} xs={12}>
              <span className={`${styles.valor} ${PlanoId === plano.PlanoId && styles.valorAtivo}`}>
                <i>{plano.SimboloMoeda}</i>
                <b><FormattedNumber style="decimal" minimumFractionDigits={2} value={plano.ValorPlano} /></b> / mês
                <FlatButton className={styles.rightIcon} type="button" onClick={() => handleOpenPlano(plano.PlanoId, planoSelected)}>
                  <img src={planoSelected === plano.PlanoId ? closearrowIcon : openarrowIcon} role="presentation" />
                </FlatButton>
              </span>
            </Col>
          </Row>
          <Row center="xs" className={`${planoSelected === plano.PlanoId ? styles.block : ''} ${styles.hide}`}>
            <Col sm={12} xs={12}>
              <FlatButton className={`${styles.btnEscolhePlano} redButton`} label={formatMessage(messages.escolhePlano)} onClick={() => handleSelectPlano(plano.PlanoId)} />
            </Col>
          </Row>
        </div>
      </ListItem>
    );
  });

  const buttonFree = document.getElementsByTagName('button');
  let i;

  for (i = 0; i < buttonFree.length; i++) {
    if (buttonFree[i].name === 'btnFree') {
      buttonFree[i].onmouseover = function mouseIn() {
        document.getElementById('spanExp').style.cssText = 'font-size: 14px; color: white; -webkit-transition: all .1s ease-in-out; -moz-transition: all .1s ease-in-out; transition: all .1s ease-in-out;';
      };
      buttonFree[i].onmouseout = function mouseOut() {
        document.getElementById('spanExp').style.cssText = 'font-size: 14px; color: red; -webkit-transition: all .1s ease-in-out; -moz-transition: all .1s ease-in-out; transition: all .1s ease-in-out;';
      };

      buttonFree[i].innerHTML = '<style type="text/css">.redText{color:red;}</style><div><span style="position: relative; padding-left: 16px; padding-right: 1px; vertical-align: middle; letter-spacing: 0px; text-transform: uppercase; font-weight: 500; font-size: 14px;">Quero </span><span id="spanExp" style="position: relative; padding-left: 0px; padding-right: 1px; vertical-align: middle; letter-spacing: 0px; text-transform: uppercase; font-weight: 500; font-size: 14px;" class="redText">experimentar </span><span style="position: relative; padding-left: 0px; padding-right: 16px; vertical-align: middle; letter-spacing: 0px; text-transform: uppercase; font-weight: 500; font-size: 14px;">a Superdigital sem uma assinatura agora</span></div>';
      break;
    }
  }

  return (
    <form onSubmit={handleSubmit}>
      <List>
        <ListItem key={1} autoHeight>
          <p>
            Escolha uma assinatura:
          </p>
        </ListItem>
      </List>
      <List showHoverEffect behind={(planoSelected && planoSelected !== 0) || (PlanoId && PlanoId !== 0)} activeItem={PlanoId || planoSelected}>
        {planosList}
      </List>
      {showFreemium && <div className={`${PlanoId && PlanoId !== 0 ? styles.hide : ''}`}>
        <FlatButton className={styles.try} label={formatMessage(messages.btAcessar)} /* onMouseUp={redirectDashboard}*/ type="submit" />
      </div>}
      <div className={`${styles.block} ${styles.itensCheckbox}`}>
        <Row>
          <Col xs={12}>
            <Field name="TermoUso" id="TermoUso" component={Checkbox} className={`${styles.inputChk} redInput`} />
            <label htmlFor="TermoUso">{formatMessage(messages.lblConcordo)} <a href="http://superdigital.com.br/Termos_Superdigital.pdf" target="_blank">{formatMessage(messages.lblTermoUso)}</a> {formatMessage(messages.lblSuperdigital)}</label>
            <Field component={TextField} className={`${styles.chkTermoUso} iptHidden`} name="TermoUso_Check" type="hidden" underlineShow={false} />
          </Col>
        </Row>
        <Row>
          <Col xs={12}>
            <Field name="AceitePromocoes" id="AceitePromocoes" component={Checkbox} className={`${styles.inputChk} redInput`} />
            <label htmlFor="AceitePromocoes">{formatMessage(messages.lblAceitePromocoes)}</label>
          </Col>
        </Row>
      </div>
      <div className={`${PlanoId && PlanoId !== 0 ? styles.block : ''} ${styles.hide}`}>
        <FlatButton type="submit" className="redButton big centered" label={formatMessage(messages.btContinuar)} />
      </div>
      <div className={styles.infoPlanos}>
        <h4>Com a sua assinatura, você usa todas as funcionalidades Superdigital quantas vezes quiser sem pagar nada por isso. Se quiser algum serviço extra, você paga:</h4>
        <ul>
          <li>R$ 5,90 por saque no Brasil no Banco 24Horas.</li>
          <li>R$ 2,00 por emissão de saldo ou extrato no Banco 24Horas.</li>
          <li>R$ 5,90 por transferências para outros bancos.</li>
          <li>R$ 19,90 por saque no exterior na Rede Cirrus®.</li>
          <li>R$ 4,90 por cartão virtual emitido acima da franquia.</li>
          <li>R$ 14,90 por 2ª via de cartão emitido ou por cartão físico emitido acima da franquia.</li>
        </ul>
      </div>
    </form>
  );
};

Planos.propTypes = {
  initialValues: React.PropTypes.object,
  handleOpenPlano: React.PropTypes.func,
  handleSelectPlano: React.PropTypes.func,
  handleSubmit: React.PropTypes.func,
  planoSelected: React.PropTypes.number,
  // idPlanoSelected: React.PropTypes.number,
  PlanoId: React.PropTypes.number,
  TermoUso: React.PropTypes.bool,
  AceitePromocoes: React.PropTypes.bool,
  showFreemium: React.PropTypes.bool,
  planos: React.PropTypes.object,
  intl: intlShape.isRequired,
  redirectDashboard: React.PropTypes.func,
};

function mapDispatchToProps(dispatch) {
  return {
    handleOpenPlano: (plano, planoSelected) => {
      dispatch(change('planosForm', 'planoSelected', planoSelected === plano ? 0 : plano));
    },
    handleSelectPlano: (PlanoId) => {
      // dispatch(change('planosForm', 'idPlanoSelected', PlanoId));
      dispatch(change('planosForm', 'PlanoId', PlanoId));
    },
    dispatch,
  };
}

const selector = formValueSelector('planosForm');
export default connect(
  state => {
    const planoSelected = selector(state, 'planoSelected');
    const PlanoId = selector(state, 'PlanoId');
    return {
      planoSelected,
      PlanoId,
    };
  }, mapDispatchToProps)(injectIntl(reduxForm({
    form: 'planosForm',
    validate: validatePlanos,
  })(Planos)));
