/*
 * LoginForm Messages
 *
 * This contains all the text for the LoginForm component.
 */
import { defineMessages } from 'react-intl';

export default defineMessages({
  header: {
    id: 'superdigital.LoginForm.header',
    defaultMessage: 'Faça seu login',
  },
  labelCPF: {
    id: 'superdigital.LoginForm.labelCPF',
    defaultMessage: 'CPF só números mesmo',
  },
  labelSenha: {
    id: 'superdigital.LoginForm.labelSenha',
    defaultMessage: 'SENHA',
  },
  submitButton: {
    id: 'superdigital.LoginForm.submitButton',
    defaultMessage: 'Entrar',
  },
});
