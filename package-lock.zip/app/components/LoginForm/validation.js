import messages from 'containers/App/messages';

const validateLogin = (valuesFromState, props) => {
  const { formatMessage } = props.intl;
  const errors = {};
  const values = valuesFromState.toJS();

  if (!values.cpf || values.cpf.length < 14) {
    errors.cpf = formatMessage(messages.mandatoryField);
  }
  // if (!values.senha) {
    // errors.senha = formatMessage(messages.mandatoryField);
  // }
  return errors;
};

export default validateLogin;
