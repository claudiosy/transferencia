import { cpfValidation } from 'containers/LoginPage/actions';
import { openSignUpPage, setDadosRecadastro } from 'containers/SignUpPage/actions';
import { push } from 'react-router-redux';

const asyncValidateLogin = (values, dispatch) => {
  const data = values.toJS();
  return new Promise((resolve, reject) => {
    dispatch(cpfValidation(data.cpf, resolve, reject));
  }).then((status) => {
    if (status.Status < 1) {
      dispatch(openSignUpPage(data.cpf));
      dispatch(push('/cadastro'));
      // dispatch(cpfValidationSuccessOrFailure(1));
    } else if (status.Status === 4) {
      dispatch(setDadosRecadastro(data.cpf, status.Nome, status.DataNascimento));
    }
  });
};

export default asyncValidateLogin;
