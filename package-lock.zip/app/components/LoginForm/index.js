import React from 'react';
import { reduxForm /* Field */ } from 'redux-form/immutable';
import { TextField } from 'redux-form-material-ui';
import IconTextField from 'components/IconTextField';
// import CircularProgress from 'material-ui/CircularProgress';
// import FlatButton from 'material-ui/FlatButton';

import { normalizeCPF } from 'normalizers';
import validateLogin from './validation';
import asyncValidateLogin from './asyncValidation';

import { injectIntl, intlShape } from 'react-intl';
import messages from './messages';
import styles from './styles.css';
import personIcon from 'containers/App/person-icon.png';
// import lockIcon from 'containers/App/lock-icon.png';
import proceedIcon from 'containers/App/proceed-icon.png';

const LoginForm = props => { // eslint-disable-line react/prefer-stateless-function
  const { cpfStatus, hasCpf, senhaStatus, handleSubmit } = props;
  const { formatMessage } = props.intl;

  return (
    <form className={styles.loginForm} onSubmit={(evt) => { evt.preventDefault(); return false; }}>
      <IconTextField autoFocus={!hasCpf} name="cpf" type="tel" className="redInput negative" wrapperClassName="fieldWrapper sm-centered" fieldStatus={cpfStatus} icon={personIcon} component={TextField} floatingLabelText={formatMessage(messages.labelCPF)} label={formatMessage(messages.labelCPF)} normalize={normalizeCPF} onKeyUp={(evt) => evt.keyCode === 13 && document.getElementsByName('senha')[0].focus()} />
      <IconTextField className="redInput negative" name="senha" type="password" wrapperClassName={`fieldWrapper sm-centered ${styles.senha}`} component={TextField} fieldStatus={senhaStatus} icon={proceedIcon} floatingLabelText={formatMessage(messages.labelSenha)} label={formatMessage(messages.labelSenha)} onFocus={() => { document.getElementsByName('cpf')[0].focus(); document.activeElement.blur(); }} readOnly />
      <button className={styles.hiddenSubmit} onMouseUp={handleSubmit} />
    </form>
  );
};

LoginForm.propTypes = {
  handleSubmit: React.PropTypes.func,
  cpfStatus: React.PropTypes.number,
  senhaStatus: React.PropTypes.number,
  hasCpf: React.PropTypes.string,
  intl: intlShape.isRequired,
};

export default injectIntl(reduxForm({
  form: 'loginForm',
  validate: validateLogin,
  asyncValidate: asyncValidateLogin,
  asyncBlurFields: ['cpf'],
})(LoginForm));
