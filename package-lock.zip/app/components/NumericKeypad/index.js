/**
*
* NumericKeypad
*
*/

import React from 'react';
import { connect } from 'react-redux';

import FlatButton from 'material-ui/FlatButton';

import { injectIntl, intlShape, FormattedMessage } from 'react-intl';
import { change, submit } from 'redux-form/immutable';
import messages from './messages';
import confirmIcon from './confirm-green-icon.png';
import whiteLockIcon from 'containers/App/white-lock.png';
import tokenAppIcon from 'containers/App/tokenapp-icon.png';
import backIcon from './back-icon.png';

import styles from './styles.css';

class NumericKeypad extends React.Component { // eslint-disable-line react/prefer-stateless-function
  constructor() {
    super();
    this.state = { wrong: false };
  }
  keypadNumberClick(number) {
    const { form, field, password, passwordLength } = this.props;

    if ((password || '').length < passwordLength) {
      this.props.handleNumberClick(form, field, password, number);
    }
  }
  keypadClearClick() {
    const { form, field, password } = this.props;

    if ((!password || !password.length) && this.props.handleBack) {
      this.props.handleBack();
    } else {
      this.props.handleNumberClick(form, field, password && password.length > 1 ? password.toString().substring(0, password.toString().length - 1) : null, '');
    }
  }
  keypadConfirmClick() {
    const { form, shouldSubmit, handleSubmit, password, passwordLength } = this.props;

    if ((password || '').length < passwordLength) {
      clearTimeout(this.wrongTimeout);
      this.setState({ wrong: true });
      this.wrongTimeout = setTimeout(() => {
        this.setState({ wrong: false });
      }, 1000);
      if (navigator.vibrate) {
        navigator.vibrate(100);
      }

      return;
    }

    if (shouldSubmit) {
      this.props.handleConfirmClick(form);
    } else if (handleSubmit) {
      handleSubmit();
    }
  }
  render() {
    const { formatMessage } = this.props.intl;
    const { password, passwordLength, handleBack, title, isToken, field } = this.props;

    const dots = [];

    for (let i = 1; i <= passwordLength; i++) {
      if (!isToken) {
        dots.push(<li className={i <= (password ? password.length : 0) && styles.filled}></li>);
      } else {
        dots.push(<li className={i <= (password ? password.length : 0) ? styles.filledNumber : styles.dash}>{password && password[i - 1]}</li>);
      }
    }

    return (
      <div name={`div${field}`} className={styles.numericKeypad}>
        <h4 className={styles.title}>
          <img src={(isToken ? tokenAppIcon : whiteLockIcon)} className={styles.lockIcon} role="presentation" alt="" />
          <span>
            {title || formatMessage(messages.title)}
          </span>
        </h4>

        <ul className={`${styles.passwordDots} ${this.state.wrong && styles.wrong}`}>
          {dots}
        </ul>

        <ul className={styles.keypadButtons}>
          <li>
            <FlatButton name="btn1" className={styles.keypadButton} type="button" label={formatMessage(messages.one)} onMouseDown={() => this.keypadNumberClick(1)} />
          </li>
          <li>
            <FlatButton name="btn2" className={styles.keypadButton} type="button" label={formatMessage(messages.two)} onMouseDown={() => this.keypadNumberClick(2)} />
          </li>
          <li>
            <FlatButton name="btn3" className={styles.keypadButton} type="button" label={formatMessage(messages.three)} onMouseDown={() => this.keypadNumberClick(3)} />
          </li>
          <li>
            <FlatButton name="btn4" className={styles.keypadButton} type="button" label={formatMessage(messages.four)} onMouseDown={() => this.keypadNumberClick(4)} />
          </li>
          <li>
            <FlatButton name="btn5" className={styles.keypadButton} type="button" label={formatMessage(messages.five)} onMouseDown={() => this.keypadNumberClick(5)} />
          </li>
          <li>
            <FlatButton name="btn6" className={styles.keypadButton} type="button" label={formatMessage(messages.six)} onMouseDown={() => this.keypadNumberClick(6)} />
          </li>
          <li>
            <FlatButton name="btn7" className={styles.keypadButton} type="button" label={formatMessage(messages.seven)} onMouseDown={() => this.keypadNumberClick(7)} />
          </li>
          <li>
            <FlatButton name="btn8" className={styles.keypadButton} type="button" label={formatMessage(messages.eight)} onMouseDown={() => this.keypadNumberClick(8)} />
          </li>
          <li>
            <FlatButton name="btn9" className={styles.keypadButton} type="button" label={formatMessage(messages.nine)} onMouseDown={() => this.keypadNumberClick(9)} />
          </li>
          <li>
            <FlatButton name="btnBack" className={`${styles.keypadButton} ${styles.noCircle} ${styles.hasIcon}`} label="C" type="button" onTouchTap={() => this.keypadClearClick()}>
              <img src={backIcon} role="presentation" />
              {((password && password.length) || !handleBack) && <FormattedMessage {...messages.clear} />}
              {((!password || !password.length) && handleBack) && <FormattedMessage {...messages.back} />}
            </FlatButton>
          </li>
          <li>
            <FlatButton name="btn0" className={styles.keypadButton} type="button" label={formatMessage(messages.zero)} onMouseDown={() => this.keypadNumberClick(0)} />
          </li>
          <li>
            <FlatButton name="btnConfirm" className={`${styles.keypadButton} ${styles.noCircle} ${styles.hasIcon}`} label="C" type="button" onTouchTap={() => this.keypadConfirmClick()}>
              <img src={confirmIcon} role="presentation" />
              <FormattedMessage {...messages.confirm} />
            </FlatButton>
          </li>
        </ul>
      </div>
    );
  }
}

NumericKeypad.propTypes = {
  form: React.PropTypes.string,
  field: React.PropTypes.string,
  title: React.PropTypes.string,
  password: React.PropTypes.string,
  passwordLength: React.PropTypes.number,
  handleNumberClick: React.PropTypes.func,
  handleConfirmClick: React.PropTypes.func,
  handleSubmit: React.PropTypes.func,
  handleClose: React.PropTypes.func,
  handleBack: React.PropTypes.func,
  shouldSubmit: React.PropTypes.bool,
  isToken: React.PropTypes.bool,
  intl: intlShape.isRequired,
};

function mapDispatchToProps(dispatch) {
  return {
    handleNumberClick: (form, field, password, number) => {
      dispatch(change(form, field, (password || '') + number.toString()));
    },
    handleConfirmClick: (form) => {
      dispatch(submit(form));
    },
    dispatch,
  };
}

export default connect(null, mapDispatchToProps)(injectIntl(NumericKeypad));
