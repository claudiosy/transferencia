/*
 * NumericKeypad Messages
 *
 * This contains all the text for the NumericKeypad component.
 */
import { defineMessages } from 'react-intl';

export default defineMessages({
  title: {
    id: 'superdigital.NumericKeypad.title',
    defaultMessage: 'Senha Eletrônica',
  },
  one: {
    id: 'superdigital.NumericKeypad.one',
    defaultMessage: '1',
  },
  two: {
    id: 'superdigital.NumericKeypad.two',
    defaultMessage: '2',
  },
  three: {
    id: 'superdigital.NumericKeypad.three',
    defaultMessage: '3',
  },
  four: {
    id: 'superdigital.NumericKeypad.four',
    defaultMessage: '4',
  },
  five: {
    id: 'superdigital.NumericKeypad.five',
    defaultMessage: '5',
  },
  six: {
    id: 'superdigital.NumericKeypad.six',
    defaultMessage: '6',
  },
  seven: {
    id: 'superdigital.NumericKeypad.seven',
    defaultMessage: '7',
  },
  eight: {
    id: 'superdigital.NumericKeypad.eight',
    defaultMessage: '8',
  },
  nine: {
    id: 'superdigital.NumericKeypad.nine',
    defaultMessage: '9',
  },
  zero: {
    id: 'superdigital.NumericKeypad.zero',
    defaultMessage: '0',
  },
  clear: {
    id: 'superdigital.NumericKeypad.clear',
    defaultMessage: 'Limpar',
  },
  confirm: {
    id: 'superdigital.NumericKeypad.confirm',
    defaultMessage: 'Confirmar',
  },
  back: {
    id: 'superdigital.NumericKeypad.back',
    defaultMessage: 'Voltar',
  },
});
