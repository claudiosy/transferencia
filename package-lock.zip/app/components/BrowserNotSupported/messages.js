/*
 * BrowserNotSupported Messages
 *
 * This contains all the text for the BrowserNotSupported component.
 */
import { defineMessages } from 'react-intl';

export default defineMessages({
  notSupportedMessage1: {
    id: 'superdigital.BrowserNotSupported.notSupportedMessage1',
    defaultMessage: 'VOCÊ PRECISA ATUALIZAR SEU NAVEGADOR.',
  },
  notSupportedMessage2: {
    id: 'superdigital.BrowserNotSupported.notSupportedMessage2',
    defaultMessage: 'Baixa lá a versão mais recente dele. A gente te espera.',
  },
});
