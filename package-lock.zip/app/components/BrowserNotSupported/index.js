import React from 'react';

import { FormattedMessage } from 'react-intl';
import messages from './messages';

import logo from './logo.png';
import omg from './omg.png';
import safari from './sa.png';
import firefox from './ff.png';
import chrome from './ch.png';
import opera from './op.png';
import ed from './ed.png';

import styles from './styles.css';

function BrowserNotSupported() {
  return (
    <div className={styles.browserNotSupported}>
      <div className={styles.logo}>
        <img src={logo} className={styles.imgLogo} role="presentation" alt="" />
      </div>
      <div className={styles.divOmg}>
        <img src={omg} role="presentation" alt="" />
      </div>

      <div className={styles.divMsg}>
        <h3 className={styles.msg1}><FormattedMessage {...messages.notSupportedMessage1} /></h3>
        <hr className={styles.hrRed}></hr>
        <h5 className={styles.msg2}><FormattedMessage {...messages.notSupportedMessage2} /></h5>
      </div>
      <div className={styles.divNav}>
        <a href="https://support.apple.com/downloads/safari/" target="_blank">
          <img src={safari} className={styles.spaceImg} role="presentation" alt="" />
        </a>
        <a href="https://www.opera.com/" target="_blank">
          <img src={opera} className={styles.spaceImg} role="presentation" alt="" />
        </a>
        <a href="https://www.google.com/chrome/browser/desktop/" target="_blank">
          <img src={chrome} className={styles.spaceImg} role="presentation" alt="" />
        </a>
        <a href="https://www.mozilla.com/firefox/" target="_blank">
          <img src={firefox} className={styles.spaceImg} role="presentation" alt="" />
        </a>
        <a href="https://www.microsoft.com/pt-br/windows/microsoft-edge" target="_blank">
          <img src={ed} className={styles.spaceImg} role="presentation" alt="" />
        </a>
      </div>
      <div className={styles.divFt}>
        <img src={logo} className={styles.imgLogoFt} role="presentation" alt="" />
      </div>
    </div>
  );
}

export default BrowserNotSupported;
